INSERT INTO login (email, contrasena) VALUES ('juan.perez@email.com', 'Pass1234');
INSERT INTO login (email, contrasena) VALUES ('m.garcia@servicio.cl', 'Admin_2024');
INSERT INTO login (email, contrasena) VALUES ('cruiz.98@webmail.com', 'Segura#98');
INSERT INTO login (email, contrasena) VALUES ('ana.soto@empresa.com', 'Soto_Ana21');
INSERT INTO login (email, contrasena) VALUES ('rlagos.75@portal.net', 'RbtLagos!5');