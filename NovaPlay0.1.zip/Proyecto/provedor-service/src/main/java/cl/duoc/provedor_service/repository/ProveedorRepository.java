package cl.duoc.provedor_service.repository;

import cl.duoc.provedor_service.model.Proveedor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface ProveedorRepository extends JpaRepository<Proveedor, Long> {
    // 1. Consulta por coincidencia exacta de RUT
    Optional<Proveedor> findByRut(String rut);

    // 2. Consulta por nombre que contenga una palabra (IgnoreCase para evitar problemas de mayúsculas)
    List<Proveedor> findByNombreContainingIgnoreCase(String nombre);

    // 3. Consulta de existencia (retorna boolean, ideal para validaciones)
    boolean existsByRut(String rut);

    List<Proveedor> findByActivoTrue();

    List<Proveedor> findByFechaRegistroBetween(LocalDate inicio, LocalDate fin);

    List<Proveedor> findByTipoProveedor(String tipo);
}
