INSERT INTO cliente (rut, nombre, apellido, fecha_nacimiento, login)
VALUES ('12.345.678-9', 'Juan', 'Pérez', '1990-05-15', 101);

INSERT INTO cliente (rut, nombre, apellido, fecha_nacimiento, login)
VALUES ('15.987.654-3', 'María José', 'García', '1985-11-22', 102);

INSERT INTO cliente (rut, nombre, apellido, fecha_nacimiento, login)
VALUES ('18.456.123-k', 'Carlos', 'Ruiz', '1998-02-03', 103);

INSERT INTO cliente (rut, nombre, apellido, fecha_nacimiento, login)
VALUES ('20.111.222-4', 'Ana', 'Soto', '2001-08-30', 104);

INSERT INTO cliente (rut, nombre, apellido, fecha_nacimiento, login)
VALUES ('9.876.543-2', 'Roberto', 'Lagos', '1975-12-12', 105);