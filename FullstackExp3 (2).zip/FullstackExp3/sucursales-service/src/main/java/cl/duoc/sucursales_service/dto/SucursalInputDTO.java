package cl.duoc.sucursales_service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Schema(description = "Estructura de entrada para los datos de una Sucursal")
public class SucursalInputDTO {

    @Schema(description = "Nombre de la sucursal", example = "Sucursal Plaza Vespucio")
    @NotBlank(message = "El nombre no puede estar vacío")
    private String nombre;

    @Schema(description = "Calle de la sucursal", example = "Av. Vicuña Mackenna")
    @NotBlank(message = "La calle no puede estar vacía")
    private String calle;

    @Schema(description = "Número de la sucursal", example = "7110")
    @NotNull(message = "El número de sucursal es obligatorio")
    private Integer nroSucursal;

    @Schema(description = "Identificador del proveedor", example = "12")
    @NotNull(message = "El ID del proveedor es obligatorio")
    private Integer idProvedor;
}