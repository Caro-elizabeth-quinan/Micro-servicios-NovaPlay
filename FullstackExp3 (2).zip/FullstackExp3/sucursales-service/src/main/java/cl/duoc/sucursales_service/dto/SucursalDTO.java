package cl.duoc.sucursales_service.dto;

import lombok.Data;

@Data
public class SucursalDTO {
    private String nombre;
    private String calle;
    private ProveedorDTO provedor;
}
