package cl.duoc.sucursales_service.mapper;

import cl.duoc.sucursales_service.dto.SucursalDTO;
import cl.duoc.sucursales_service.model.Sucursal;
import org.springframework.stereotype.Component;

@Component
public class SucursalMapper {

    public SucursalDTO toDTO(Sucursal sucu ){
        if ( sucu == null ) return null;
        SucursalDTO dto = new SucursalDTO();
        dto.setNombre( sucu.getNombre());
        dto.setCalle(sucu.getCalle());
        return dto;
    }
}
