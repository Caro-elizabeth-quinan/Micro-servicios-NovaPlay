package cl.duoc.sucursales_service.exception;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ErrorResponse {
    /*utilice esto para sacar los errores
    fecha	cuándo ocurrió
    status	código HTTP
    error	nombre del error
    mensaje	explicación personalizada
    path	endpoint que falló
     */
    private LocalDateTime fecha;
    private int status;
    private String error;
    private String mensaje;
    private String path;
}
