package cl.duoc.sucursales_service.controller;

import cl.duoc.sucursales_service.dto.SucursalDTO;
import cl.duoc.sucursales_service.dto.SucursalInputDTO;
import cl.duoc.sucursales_service.exception.ErrorResponse;
import cl.duoc.sucursales_service.model.Sucursal;
import cl.duoc.sucursales_service.service.SucursalService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/v1/sucursales")
@Tag(name = "Sucursal", description = "API para la gestión y búsquedas de Sucursales")
public class SucursalController {

    @Autowired
    private SucursalService sucursalService;

    @Operation(
            summary = "Buscar por código",
            description = "Busca una sucursal por su ID e integra los datos del proveedor compuesto vía DTO."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Sucursal DTO encontrada",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = SucursalDTO.class),
                    examples = @ExampleObject(
                            name = "Ejemplo Detalle Compuesto",
                            value = "{\n  \"nombre\": \"Sucursal Plaza Vespucio\",\n  \"calle\": \"Av. Vicuña Mackenna\",\n  \"provedor\": {\n    \"rut\": \"76.123.456-7\",\n    \"nombre\": \"Proveedor Mayorista SpA\",\n    \"direccion\": \"Santiago Centro\"\n  }\n}"
                    )
            )
    )
    @ApiResponse(
            responseCode = "404",
            description = "Sucursal no encontrada",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = @ExampleObject(
                            name = "Error: ID Inexistente",
                            value = "{\n  \"fecha\": \"2026-06-20T18:30:00\",\n  \"status\": 404,\n  \"error\": \"Not Found\",\n  \"mensaje\": \"Sucursal no encontrada con id: 99\",\n  \"path\": \"/api/v1/sucursales/99\"\n}"
                    )
            )
    )
    @GetMapping("/{cod}")
    public ResponseEntity<?> buscarPorId(
            @Parameter(description = "Código único de la sucursal", example = "1")
            @PathVariable Long cod
    ) {
        return ResponseEntity.ok(sucursalService.findById(cod));
    }

    @Operation(
            summary = "Actualizar una Sucursal",
            description = "Modifica los datos de una sucursal existente localizándola por su código."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Sucursal actualizada exitosamente",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = Sucursal.class)
            )
    )
    @ApiResponse(
            responseCode = "400",
            description = "Estructura del cuerpo de la solicitud mal formada",
            content = @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))
    )
    @ApiResponse(
            responseCode = "404",
            description = "Sucursal no encontrada para actualizar",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = @ExampleObject(
                            name = "Error: Actualización Fallida",
                            value = "{\n  \"fecha\": \"2026-06-20T18:35:00\",\n  \"status\": 404,\n  \"error\": \"Not Found\",\n  \"mensaje\": \"Sucursal no encontrada con id: 88\",\n  \"path\": \"/api/v1/sucursales/88\"\n}"
                    )
            )
    )
    @PutMapping("/{cod}")
    public ResponseEntity<?> actualizar(
            @PathVariable Long cod,
            @Valid @RequestBody SucursalInputDTO input
    ) {
        Sucursal sucursal = new Sucursal();
        // sucursal.setNombre(input.getNombre());
        // sucursal.setCalle(input.getCalle());
        // sucursal.setNroSucursal(input.getNroSucursal());
        // sucursal.setIdProvedor(input.getIdProvedor());

        Sucursal actualizada = sucursalService.update(cod, sucursal);
        return ResponseEntity.ok(actualizada);
    }

    @Operation(
            summary = "Eliminar una Sucursal",
            description = "Método que remueve una sucursal del sistema a partir de su código."
    )
    @ApiResponse(
            responseCode = "204",
            description = "Sucursal eliminada correctamente (Sin contenido)",
            content = @Content(mediaType = "application/json", schema = @Schema(hidden = true))
    )
    @ApiResponse(
            responseCode = "404",
            description = "Sucursal no encontrada para eliminar",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = @ExampleObject(
                            name = "Error: Eliminación Fallida",
                            value = "{\n  \"fecha\": \"2026-06-20T18:37:00\",\n  \"status\": 404,\n  \"error\": \"Not Found\",\n  \"mensaje\": \"Sucursal no encontrada con id: 99\",\n  \"path\": \"/api/v1/sucursales/99\"\n}"
                    )
            )
    )
    @DeleteMapping("/{cod}")
    public ResponseEntity<?> borrar(@PathVariable Long cod) {
        sucursalService.delete(cod);
        return ResponseEntity.noContent().build();
    }

    @Operation(
            summary = "Listar Sucursales",
            description = "Método que lista todas las sucursales registradas en el sistema."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Sucursales encontradas",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = Sucursal.class)),
                    examples = @ExampleObject(
                            name = "Ejemplo Lista",
                            value = "[\n  { \"id\": 1, \"nombre\": \"Sucursal Plaza Vespucio\", \"calle\": \"Av. Vicuña Mackenna\", \"nroSucursal\": 7110, \"idProvedor\": 12 }\n]"
                    )
            )
    )
    @GetMapping
    public ResponseEntity<?> listar() {
        return ResponseEntity.ok(sucursalService.findAll());
    }

    @Operation(
            summary = "Registrar una Sucursal",
            description = "Método que registra una nueva sucursal a partir de los datos de entrada."
    )
    @ApiResponse(
            responseCode = "201",
            description = "Sucursal registrada exitosamente",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = Sucursal.class),
                    examples = @ExampleObject(
                            name = "Sucursal Creada",
                            value = "{ \"id\": 2, \"nombre\": \"Sucursal Tobalaba\", \"calle\": \"Av. Tobalaba\", \"nroSucursal\": 1234, \"idProvedor\": 15 }"
                    )
            )
    )
    @ApiResponse(
            responseCode = "400",
            description = "Datos de entrada inválidos",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = @ExampleObject(
                            name = "Error: Bad Request",
                            value = "{\n  \"fecha\": \"2026-06-20T18:32:00\",\n  \"status\": 400,\n  \"error\": \"Bad Request\",\n  \"mensaje\": \"El nombre no puede estar vacío\",\n  \"path\": \"/api/v1/sucursales\"\n}"
                    )
            )
    )
    @PostMapping
    public ResponseEntity<?> registrar(@Valid @RequestBody SucursalInputDTO input) {
        Sucursal sucursal = new Sucursal();
        // sucursal.setNombre(input.getNombre());
        // sucursal.setCalle(input.getCalle());
        // sucursal.setNroSucursal(input.getNroSucursal());
        // sucursal.setIdProvedor(input.getIdProvedor());

        Sucursal nueva = sucursalService.save(sucursal);
        return new ResponseEntity<>(nueva, HttpStatus.CREATED);
    }

    @Operation(
            summary = "Buscar sucursales por proveedor",
            description = "Obtiene una lista de sucursales asociadas a un identificador de proveedor específico."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Sucursales del proveedor encontradas",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = Sucursal.class)),
                    examples = @ExampleObject(
                            name = "Sucursales por Proveedor",
                            value = "[\n  { \"id\": 1, \"nombre\": \"Sucursal Plaza Vespucio\", \"calle\": \"Av. Vicuña Mackenna\", \"nroSucursal\": 7110, \"idProvedor\": 12 }\n]"
                    )
            )
    )
    @ApiResponse(
            responseCode = "404",
            description = "Proveedor sin sucursales asociadas",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = @ExampleObject(
                            name = "Error: Proveedor Vacío",
                            value = "{\n  \"fecha\": \"2026-06-20T18:40:00\",\n  \"status\": 404,\n  \"error\": \"Not Found\",\n  \"mensaje\": \"No se encontraron sucursales asociadas al proveedor especificado\",\n  \"path\": \"/api/v1/sucursales/proveedor/12\"\n}"
                    )
            )
    )
    @GetMapping("/proveedor/{idProveedor}")
    public ResponseEntity<?> buscarProveedor(@PathVariable int idProveedor) {
        return ResponseEntity.ok(sucursalService.buscarPorProveedor(idProveedor));
    }

    @Operation(
            summary = "Buscar sucursales por número de dirección",
            description = "Obtiene la lista de sucursales que corresponden al número domiciliario exacto provisto."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Sucursales encontradas",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = Sucursal.class)),
                    examples = @ExampleObject(
                            name = "Sucursales por Número",
                            value = "[\n  { \"id\": 1, \"nombre\": \"Sucursal Plaza Vespucio\", \"calle\": \"Av. Vicuña Mackenna\", \"nroSucursal\": 7110, \"idProvedor\": 12 }\n]"
                    )
            )
    )
    @ApiResponse(
            responseCode = "404",
            description = "No se encontraron sucursales con ese número",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = @ExampleObject(
                            name = "Error: Número Inexistente",
                            value = "{\n  \"fecha\": \"2026-06-20T18:42:00\",\n  \"status\": 404,\n  \"error\": \"Not Found\",\n  \"mensaje\": \"No se encontraron sucursales con el número de calle indicado\",\n  \"path\": \"/api/v1/sucursales/buscar/numero/9999\"\n}"
                    )
            )
    )
    @GetMapping("/buscar/numero/{nro}")
    public ResponseEntity<?> buscarNumero(@PathVariable int nro) {
        return ResponseEntity.ok(sucursalService.buscarPorNumero(nro));
    }

    @Operation(
            summary = "Buscar sucursales por nombre exacto",
            description = "Filtra y obtiene las sucursales que coincidan de manera exacta con el nombre ingresado."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Sucursales encontradas",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = Sucursal.class)),
                    examples = @ExampleObject(
                            name = "Sucursales por Nombre",
                            value = "[\n  { \"id\": 1, \"nombre\": \"Sucursal Plaza Vespucio\", \"calle\": \"Av. Vicuña Mackenna\", \"nroSucursal\": 7110, \"idProvedor\": 12 }\n]"
                    )
            )
    )
    @ApiResponse(
            responseCode = "404",
            description = "Sucursales no encontradas por nombre",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = @ExampleObject(
                            name = "Error: Nombre Inexistente",
                            value = "{\n  \"fecha\": \"2026-06-20T18:44:00\",\n  \"status\": 404,\n  \"error\": \"Not Found\",\n  \"mensaje\": \"No se encontraron sucursales con el nombre especificado\",\n  \"path\": \"/api/v1/sucursales/buscar/nombre\"\n}"
                    )
            )
    )
    @GetMapping("/buscar/nombre")
    public ResponseEntity<?> buscarNombre(@RequestParam String valor) {
        return ResponseEntity.ok(sucursalService.buscarPorNombre(valor));
    }

    @Operation(
            summary = "Buscar sucursales por coincidencia de calle",
            description = "Obtiene las sucursales cuya calle contenga el patrón de texto enviado (Case Insensitive)."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Sucursales encontradas",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = Sucursal.class)),
                    examples = @ExampleObject(
                            name = "Sucursales por Calle",
                            value = "[\n  { \"id\": 1, \"nombre\": \"Sucursal Plaza Vespucio\", \"calle\": \"Av. Vicuña Mackenna\", \"nroSucursal\": 7110, \"idProvedor\": 12 }\n]"
                    )
            )
    )
    @ApiResponse(
            responseCode = "404",
            description = "No se encontraron sucursales en esa calle",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = @ExampleObject(
                            name = "Error: Calle sin Resultados",
                            value = "{\n  \"fecha\": \"2026-06-20T18:46:00\",\n  \"status\": 404,\n  \"error\": \"Not Found\",\n  \"mensaje\": \"No se encontraron sucursales registradas en la calle indicada\",\n  \"path\": \"/api/v1/sucursales/buscar/calle\"\n}"
                    )
            )
    )
    @GetMapping("/buscar/calle")
    public ResponseEntity<?> buscarCalle(@RequestParam String valor) {
        return ResponseEntity.ok(sucursalService.buscarPorCalle(valor));
    }
}