package cl.duoc.sucursales_service.clients;

import cl.duoc.sucursales_service.dto.ProveedorDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "provedor-service")
public interface ProvedorFeign {

    @GetMapping("/api/v1/proveedores/{id}")
    ProveedorDTO buscarPorId(@PathVariable int id);

}
