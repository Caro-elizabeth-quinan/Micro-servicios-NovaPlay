package cl.duoc.sucursales_service;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.cloud.openfeign.FeignClient;

@OpenAPIDefinition(
		info = @Info(
				title = "API para gestión de Sucursales",
				version = "1.0.1",
				description = "API que gestiona la información y localización de las sucursales, incluyendo búsquedas personalizadas.",
				contact = @Contact(
						name = "Carolina Elizabeth Quinan Perot",
						email = "ca.quinan@duocuc.cl"
				)
		)
)
@EnableDiscoveryClient
@EnableFeignClients
@SpringBootApplication
public class SucursalesServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SucursalesServiceApplication.class, args);
	}

}
