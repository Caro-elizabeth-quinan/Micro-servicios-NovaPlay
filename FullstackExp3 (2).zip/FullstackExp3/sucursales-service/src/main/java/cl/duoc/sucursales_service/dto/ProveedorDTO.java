package cl.duoc.sucursales_service.dto;

import lombok.Data;

@Data
public class ProveedorDTO {
    private String rut;
    private String nombre;
    private String direccion;
}
