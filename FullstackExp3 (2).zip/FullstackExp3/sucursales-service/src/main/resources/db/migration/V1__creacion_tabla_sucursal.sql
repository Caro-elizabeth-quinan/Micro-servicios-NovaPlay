create table sucursal(
    id bigint auto_increment primary key,
    nombre varchar(50) not null,
    calle varchar(50) not null,
    nro_sucursal integer not null,
    id_provedor integer not null
)
