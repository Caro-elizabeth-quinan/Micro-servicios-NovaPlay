INSERT INTO sucursal (nombre, calle, nro_sucursal, id_provedor)
VALUES ('Sucursal Central', 'Alameda', 101, 1);

INSERT INTO sucursal (nombre, calle, nro_sucursal, id_provedor)
VALUES ('Sucursal Norte', 'Av. Pedro de Valdivia', 102, 2);

INSERT INTO sucursal (nombre, calle, nro_sucursal, id_provedor)
VALUES ('Sucursal Oriente', 'Vitacura', 103, 3);

INSERT INTO sucursal (nombre, calle, nro_sucursal, id_provedor)
VALUES ('Sucursal Poniente', 'Pajaritos', 104, 4);

INSERT INTO sucursal (nombre, calle, nro_sucursal, id_provedor)
VALUES ('Sucursal Sur', 'Gran Avenida', 105, 5);