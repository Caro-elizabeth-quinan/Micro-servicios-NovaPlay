package cl.duoc.sucursales_service;

import cl.duoc.sucursales_service.clients.ProvedorFeign;
import cl.duoc.sucursales_service.dto.ProveedorDTO;
import cl.duoc.sucursales_service.dto.SucursalDTO;
import cl.duoc.sucursales_service.mapper.SucursalMapper;
import cl.duoc.sucursales_service.model.Sucursal;
import cl.duoc.sucursales_service.repository.SucursalRepository;
import cl.duoc.sucursales_service.service.SucursalService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
class SucursalServiceTest {

    @Mock
    private SucursalRepository sucursalRepository;

    @Mock
    private SucursalMapper sucursalMapper;

    @Mock
    private ProvedorFeign provedorFeign;

    @InjectMocks
    private SucursalService sucursalService;

    @Test
    void findAll() {

        Sucursal sucursal = new Sucursal();
        sucursal.setNombre("Sucursal Centro");

        when(sucursalRepository.findAll())
                .thenReturn(List.of(sucursal));

        List<Sucursal> resultado = sucursalService.findAll();

        assertNotNull(resultado);
        assertEquals(1, resultado.size());

        verify(sucursalRepository).findAll();
    }

    @Test
    void findById() {

        Sucursal sucursal = new Sucursal();
        sucursal.setIdProvedor(1);

        SucursalDTO dto = new SucursalDTO();

        ProveedorDTO proveedorDTO = new ProveedorDTO();
        proveedorDTO.setNombre("Proveedor Test");

        when(sucursalRepository.findById(1L))
                .thenReturn(Optional.of(sucursal));

        when(sucursalMapper.toDTO(sucursal))
                .thenReturn(dto);

        when(provedorFeign.buscarPorId(1))
                .thenReturn(proveedorDTO);

        SucursalDTO resultado = sucursalService.findById(1L);

        assertNotNull(resultado);

        verify(sucursalRepository).findById(1L);
        verify(provedorFeign).buscarPorId(1);
    }

    @Test
    void save() {

        Sucursal sucursal = new Sucursal();

        when(sucursalRepository.save(any(Sucursal.class)))
                .thenReturn(sucursal);

        Sucursal resultado = sucursalService.save(sucursal);

        assertNotNull(resultado);

        verify(sucursalRepository).save(sucursal);
    }

    @Test
    void delete() {

        when(sucursalRepository.existsById(1L))
                .thenReturn(true);

        sucursalService.delete(1L);

        verify(sucursalRepository).existsById(1L);
        verify(sucursalRepository).deleteById(1L);
    }

    @Test
    void update() {

        Sucursal existente = new Sucursal();

        Sucursal nueva = new Sucursal();
        nueva.setNombre("Nueva");
        nueva.setCalle("Providencia");
        nueva.setNroSucursal(10);
        nueva.setIdProvedor(1);

        when(sucursalRepository.findById(1L))
                .thenReturn(Optional.of(existente));

        when(sucursalRepository.save(any(Sucursal.class)))
                .thenReturn(existente);

        Sucursal resultado =
                sucursalService.update(1L, nueva);

        assertNotNull(resultado);

        verify(sucursalRepository).findById(1L);
        verify(sucursalRepository).save(any(Sucursal.class));
    }

    @Test
    void buscarPorNombre() {

        Sucursal sucursal = new Sucursal();

        when(sucursalRepository.findByNombre("Centro"))
                .thenReturn(List.of(sucursal));

        List<Sucursal> resultado =
                sucursalService.buscarPorNombre("Centro");

        assertEquals(1, resultado.size());
    }

    @Test
    void buscarPorCalle() {

        Sucursal sucursal = new Sucursal();

        when(sucursalRepository.findByCalleContainingIgnoreCase("Providencia"))
                .thenReturn(List.of(sucursal));

        List<Sucursal> resultado =
                sucursalService.buscarPorCalle("Providencia");

        assertEquals(1, resultado.size());
    }

    @Test
    void buscarPorNumero() {

        Sucursal sucursal = new Sucursal();

        when(sucursalRepository.findByNroSucursal(10))
                .thenReturn(List.of(sucursal));

        List<Sucursal> resultado =
                sucursalService.buscarPorNumero(10);

        assertEquals(1, resultado.size());
    }

    @Test
    void buscarPorProveedor() {

        Sucursal sucursal = new Sucursal();

        when(sucursalRepository.findByIdProvedor(1))
                .thenReturn(List.of(sucursal));

        List<Sucursal> resultado =
                sucursalService.buscarPorProveedor(1);

        assertEquals(1, resultado.size());
    }
}