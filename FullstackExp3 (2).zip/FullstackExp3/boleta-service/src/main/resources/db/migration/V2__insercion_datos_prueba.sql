INSERT INTO boleta (monto, fecha_Emision, iva) VALUES (10000, '2024-03-01', 1900);
INSERT INTO boleta (monto, fecha_Emision, iva) VALUES (25500, '2024-03-02', 4845);
INSERT INTO boleta (monto, fecha_Emision, iva) VALUES (5400, '2024-03-05', 1026);
INSERT INTO boleta (monto, fecha_Emision, iva) VALUES (120000, '2024-03-10', 22800);
INSERT INTO boleta (monto, fecha_Emision, iva) VALUES (8990, '2024-03-12', 1708);
