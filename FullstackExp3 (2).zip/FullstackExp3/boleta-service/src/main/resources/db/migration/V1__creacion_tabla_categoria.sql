create table boleta(
    id bigint auto_increment primary key,
    monto integer not null,
    fecha_Emision date not null,
    iva integer not null
)
