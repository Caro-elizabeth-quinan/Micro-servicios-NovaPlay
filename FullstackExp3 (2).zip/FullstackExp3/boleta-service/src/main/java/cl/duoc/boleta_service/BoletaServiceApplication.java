package cl.duoc.boleta_service;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

@OpenAPIDefinition(
		info = @Info(
				title = "API para gestión de Boletas",
				version = "1.0.1",
				description = "Servicio encargado de la emisión legal de documentos, cálculos impositivos y auditoría financiera de transacciones.",
				contact = @Contact(
						name = "Hans Araya",
						email = "ha.araya@duocuc.cl"
				)
		)
)
@EnableDiscoveryClient
@EnableFeignClients
@SpringBootApplication
public class BoletaServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BoletaServiceApplication.class, args);
	}

}
