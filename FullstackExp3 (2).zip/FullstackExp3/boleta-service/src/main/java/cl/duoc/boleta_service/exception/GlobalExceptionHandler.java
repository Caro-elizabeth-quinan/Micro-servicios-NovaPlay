package cl.duoc.boleta_service.exception;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

// Esta anotación convierte esta clase en un manejador global de excepciones.
// Captura errores de TODOS los controllers del proyecto.
@RestControllerAdvice
public class GlobalExceptionHandler {

    // ============================================
    // MANEJO ERROR 404 - NOT FOUND
    // ============================================

    // @ExceptionHandler indica qué excepción manejará este método.
    // En este caso, ResourceNotFoundException.
    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ErrorResponse> manejar404(

            // ex contiene la excepción lanzada
            ResourceNotFoundException ex,

            // request permite obtener información de la petición HTTP
            HttpServletRequest request
    ){

        // Creamos el objeto de respuesta personalizado
        ErrorResponse error = new ErrorResponse(

                // Fecha y hora actual del error
                LocalDateTime.now(),

                // Código HTTP 404
                HttpStatus.NOT_FOUND.value(),

                // Nombre del error HTTP
                "NOT FOUND",

                // Mensaje personalizado de la excepción
                ex.getMessage(),

                // Ruta que provocó el error
                request.getRequestURI()
        );

        // Retorna el JSON con status 404
        return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
    }


    // ============================================
    // MANEJO ERROR 400 - VALIDACIONES
    // ============================================

    // Captura errores provocados por @Valid
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<?> manejarValidaciones(
            // Contiene los errores de validación
            MethodArgumentNotValidException ex
    ){

        // Map para guardar campo + mensaje error
        Map<String, String> errores = new HashMap<>();

        // Recorremos todos los errores encontrados
        ex.getBindingResult().getFieldErrors().forEach(error -> {

            // Guardamos:
            // nombreCampo -> mensajeError
            errores.put(
                    error.getField(),
                    error.getDefaultMessage()
            );
        });

        // Retorna status 400 BAD REQUEST
        return new ResponseEntity<>(errores, HttpStatus.BAD_REQUEST);
    }


    // ============================================
    // MANEJO ERROR 500 - ERROR GENERAL
    // ============================================

    // Captura cualquier excepción NO controlada
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> manejar500(

            // Excepción general
            Exception ex,

            // Datos de la petición
            HttpServletRequest request
    ){

        // Creamos respuesta personalizada
        ErrorResponse error = new ErrorResponse(

                // Fecha del error
                LocalDateTime.now(),

                // Código HTTP 500
                HttpStatus.INTERNAL_SERVER_ERROR.value(),

                // Nombre del error
                "INTERNAL SERVER ERROR",

                // Mensaje de la excepción
                ex.getMessage(),

                // Endpoint que provocó el error
                request.getRequestURI()
        );

        // Retorna respuesta 500
        return new ResponseEntity<>(
                error,
                HttpStatus.INTERNAL_SERVER_ERROR
        );
    }
}
