package cl.duoc.boleta_service.boletaDTO;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.Data;

import java.time.LocalDate;

@Data
@Schema(description = "Estructura de entrada para la creación o actualización de una Boleta")
public class BoletaInputDTO {

    @Schema(description = "Monto total de la transacción", example = "15000")
    @NotNull(message = "El campo monto no puede estar vacio")
    @PositiveOrZero(message = "El monto debe ser un valor positivo o cero")
    private Integer monto;

    @Schema(description = "Fecha de emisión del documento", example = "2026-06-20")
    @NotNull(message = "El campo fecha Emision no puede estar vacio")
    private LocalDate fechaEmision;

    @Schema(description = "Valor porcentual o absoluto del IVA aplicado", example = "19")
    @NotNull(message = "El campo IVA no puede estar vacio")
    @PositiveOrZero(message = "El IVA no puede ser un valor negativo")
    private Integer iva;
}