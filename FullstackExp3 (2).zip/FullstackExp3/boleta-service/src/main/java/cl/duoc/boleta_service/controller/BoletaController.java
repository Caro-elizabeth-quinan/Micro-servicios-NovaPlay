package cl.duoc.boleta_service.controller;

import cl.duoc.boleta_service.boletaDTO.BoletaDTO;
import cl.duoc.boleta_service.boletaDTO.BoletaInputDTO;
import cl.duoc.boleta_service.model.Boleta;
import cl.duoc.boleta_service.service.BoletaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("api/v1/boletas")
@Tag(name = "Boletas", description = "API para la emisión, control financiero y generación de reportes de boletas")
public class BoletaController {

    @Autowired
    private BoletaService boletaService;

    @Operation(
            summary = "Buscar boleta por ID",
            description = "Obtiene los detalles estructurados de una boleta mediante su identificador único."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Boleta localizada con éxito",
            content = @Content(mediaType = "application/json", schema = @Schema(implementation = BoletaDTO.class))
    )
    @ApiResponse(responseCode = "404", description = "La boleta solicitada no existe")
    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(
            @Parameter(description = "ID único de la boleta", example = "1")
            @PathVariable Long id
    ) {
        BoletaDTO dto = boletaService.findById(id);
        if (dto == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(dto);
    }

    @Operation(
            summary = "Actualizar boleta",
            description = "Modifica los datos financieros de una boleta existente localizándola por su ID."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Documento actualizado correctamente",
            content = @Content(mediaType = "application/json", schema = @Schema(implementation = Boleta.class))
    )
    @ApiResponse(responseCode = "404", description = "No se encontró el registro para actualizar")
    @PutMapping("/{id}")
    public ResponseEntity<?> actualizar(
            @PathVariable Long id,
            @Valid @RequestBody BoletaInputDTO input
    ) {
        Boleta boleta = new Boleta();
        boleta.setMonto(input.getMonto());
        boleta.setFechaEmision(input.getFechaEmision());
        boleta.setIva(input.getIva());

        Boleta actualizada = boletaService.update(id, boleta);
        if (actualizada == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(actualizada);
    }

    @Operation(
            summary = "Eliminar boleta",
            description = "Remueve un registro de boleta del sistema a partir de su ID."
    )
    @ApiResponse(responseCode = "204", description = "Boleta removida con éxito (Sin contenido)")
    @ApiResponse(responseCode = "500", description = "Error interno o validación de antigüedad fallida")
    @DeleteMapping("/{id}")
    public ResponseEntity<?> borrar(@PathVariable Long id) {
        try {
            boletaService.delete(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @Operation(
            summary = "Listar boletas",
            description = "Obtiene el historial completo de boletas emitidas registradas en el sistema."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Listado de boletas recuperado",
            content = @Content(array = @ArraySchema(schema = @Schema(implementation = Boleta.class)))
    )
    @GetMapping
    public ResponseEntity<List<Boleta>> listar() {
        return ResponseEntity.ok(boletaService.findAll());
    }

    @Operation(
            summary = "Registrar boleta",
            description = "Crea una nueva boleta calculando y verificando montos e IVA asociados."
    )
    @ApiResponse(
            responseCode = "201",
            description = "Boleta generada y guardada exitosamente",
            content = @Content(mediaType = "application/json", schema = @Schema(implementation = Boleta.class))
    )
    @PostMapping
    public ResponseEntity<Boleta> registrar(@Valid @RequestBody BoletaInputDTO input) {
        Boleta boleta = new Boleta();
        boleta.setMonto(input.getMonto());
        boleta.setFechaEmision(input.getFechaEmision());
        boleta.setIva(input.getIva());

        Boleta nueva = boletaService.save(boleta);
        return new ResponseEntity<>(nueva, HttpStatus.CREATED);
    }

    @Operation(
            summary = "Reporte por rango de fechas",
            description = "Genera una lista de boletas comprendidas dentro de un intervalo temporal específico."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Reporte de rango generado",
            content = @Content(array = @ArraySchema(schema = @Schema(implementation = Boleta.class)))
    )
    @GetMapping("/reporte-rango")
    public ResponseEntity<List<Boleta>> buscarRangoFechas(
            @Parameter(description = "Fecha de inicio del reporte (yyyy-MM-dd)", example = "2026-01-01")
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate inicio,
            @Parameter(description = "Fecha de término del reporte (yyyy-MM-dd)", example = "2026-06-30")
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fin
    ) {
        return ResponseEntity.ok(boletaService.buscarRangoFechas(inicio, fin));
    }

    @Operation(
            summary = "Buscar por monto mínimo",
            description = "Filtra todas aquellas boletas cuyo monto sea mayor o igual al valor provisto."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Registros que igualan o superan el monto",
            content = @Content(array = @ArraySchema(schema = @Schema(implementation = Boleta.class)))
    )
    @GetMapping("/monto/{monto}")
    public ResponseEntity<List<Boleta>> buscarPorMontoMinimo(
            @Parameter(description = "Monto mínimo límite de consulta", example = "5000")
            @PathVariable int monto
    ) {
        return ResponseEntity.ok(boletaService.buscarPorMontoMinimo(monto));
    }

    @Operation(
            summary = "Buscar por IVA",
            description = "Filtra las boletas almacenadas según un valor específico de IVA."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Coincidencias de IVA localizadas",
            content = @Content(array = @ArraySchema(schema = @Schema(implementation = Boleta.class)))
    )
    @GetMapping("/iva/{iva}")
    public ResponseEntity<List<Boleta>> buscarPorIva(
            @Parameter(description = "Porcentaje de IVA exacto a consultar", example = "19")
            @PathVariable int iva
    ) {
        return ResponseEntity.ok(boletaService.buscarPorIva(iva));
    }

    @Operation(
            summary = "Buscar por fecha de emisión",
            description = "Busca los documentos generados en un día específico del año."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Documentos localizados para el día indicado",
            content = @Content(array = @ArraySchema(schema = @Schema(implementation = Boleta.class)))
    )
    @GetMapping("/buscar-por-fecha")
    public ResponseEntity<List<Boleta>> buscarPorFecha(
            @Parameter(description = "Día exacto de emisión (yyyy-MM-dd)", example = "2026-06-20")
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fecha
    ) {
        return ResponseEntity.ok(boletaService.buscarPorFecha(fecha));
    }
}