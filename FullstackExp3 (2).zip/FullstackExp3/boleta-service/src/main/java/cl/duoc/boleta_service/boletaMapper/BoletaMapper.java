package cl.duoc.boleta_service.boletaMapper;

import cl.duoc.boleta_service.boletaDTO.BoletaDTO;
import cl.duoc.boleta_service.model.Boleta;
import org.springframework.stereotype.Component;

@Component
public class BoletaMapper {


    public BoletaDTO toDTO(Boleta boleta) {
        if (boleta == null) return null;
        BoletaDTO dto = new BoletaDTO();
        dto.setId(boleta.getId());
        dto.setMonto(boleta.getMonto());
        dto.setIva(boleta.getIva() + "%");
        dto.setFechaEmision(boleta.getFechaEmision());
        return dto;
    }
}
