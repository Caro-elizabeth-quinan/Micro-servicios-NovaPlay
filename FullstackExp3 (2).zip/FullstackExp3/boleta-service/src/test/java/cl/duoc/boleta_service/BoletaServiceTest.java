package cl.duoc.boleta_service.service;

import cl.duoc.boleta_service.boletaDTO.BoletaDTO;
import cl.duoc.boleta_service.boletaMapper.BoletaMapper;
import cl.duoc.boleta_service.model.Boleta;
import cl.duoc.boleta_service.repository.BoletaRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BoletaServiceTest {

    @Mock
    private BoletaRepository boletaRepository;

    @Mock
    private BoletaMapper boletaMapper;

    @InjectMocks
    private BoletaService boletaService;

    private Boleta boleta;

    @BeforeEach
    void setUp() {
        boleta = new Boleta();
        boleta.setId(1L);
        boleta.setMonto(10000);
        boleta.setIva(19);
        boleta.setFechaEmision(LocalDate.now());
    }

    // ---------------- FIND ALL ----------------
    @Test
    void testFindAll() {
        when(boletaRepository.findAll()).thenReturn(List.of(boleta));

        List<Boleta> result = boletaService.findAll();

        assertEquals(1, result.size());
        verify(boletaRepository, times(1)).findAll();
    }

    // ---------------- FIND BY ID ----------------
    @Test
    void testFindById() {
        BoletaDTO dto = new BoletaDTO();
        dto.setId(1L);

        when(boletaRepository.findById(1L)).thenReturn(Optional.of(boleta));
        when(boletaMapper.toDTO(boleta)).thenReturn(dto);

        BoletaDTO result = boletaService.findById(1L);

        assertNotNull(result);
        assertEquals(1L, result.getId());
        verify(boletaRepository).findById(1L);
        verify(boletaMapper).toDTO(boleta);
    }

    // ---------------- SAVE ----------------
    @Test
    void testSave() {
        when(boletaRepository.save(boleta)).thenReturn(boleta);

        Boleta result = boletaService.save(boleta);

        assertNotNull(result);
        verify(boletaRepository).save(boleta);
    }

    // ---------------- UPDATE ----------------
    @Test
    void testUpdate() {
        Boleta updated = new Boleta();
        updated.setMonto(20000);
        updated.setIva(10);
        updated.setFechaEmision(LocalDate.now());

        when(boletaRepository.findById(1L)).thenReturn(Optional.of(boleta));
        when(boletaRepository.save(any(Boleta.class))).thenReturn(boleta);

        Boleta result = boletaService.update(1L, updated);

        assertNotNull(result);
        verify(boletaRepository).findById(1L);
        verify(boletaRepository).save(any(Boleta.class));
    }

    // ---------------- DELETE ----------------
    @Test
    void testDelete() {
        when(boletaRepository.existsById(1L)).thenReturn(true);
        doNothing().when(boletaRepository).deleteById(1L);

        assertDoesNotThrow(() -> boletaService.delete(1L));

        verify(boletaRepository).deleteById(1L);
    }

    @Test
    void testDelete_BoletaNoExiste() {
        when(boletaRepository.existsById(1L)).thenReturn(false);

        RuntimeException exception = assertThrows(RuntimeException.class,
                () -> boletaService.delete(1L));

        assertEquals("Boleta no encontrada", exception.getMessage());
    }

    // ---------------- BUSQUEDAS ----------------
    @Test
    void testBuscarPorFecha() {
        when(boletaRepository.findByFechaEmision(any()))
                .thenReturn(List.of(boleta));

        List<Boleta> result = boletaService.buscarPorFecha(LocalDate.now());

        assertFalse(result.isEmpty());
        verify(boletaRepository).findByFechaEmision(any());
    }

    @Test
    void testBuscarPorMontoMinimo() {
        when(boletaRepository.findByMontoGreaterThanEqual(1000))
                .thenReturn(List.of(boleta));

        List<Boleta> result = boletaService.buscarPorMontoMinimo(1000);

        assertEquals(1, result.size());
    }

    @Test
    void testBuscarPorIva() {
        when(boletaRepository.findByIva(19))
                .thenReturn(List.of(boleta));

        List<Boleta> result = boletaService.buscarPorIva(19);

        assertEquals(1, result.size());
    }
}