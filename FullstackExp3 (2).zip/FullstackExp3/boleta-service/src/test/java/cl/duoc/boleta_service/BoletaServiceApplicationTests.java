package cl.duoc.boleta_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoletaServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
