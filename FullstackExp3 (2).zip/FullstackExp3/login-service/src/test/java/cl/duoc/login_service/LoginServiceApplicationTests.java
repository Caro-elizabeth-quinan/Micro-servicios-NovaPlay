package cl.duoc.login_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
