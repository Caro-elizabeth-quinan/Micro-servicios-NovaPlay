package cl.duoc.login_service;

import cl.duoc.login_service.dto.LoginDTO;
import cl.duoc.login_service.mapper.LoginMapper;
import cl.duoc.login_service.model.Login;
import cl.duoc.login_service.repository.LoginRepository;
import cl.duoc.login_service.service.LoginService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
class LoginServiceTest {

    @Mock
    private LoginRepository loginRepository;

    @Mock
    private LoginMapper loginMapper;

    @InjectMocks
    private LoginService loginService;

    @Test
    void findAll() {

        Login login = new Login();
        login.setEmail("test@correo.cl");

        when(loginRepository.findAll())
                .thenReturn(List.of(login));

        List<Login> resultado = loginService.findAll();

        assertNotNull(resultado);
        assertEquals(1, resultado.size());

        verify(loginRepository).findAll();
    }

    @Test
    void findById() {

        Login login = new Login();
        login.setEmail("test@correo.cl");

        LoginDTO dto = new LoginDTO();
        dto.setEmail("test@correo.cl");

        when(loginRepository.findById(1L))
                .thenReturn(Optional.of(login));

        when(loginMapper.toDTO(login))
                .thenReturn(dto);

        LoginDTO resultado = loginService.findById(1L);

        assertNotNull(resultado);
        assertEquals("test@correo.cl", resultado.getEmail());

        verify(loginRepository).findById(1L);
    }

    @Test
    void save() {

        Login login = new Login();
        login.setEmail("test@correo.cl");

        when(loginRepository.save(any(Login.class)))
                .thenReturn(login);

        Login resultado = loginService.save(login);

        assertNotNull(resultado);

        verify(loginRepository).save(login);
    }

    @Test
    void delete() {

        when(loginRepository.existsById(1L))
                .thenReturn(true);

        loginService.delete(1L);

        verify(loginRepository).existsById(1L);
        verify(loginRepository).deleteById(1L);
    }

    @Test
    void update() {

        Login existente = new Login();

        Login nuevo = new Login();
        nuevo.setEmail("nuevo@correo.cl");
        nuevo.setContrasena("123456");

        when(loginRepository.findById(1L))
                .thenReturn(Optional.of(existente));

        when(loginRepository.save(any(Login.class)))
                .thenReturn(existente);

        Login resultado =
                loginService.update(1L, nuevo);

        assertNotNull(resultado);

        verify(loginRepository).findById(1L);
        verify(loginRepository).save(any(Login.class));
    }

    @Test
    void buscarPorEmail() {

        Login login = new Login();
        login.setEmail("test@correo.cl");

        when(loginRepository.findByEmail("test@correo.cl"))
                .thenReturn(Optional.of(login));

        Login resultado =
                loginService.buscarPorEmail("test@correo.cl");

        assertNotNull(resultado);
        assertEquals("test@correo.cl", resultado.getEmail());

        verify(loginRepository)
                .findByEmail("test@correo.cl");
    }
}