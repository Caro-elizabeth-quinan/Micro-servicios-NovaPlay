create table login(
    id bigint auto_increment primary key,
    email varchar(50) not null,
    contrasena varchar(30) not null
)
