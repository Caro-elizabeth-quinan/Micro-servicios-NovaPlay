package cl.duoc.login_service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
@Schema(description = "Estructura de entrada para crear o actualizar credenciales de acceso")
public class LoginInputDTO {

    @Schema(description = "Nombre de usuario o identificador único de cuenta", example = "cquinan")
    @NotBlank(message = "El nombre de usuario no puede estar vacío")
    @Size(min = 4, max = 20, message = "El usuario debe tener entre 4 y 20 caracteres")
    private String username;

    @Schema(description = "Contraseña privada de acceso", example = "ClaveSegura123")
    @NotBlank(message = "La contraseña es un campo obligatorio")
    @Size(min = 6, message = "La contraseña debe contener un mínimo de 6 caracteres")
    private String password;

    @Schema(description = "Correo electrónico institucional o personal", example = "ca.quinan@duocuc.cl")
    @NotBlank(message = "El correo electrónico no puede estar vacío")
    @Email(message = "Debe proporcionar una estructura de correo electrónico válida")
    private String email;
}