package cl.duoc.login_service.dto;


import lombok.Data;

@Data
public class LoginDTO {
    private String email;
}
