package cl.duoc.login_service.service;


import cl.duoc.login_service.dto.LoginDTO;
import cl.duoc.login_service.exception.ResourceNotFoundException;
import cl.duoc.login_service.mapper.LoginMapper;
import cl.duoc.login_service.model.Login;
import cl.duoc.login_service.repository.LoginRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class LoginService {


    @Autowired
    private LoginRepository loginRepository;

    @Autowired
    private LoginMapper loginMapper;

    public List<Login> findAll() {return loginRepository.findAll();
    }

    public LoginDTO findById(Long id) {
        // Busca login por id.
        // Si no existe, lanza excepción 404.
        Login login = loginRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Login no encontrado con id: " + id)
                );
        // Convierte entity a DTO
        return loginMapper.toDTO(login);
    }

    public Login save(Login login) {
        return loginRepository.save(login);
    }

    public void delete(Long id){
        // Verifica si el login existe
        if(!loginRepository.existsById(id)){
            // Lanza error 404
            throw new ResourceNotFoundException(
                    "Login no encontrado con id: " + id
            );
        }

        loginRepository.deleteById(id);
    }

    public Login update(Long id, Login login) {
        // Busca login por id.
        // Si no existe, lanza excepción personalizada.
        Login loginActualizado = loginRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Login no encontrado con id: " + id)
                );
        // Actualiza campos
        loginActualizado.setEmail(login.getEmail());
        loginActualizado.setContrasena(login.getContrasena());
        // Guarda cambios
        return loginRepository.save(loginActualizado);
    }

    public Login buscarPorEmail(String email) {

        return loginRepository.findByEmail(email)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Login no encontrado con email: " + email
                        )
                );
    }
}
