package cl.duoc.login_service.repository;


import cl.duoc.login_service.model.Login;
import cl.duoc.login_service.service.LoginService;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface LoginRepository extends JpaRepository<Login,Long> {
    Optional<Login> findByEmail(String email);
}
