package cl.duoc.login_service.mapper;

import cl.duoc.login_service.dto.LoginDTO;
import cl.duoc.login_service.model.Login;
import org.springframework.stereotype.Component;

@Component
public class LoginMapper {


    public LoginDTO toDTO(Login login){
        if ( login == null ) return null;
        LoginDTO dto = new LoginDTO();
        dto.setEmail(login.getEmail());
        return dto;
    }
}
