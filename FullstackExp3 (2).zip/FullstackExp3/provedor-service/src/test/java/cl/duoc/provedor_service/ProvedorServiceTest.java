package cl.duoc.provedor_service;

import cl.duoc.provedor_service.dto.ProveedorDTO;
import cl.duoc.provedor_service.mapper.ProveedorMapper;
import cl.duoc.provedor_service.model.Proveedor;
import cl.duoc.provedor_service.repository.ProveedorRepository;
import cl.duoc.provedor_service.service.ProveedorService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
class ProveedorServiceTest {

    @Mock
    private ProveedorRepository proveedorRepository;

    @Mock
    private ProveedorMapper proveedorMapper;

    @InjectMocks
    private ProveedorService proveedorService;

    @Test
    void findAll() {

        Proveedor proveedor = new Proveedor();
        proveedor.setNombre("Sony");

        when(proveedorRepository.findAll())
                .thenReturn(List.of(proveedor));

        List<Proveedor> resultado = proveedorService.findAll();

        assertNotNull(resultado);
        assertEquals(1, resultado.size());

        verify(proveedorRepository).findAll();
    }

    @Test
    void save() {

        Proveedor proveedor = new Proveedor();
        proveedor.setRut("11.111.111-1");

        when(proveedorRepository.existsByRut("11.111.111-1"))
                .thenReturn(false);

        when(proveedorRepository.save(any(Proveedor.class)))
                .thenReturn(proveedor);

        Proveedor resultado = proveedorService.save(proveedor);

        assertNotNull(resultado);

        verify(proveedorRepository).existsByRut("11.111.111-1");
        verify(proveedorRepository).save(proveedor);
    }

    @Test
    void findById() {

        Proveedor proveedor = new Proveedor();
        proveedor.setRut("11.111.111-1");

        ProveedorDTO dto = new ProveedorDTO();
        dto.setRut("11.111.111-1");

        when(proveedorRepository.findById(1L))
                .thenReturn(Optional.of(proveedor));

        when(proveedorMapper.toDTO(proveedor))
                .thenReturn(dto);

        ProveedorDTO resultado = proveedorService.findById(1L);

        assertNotNull(resultado);

        verify(proveedorRepository).findById(1L);
    }

    @Test
    void delete() {

        when(proveedorRepository.existsById(1L))
                .thenReturn(true);

        proveedorService.delete(1L);

        verify(proveedorRepository).existsById(1L);
        verify(proveedorRepository).deleteById(1L);
    }

    @Test
    void update() {

        Proveedor existente = new Proveedor();

        Proveedor nuevo = new Proveedor();
        nuevo.setRut("22.222.222-2");
        nuevo.setNombre("Nintendo");
        nuevo.setDireccion("Santiago");

        when(proveedorRepository.findById(1L))
                .thenReturn(Optional.of(existente));

        when(proveedorRepository.save(any(Proveedor.class)))
                .thenReturn(existente);

        Proveedor resultado =
                proveedorService.update(1L, nuevo);

        assertNotNull(resultado);

        verify(proveedorRepository).findById(1L);
        verify(proveedorRepository).save(any(Proveedor.class));
    }

    @Test
    void findByRut() {

        Proveedor proveedor = new Proveedor();
        proveedor.setRut("11.111.111-1");

        ProveedorDTO dto = new ProveedorDTO();
        dto.setRut("11.111.111-1");

        when(proveedorRepository.findByRut("11.111.111-1"))
                .thenReturn(Optional.of(proveedor));

        when(proveedorMapper.toDTO(proveedor))
                .thenReturn(dto);

        ProveedorDTO resultado =
                proveedorService.findByRut("11.111.111-1");

        assertNotNull(resultado);

        verify(proveedorRepository)
                .findByRut("11.111.111-1");
    }

    @Test
    void findByNombre() {

        Proveedor proveedor = new Proveedor();
        proveedor.setNombre("Sony");

        when(proveedorRepository.findByNombreContainingIgnoreCase("Sony"))
                .thenReturn(List.of(proveedor));

        List<Proveedor> resultado =
                proveedorService.findByNombre("Sony");

        assertEquals(1, resultado.size());

        verify(proveedorRepository)
                .findByNombreContainingIgnoreCase("Sony");
    }

    @Test
    void existePorRut() {

        when(proveedorRepository.existsByRut("11.111.111-1"))
                .thenReturn(true);

        boolean resultado =
                proveedorService.existePorRut("11.111.111-1");

        assertTrue(resultado);

        verify(proveedorRepository)
                .existsByRut("11.111.111-1");
    }
}