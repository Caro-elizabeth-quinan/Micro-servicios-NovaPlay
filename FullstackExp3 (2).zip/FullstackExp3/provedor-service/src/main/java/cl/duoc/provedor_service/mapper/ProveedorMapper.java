package cl.duoc.provedor_service.mapper;

import cl.duoc.provedor_service.dto.ProveedorDTO;
import cl.duoc.provedor_service.model.Proveedor;
import org.springframework.stereotype.Component;

@Component
public class ProveedorMapper {
    public ProveedorDTO toDTO(Proveedor proveedor){
        ProveedorDTO dto = new ProveedorDTO();
        dto.setRut(proveedor.getRut());
        dto.setNombre(proveedor.getNombre());
        dto.setDireccion(proveedor.getDireccion());

        return dto;
    }
}
