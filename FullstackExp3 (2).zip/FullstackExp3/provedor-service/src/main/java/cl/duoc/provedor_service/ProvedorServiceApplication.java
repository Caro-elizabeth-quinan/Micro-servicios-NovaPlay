package cl.duoc.provedor_service;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

@OpenAPIDefinition(
		info = @Info(
				title = "API para gestión de Proveedores",
				version = "1.0.1",
				description = "API que gestiona el catálogo de proveedores, permitiendo la administración de sus datos comerciales y búsquedas avanzadas por RUT o nombre.",
				contact = @Contact(
						name = "Raysa Aguilera Muñoz",
						email = "ray.aguilera@duocuc.cl"
				)
		)
)
@EnableDiscoveryClient
@EnableFeignClients
@SpringBootApplication
public class ProvedorServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProvedorServiceApplication.class, args);
	}

}
