package cl.duoc.provedor_service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
@Schema(description = "Estructura de entrada para los datos de un Proveedor")
public class ProveedorInputDTO {

    @Schema(description = "RUT único del proveedor", example = "76.123.456-7")
    @NotBlank(message = "El campo rut no puede estar vacio")
    private String rut;

    @Schema(description = "Nombre de la empresa o proveedor", example = "Proveedor Mayorista SpA")
    @NotBlank(message = "El campo nombre no puede estar vacio")
    @Size(min = 3, max = 50, message = "El nombre debe tener entre 3 y 50 caracteres")
    private String nombre;

    @Schema(description = "Dirección de la casa matriz", example = "Av. Libertador Bernardo O'Higgins 1234")
    @NotBlank(message = "El campo direccion no puede estar vacio")
    @Size(min = 3, max = 50, message = "La dirección debe tener entre 3 y 50 caracteres")
    private String direccion;
}
