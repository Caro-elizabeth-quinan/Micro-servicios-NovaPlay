package cl.duoc.provedor_service.service;

import cl.duoc.provedor_service.dto.ProveedorDTO;
import cl.duoc.provedor_service.exception.ResourceNotFoundException;
import cl.duoc.provedor_service.mapper.ProveedorMapper;
import cl.duoc.provedor_service.model.Proveedor;
import cl.duoc.provedor_service.repository.ProveedorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

import static org.springframework.data.jpa.domain.AbstractPersistable_.id;

@Service
public class ProveedorService {
    @Autowired
    private ProveedorRepository proveedorRepository;

    @Autowired
    private ProveedorMapper proveedorMapper;

    public List<Proveedor> findAll(){
        return proveedorRepository.findAll();
    }

    // Consulta 3: Validación de existencia para evitar duplicados
    public Proveedor save(Proveedor proveedor){
        if(proveedorRepository.existsByRut(proveedor.getRut())){
            throw new RuntimeException("El RUT ya se encuentra registrado");
        }
        return proveedorRepository.save(proveedor);
    }

    // Corregido: Evita NullPointerException usando el Mapper
    // Busca proveedor por id
    // Si no existe, lanza error 404
    public ProveedorDTO findById(Long id){
        Proveedor proveedor = proveedorRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Proveedor no encontrado con id: " + id)
                );
        // Convierte entity a DTO
        return proveedorMapper.toDTO(proveedor);
    }


    // Elimina proveedor
    // Si no existe, lanza error 404
    public void delete(Long id){

        // Verifica existencia
        if(!proveedorRepository.existsById(id)){

            throw new ResourceNotFoundException(
                    "Proveedor no encontrado con id: " + id
            );
        }

        proveedorRepository.deleteById(id);
    }


    // Actualiza proveedor existente
    // Si no existe, lanza error 404
    public Proveedor update(Long id, Proveedor proveedor){

        Proveedor p = proveedorRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Proveedor no encontrado con id: " + id
                        )
                );

        // Actualiza campos
        p.setRut(proveedor.getRut());
        p.setNombre(proveedor.getNombre());
        p.setDireccion(proveedor.getDireccion());

        // Guarda cambios
        return proveedorRepository.save(p);
    }

    // Consulta 1: Buscar por RUT exacto
    // Busca proveedor por rut exacto
    // Si no existe, lanza error 404
    public ProveedorDTO findByRut(String rut){
        Proveedor proveedor = proveedorRepository.findByRut(rut)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Proveedor no encontrado con rut: " + rut
                        )
                );

        // Convierte entity a DTO
        return proveedorMapper.toDTO(proveedor);
    }

    // Consulta 2: Buscar por nombre parcial
    public List<Proveedor> findByNombre(String nombre){
        return proveedorRepository.findByNombreContainingIgnoreCase(nombre);
    }

    // Método adicional para el controlador si quieres validar existencia pura
    public boolean existePorRut(String rut) {
        return proveedorRepository.existsByRut(rut);
    }


}
