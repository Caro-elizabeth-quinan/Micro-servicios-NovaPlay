package cl.duoc.provedor_service.controller;

import cl.duoc.provedor_service.dto.ProveedorDTO;
import cl.duoc.provedor_service.dto.ProveedorInputDTO;
import cl.duoc.provedor_service.exception.ErrorResponse;
import cl.duoc.provedor_service.model.Proveedor;
import cl.duoc.provedor_service.service.ProveedorService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/v1/proveedores")
@Tag(name = "Proveedor", description = "API para la administración y consultas del catálogo de proveedores")
public class ProveedorControler {

    @Autowired
    private ProveedorService proveedorService;

    @Operation(
            summary = "Buscar proveedor por ID",
            description = "Busca un proveedor específico utilizando su identificador único y lo retorna mapeado a DTO."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Proveedor DTO encontrado",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ProveedorDTO.class),
                    examples = @ExampleObject(
                            name = "Ejemplo DTO",
                            value = "{\n  \"rut\": \"76.123.456-7\",\n  \"nombre\": \"Proveedor Mayorista SpA\",\n  \"direccion\": \"Santiago Centro\"\n}"
                    )
            )
    )
    @ApiResponse(
            responseCode = "404",
            description = "Proveedor no encontrado",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = @ExampleObject(
                            name = "Error: ID Inexistente",
                            value = "{\n  \"fecha\": \"2026-06-20T18:50:00\",\n  \"status\": 404,\n  \"error\": \"Not Found\",\n  \"mensaje\": \"Proveedor no encontrado con id: 99\",\n  \"path\": \"/api/v1/proveedores/99\"\n}"
                    )
            )
    )
    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(
            @Parameter(description = "ID del proveedor", example = "1")
            @PathVariable Long id
    ) {
        return ResponseEntity.ok(proveedorService.findById(id));
    }

    @Operation(
            summary = "Actualizar proveedor",
            description = "Modifica los datos comerciales de un proveedor existente localizándolo por su ID."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Proveedor actualizado exitosamente",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = Proveedor.class)
            )
    )
    @ApiResponse(
            responseCode = "400",
            description = "Estructura de la solicitud inválida o validaciones fallidas",
            content = @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))
    )
    @ApiResponse(
            responseCode = "404",
            description = "Proveedor no encontrado para actualizar",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = @ExampleObject(
                            name = "Error: Actualización Fallida",
                            value = "{\n  \"fecha\": \"2026-06-20T18:52:00\",\n  \"status\": 404,\n  \"error\": \"Not Found\",\n  \"mensaje\": \"Proveedor no encontrado con id: 88\",\n  \"path\": \"/api/v1/proveedores/88\"\n}"
                    )
            )
    )
    @PutMapping("/{id}")
    public ResponseEntity<?> actualizar(
            @PathVariable Long id,
            @Valid @RequestBody ProveedorInputDTO input
    ) {
        Proveedor proveedor = new Proveedor();
        proveedor.setRut(input.getRut());
        proveedor.setNombre(input.getNombre());
        proveedor.setDireccion(input.getDireccion());

        return ResponseEntity.ok(proveedorService.update(id, proveedor));
    }

    @Operation(
            summary = "Eliminar proveedor",
            description = "Remueve un proveedor del sistema mediante su identificador numérico."
    )
    @ApiResponse(
            responseCode = "204",
            description = "Vendedor eliminado correctamente (Sin contenido)",
            content = @Content(mediaType = "application/json", schema = @Schema(hidden = true))
    )
    @ApiResponse(
            responseCode = "404",
            description = "Vendedor no encontrado para eliminar",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = @ExampleObject(
                            name = "Error: Eliminación Fallida",
                            value = "{\n  \"fecha\": \"2026-06-20T17:55:00\",\n  \"status\": 404,\n  \"error\": \"Not Found\",\n  \"mensaje\": \"Proveedor no encontrado con id: 99\",\n  \"path\": \"/api/v1/proveedores/99\"\n}"
                    )
            )
    )
    @DeleteMapping("/{id}")
    public ResponseEntity<?> borrar(@PathVariable Long id) {
        proveedorService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @Operation(
            summary = "Listar proveedores",
            description = "Método que obtiene la lista completa de todas las entidades proveedor registradas en la base de datos."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Lista de proveedores recuperada con éxito",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = Proveedor.class)),
                    examples = @ExampleObject(
                            name = "Ejemplo Lista",
                            value = "[\n  { \"id\": 1, \"rut\": \"76.123.456-7\", \"nombre\": \"Proveedor Mayorista SpA\", \"direccion\": \"Santiago Centro\" }\n]"
                    )
            )
    )
    @GetMapping
    public ResponseEntity<?> listar() {
        return ResponseEntity.ok(proveedorService.findAll());
    }

    @Operation(
            summary = "Registrar proveedor",
            description = "Registra un nuevo proveedor en la base de datos asegurando que el RUT no esté duplicado."
    )
    @ApiResponse(
            responseCode = "201",
            description = "Proveedor registrado exitosamente",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = Proveedor.class),
                    examples = @ExampleObject(
                            name = "Proveedor Creado",
                            value = "{ \"id\": 3, \"rut\": \"77.987.654-3\", \"nombre\": \"Distribuidora Nacional S.A.\", \"direccion\": \"Providencia\" }"
                    )
            )
    )
    @ApiResponse(
            responseCode = "400",
            description = "Datos de entrada inválidos o RUT ya registrado en el sistema",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = @ExampleObject(
                            name = "Error: RUT Duplicado",
                            value = "{\n  \"fecha\": \"2026-06-20T18:56:00\",\n  \"status\": 400,\n  \"error\": \"Bad Request\",\n  \"mensaje\": \"El RUT ya se encuentra registrado\",\n  \"path\": \"/api/v1/proveedores\"\n}"
                    )
            )
    )
    @PostMapping
    public ResponseEntity<?> registrar(@Valid @RequestBody ProveedorInputDTO input) {
        Proveedor proveedor = new Proveedor();
        proveedor.setRut(input.getRut());
        proveedor.setNombre(input.getNombre());
        proveedor.setDireccion(input.getDireccion());

        Proveedor nuevo = proveedorService.save(proveedor);
        return new ResponseEntity<>(nuevo, HttpStatus.CREATED);
    }

    @Operation(
            summary = "Buscar por RUT",
            description = "Busca un proveedor por su RUT exacto y devuelve su información resumida en un DTO."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Proveedor encontrado por su RUT",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ProveedorDTO.class),
                    examples = @ExampleObject(
                            name = "Ejemplo DTO por RUT",
                            value = "{\n  \"rut\": \"76.123.456-7\",\n  \"nombre\": \"Proveedor Mayorista SpA\",\n  \"direccion\": \"Santiago Centro\"\n}"
                    )
            )
    )
    @ApiResponse(
            responseCode = "404",
            description = "Proveedor no encontrado con el RUT ingresado",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = @ExampleObject(
                            name = "Error: RUT Inexistente",
                            value = "{\n  \"fecha\": \"2026-06-20T18:58:00\",\n  \"status\": 404,\n  \"error\": \"Not Found\",\n  \"mensaje\": \"Proveedor no encontrado con rut: 11.111.111-1\",\n  \"path\": \"/api/v1/proveedores/rut/11.111.111-1\"\n}"
                    )
            )
    )
    @GetMapping("/rut/{rut}")
    public ResponseEntity<?> buscarPorRut(
            @Parameter(description = "RUT exacto del proveedor", example = "76.123.456-7")
            @PathVariable String rut
    ) {
        return ResponseEntity.ok(proveedorService.findByRut(rut));
    }

    @Operation(
            summary = "Buscar proveedores por nombre",
            description = "Filtra y obtiene una lista de proveedores cuyo nombre contenga la cadena buscada (Case Insensitive)."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Proveedores que coinciden con el criterio de búsqueda encontrados",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = Proveedor.class)),
                    examples = @ExampleObject(
                            name = "Coincidencias de Nombre",
                            value = "[\n  { \"id\": 1, \"rut\": \"76.123.456-7\", \"nombre\": \"Proveedor Mayorista SpA\", \"direccion\": \"Santiago Centro\" }\n]"
                    )
            )
    )
    @ApiResponse(
            responseCode = "404",
            description = "No se encontraron proveedores con ese criterio de nombre",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = @ExampleObject(
                            name = "Error: Sin Coincidencias",
                            value = "{\n  \"fecha\": \"2026-06-20T19:00:00\",\n  \"status\": 404,\n  \"error\": \"Not Found\",\n  \"mensaje\": \"No se encontraron proveedores que coincidan con el nombre especificado\",\n  \"path\": \"/api/v1/proveedores/buscar\"\n}"
                    )
            )
    )
    @GetMapping("/buscar")
    public ResponseEntity<?> buscarPorNombre(@RequestParam String nombre) {
        List<Proveedor> lista = proveedorService.findByNombre(nombre);
        if (lista.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return ResponseEntity.ok(lista);
    }
}