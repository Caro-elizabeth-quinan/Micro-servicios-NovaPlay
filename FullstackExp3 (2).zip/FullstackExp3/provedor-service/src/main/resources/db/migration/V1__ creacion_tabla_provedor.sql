create table proveedor(
    id bigint auto_increment primary key,
    rut varchar(20) not null,
    nombre varchar(50) not null,
    direccion varchar(50) not null
)



