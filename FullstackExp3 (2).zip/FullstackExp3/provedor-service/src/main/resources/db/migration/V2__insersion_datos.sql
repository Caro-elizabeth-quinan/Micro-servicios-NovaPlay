INSERT INTO proveedor (rut, nombre, direccion)
VALUES ('76.123.456-7', 'Distribuidora Global S.A.', 'Av. Las Industrias 450, Santiago');

INSERT INTO proveedor (rut, nombre, direccion)
VALUES ('88.987.654-k', 'Suministros Industriales Ltda.', 'Calle Nueva 123, Concepción');

INSERT INTO proveedor (rut, nombre, direccion)
VALUES ('77.555.444-2', 'Tecnología y Redes SpA', 'Paseo Ahumada 312, Of. 501');

INSERT INTO proveedor (rut, nombre, direccion)
VALUES ('96.111.000-8', 'Logística Express del Sur', 'Ruta 5 Sur KM 120, Talca');

INSERT INTO proveedor (rut, nombre, direccion)
VALUES ('81.222.333-1', 'Importaciones Rápidas S.A.', 'Av. Libertad 890, Viña del Mar');