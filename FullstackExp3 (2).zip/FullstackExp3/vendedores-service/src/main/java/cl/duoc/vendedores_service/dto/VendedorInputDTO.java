package cl.duoc.vendedores_service.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.time.LocalDate;

@Data
public class VendedorInputDTO {

    @NotBlank(message = "El nombre no puede estar vacío")
    private String nombre;

    @NotBlank(message = "El apellido no puede estar vacío")
    private String apellido;

    @NotNull(message = "El sueldo no puede ser nulo")
    @Min(value = 0, message = "El sueldo no puede ser negativo")
    private Integer sueldo;

    @NotNull(message = "La fecha de contrato no puede ser nula")
    private LocalDate fechaContrato;

    @NotNull(message = "El ID de login asociado no puede ser nulo")
    private Long login;
}