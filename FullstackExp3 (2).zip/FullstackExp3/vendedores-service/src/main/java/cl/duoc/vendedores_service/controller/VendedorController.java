package cl.duoc.vendedores_service.controller;

import cl.duoc.vendedores_service.dto.VendedorDTO;
import cl.duoc.vendedores_service.dto.VendedorInputDTO;
import cl.duoc.vendedores_service.exception.ErrorResponse;
import cl.duoc.vendedores_service.model.Vendedor;
import cl.duoc.vendedores_service.service.VendedorService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@RestController
@RequestMapping("api/v1/vendedores")
@Tag(name = "Vendedor", description = "API para la gestión y búsquedas del equipo de Vendedores")
public class VendedorController {

    @Autowired
    private VendedorService vendedorService;

    @Operation(
            summary = "Listar Vendedores",
            description = "Método que lista todos los vendedores registrados en el sistema."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Vendedores encontrados",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = Vendedor.class)),
                    examples = @ExampleObject(
                            name = "Ejemplo Lista",
                            value = "[\n  { \"id\": 1, \"nombre\": \"Juan\", \"apellido\": \"Pérez\", \"sueldo\": 650000, \"fechaContrato\": \"2025-03-10\", \"login\": 2 }\n]"
                    )
            )
    )
    @GetMapping
    public ResponseEntity<?> listar() {
        return ResponseEntity.ok(vendedorService.findAll());
    }

    @Operation(
            summary = "Buscar Vendedor por ID",
            description = "Busca un vendedor por ID e integra datos de sesión compuestos vía DTO."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Vendedor DTO encontrado",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = VendedorDTO.class),
                    examples = @ExampleObject(
                            name = "Ejemplo Detalle Compuesto",
                            value = "{\n  \"nombreCompleto\": \"Juan Pérez\",\n  \"login\": {\n    \"email\": \"juan.perez@mail.com\"\n  }\n}"
                    )
            )
    )
    @ApiResponse(
            responseCode = "404",
            description = "Vendedor no encontrado",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = @ExampleObject(
                            name = "Error: ID Inexistente",
                            value = "{\n  \"fecha\": \"2026-06-20T17:50:00\",\n  \"status\": 404,\n  \"error\": \"Not Found\",\n  \"mensaje\": \"Vendedor no encontrado con id: 99\",\n  \"path\": \"/api/v1/vendedores/99\"\n}"
                    )
            )
    )
    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(
            @Parameter(description = "ID único del vendedor", example = "1")
            @PathVariable Long id
    ) {
        return ResponseEntity.ok(vendedorService.findById(id));
    }

    @Operation(
            summary = "Registrar un Vendedor",
            description = "Método que registra un nuevo vendedor en el sistema sin requerir ID manual."
    )
    @ApiResponse(
            responseCode = "201",
            description = "Vendedor registrado exitosamente",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = Vendedor.class),
                    examples = @ExampleObject(
                            name = "Vendedor Creado",
                            value = "{ \"id\": 3, \"nombre\": \"Diego\", \"apellido\": \"Salazar\", \"sueldo\": 700000, \"fechaContrato\": \"2026-06-20\", \"login\": 5 }"
                    )
            )
    )
    @ApiResponse(
            responseCode = "400",
            description = "Datos de entrada inválidos",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = @ExampleObject(
                            name = "Error: Bad Request",
                            value = "{\n  \"fecha\": \"2026-06-20T17:51:22\",\n  \"status\": 400,\n  \"error\": \"Bad Request\",\n  \"mensaje\": \"El nombre no puede estar vacío\",\n  \"path\": \"/api/v1/vendedores\"\n}"
                    )
            )
    )
    @PostMapping
    public ResponseEntity<?> registrar(@Valid @RequestBody VendedorInputDTO input) {
        Vendedor vendedor = new Vendedor();
        vendedor.setNombre(input.getNombre());
        vendedor.setApellido(input.getApellido());
        vendedor.setSueldo(input.getSueldo());
        vendedor.setFechaContrato(input.getFechaContrato());
        vendedor.setLogin(input.getLogin());

        Vendedor nuevo = vendedorService.save(vendedor);
        return new ResponseEntity<>(nuevo, HttpStatus.CREATED);
    }

    @Operation(
            summary = "Actualizar un Vendedor",
            description = "Modifica los datos de un vendedor existente localizándolo por su ID."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Vendedor actualizado exitosamente",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = Vendedor.class)
            )
    )
    @ApiResponse(
            responseCode = "400",
            description = "Estructura del cuerpo de la solicitud mal formada o inválida",
            content = @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))
    )
    @ApiResponse(
            responseCode = "404",
            description = "Vendedor no encontrado para actualizar",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = @ExampleObject(
                            name = "Error: Actualización Fallida",
                            value = "{\n  \"fecha\": \"2026-06-20T17:52:00\",\n  \"status\": 404,\n  \"error\": \"Not Found\",\n  \"mensaje\": \"Vendedor no encontrado con id: 88\",\n  \"path\": \"/api/v1/vendedores/88\"\n}"
                    )
            )
    )
    @PutMapping("/{id}")
    public ResponseEntity<?> actualizar(
            @PathVariable Long id,
            @Valid @RequestBody VendedorInputDTO input
    ) {
        Vendedor vendedor = new Vendedor();
        vendedor.setNombre(input.getNombre());
        vendedor.setApellido(input.getApellido());
        vendedor.setSueldo(input.getSueldo());
        vendedor.setFechaContrato(input.getFechaContrato());
        vendedor.setLogin(input.getLogin());

        Vendedor actualizado = vendedorService.update(id, vendedor);
        if (actualizado == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(actualizado);
    }

    @Operation(
            summary = "Eliminar un Vendedor",
            description = "Método que remueve un vendedor del sistema a partir de su ID."
    )
    @ApiResponse(
            responseCode = "204",
            description = "Vendedor eliminado correctamente (Sin contenido)",
            content = @Content(mediaType = "application/json", schema = @Schema(hidden = true))
    )
    @ApiResponse(
            responseCode = "404",
            description = "Vendedor no encontrado para eliminar",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = @ExampleObject(
                            name = "Error: Eliminación Fallida",
                            value = "{\n  \"fecha\": \"2026-06-20T17:55:00\",\n  \"status\": 404,\n  \"error\": \"Not Found\",\n  \"mensaje\": \"Vendedor no encontrado con id: 99\",\n  \"path\": \"/api/v1/vendedores/99\"\n}"
                    )
            )
    )
    @DeleteMapping("/{id}")
    public ResponseEntity<?> borrar(@PathVariable Long id) {
        vendedorService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @Operation(
            summary = "Buscar vendedores por apellido",
            description = "Obtiene una lista de vendedores que coincidan con el apellido indicado (Case Insensitive)."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Vendedores encontrados",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = Vendedor.class)),
                    examples = @ExampleObject(
                            name = "Vendedores por Apellido",
                            value = "[\n  { \"id\": 1, \"nombre\": \"Juan\", \"apellido\": \"Pérez\", \"sueldo\": 650000, \"fechaContrato\": \"2025-03-10\", \"login\": 2 }\n]"
                    )
            )
    )
    @ApiResponse(
            responseCode = "404",
            description = "Vendedores no encontrados por apellido",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = @ExampleObject(
                            name = "Error: Apellido Inexistente",
                            value = "{\n  \"fecha\": \"2026-06-20T18:05:12\",\n  \"status\": 404,\n  \"error\": \"Not Found\",\n  \"mensaje\": \"No se encontraron vendedores con el apellido especificado\",\n  \"path\": \"/api/v1/vendedores/buscar/apellido/Maldonado\"\n}"
                    )
            )
    )
    @GetMapping("/buscar/apellido/{apellido}")
    public ResponseEntity<?> buscarApellido(@PathVariable String apellido) {
        return ResponseEntity.ok(vendedorService.buscarPorApellido(apellido));
    }

    @Operation(
            summary = "Buscar vendedores por sueldo mayor a",
            description = "Obtiene los vendedores cuyo sueldo supere el monto estipulado."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Vendedores con sueldo superior encontrados",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = Vendedor.class)),
                    examples = @ExampleObject(
                            name = "Vendedores con Sueldo Mayor",
                            value = "[\n  { \"id\": 1, \"nombre\": \"Juan\", \"apellido\": \"Pérez\", \"sueldo\": 650000, \"fechaContrato\": \"2025-03-10\", \"login\": 2 }\n]"
                    )
            )
    )
    @ApiResponse(
            responseCode = "404",
            description = "No se encontraron vendedores con sueldos mayores",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = @ExampleObject(
                            name = "Error: Sueldo Excedido",
                            value = "{\n  \"fecha\": \"2026-06-20T18:06:40\",\n  \"status\": 404,\n  \"error\": \"Not Found\",\n  \"mensaje\": \"No existen vendedores que ganen más del monto estipulado\",\n  \"path\": \"/api/v1/vendedores/buscar/sueldo-mayor/9999999\"\n}"
                    )
            )
    )
    @GetMapping("/buscar/sueldo-mayor/{monto}")
    public ResponseEntity<?> buscarSueldo(@PathVariable int monto) {
        return ResponseEntity.ok(vendedorService.buscarSueldoMayor(monto));
    }

    @Operation(
            summary = "Buscar vendedores por nombre exacto",
            description = "Obtiene una lista de vendedores que posean el nombre enviado por parámetro."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Vendedores encontrados",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = Vendedor.class)),
                    examples = @ExampleObject(
                            name = "Vendedores por Nombre",
                            value = "[\n  { \"id\": 1, \"nombre\": \"Juan\", \"apellido\": \"Pérez\", \"sueldo\": 650000, \"fechaContrato\": \"2025-03-10\", \"login\": 2 }\n]"
                    )
            )
    )
    @ApiResponse(
            responseCode = "404",
            description = "Vendedores no encontrados por nombre",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = @ExampleObject(
                            name = "Error: Nombre Inexistente",
                            value = "{\n  \"fecha\": \"2026-06-20T18:07:15\",\n  \"status\": 404,\n  \"error\": \"Not Found\",\n  \"mensaje\": \"No se encontraron vendedores con el nombre indicado\",\n  \"path\": \"/api/v1/vendedores/buscar/nombre\"\n}"
                    )
            )
    )
    @GetMapping("/buscar/nombre")
    public ResponseEntity<?> buscarNombre(@RequestParam String valor) {
        return ResponseEntity.ok(vendedorService.buscarPorNombre(valor));
    }

    @Operation(
            summary = "Buscar vendedores por rango de fechas de contrato",
            description = "Obtiene todos los vendedores que se encuentran dentro del rango de fechas estipulado."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Vendedores encontrados",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = Vendedor.class)),
                    examples = @ExampleObject(
                            name = "Vendedores en Rango de Fechas",
                            value = "[\n  { \"id\": 1, \"nombre\": \"Juan\", \"apellido\": \"Pérez\", \"sueldo\": 650000, \"fechaContrato\": \"2023-05-15\", \"login\": 2 }\n]"
                    )
            )
    )
    @ApiResponse(
            responseCode = "404",
            description = "Vendedores no encontrados",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = @ExampleObject(
                            name = "Error: Rango sin Vendedores",
                            value = "{\n  \"fecha\": \"2026-06-20T17:45:00\",\n  \"status\": 404,\n  \"error\": \"Not Found\",\n  \"mensaje\": \"No se encontraron vendedores contratados entre las fechas 2023-01-01 y 2023-12-31\",\n  \"path\": \"/api/v1/vendedores/buscar/fecha\"\n}"
                    )
            )
    )
    @GetMapping("/buscar/fecha")
    public ResponseEntity<?> buscarPorFecha(
            @Parameter(description = "Fecha inicial (yyyy-MM-dd)", example = "2023-01-01")
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) String inicio,
            @Parameter(description = "Fecha de término (yyyy-MM-dd)", example = "2023-12-31")
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) String fin
    ) {
        return ResponseEntity.ok(vendedorService.buscarPorRangoFecha(
                LocalDate.parse(inicio),
                LocalDate.parse(fin)));
    }
}