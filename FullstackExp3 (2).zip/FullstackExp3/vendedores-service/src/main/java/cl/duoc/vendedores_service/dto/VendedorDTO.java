package cl.duoc.vendedores_service.dto;


import lombok.Data;

@Data
public class VendedorDTO {
    private String nombreCompleto;
    private LoginDTO login;
}
