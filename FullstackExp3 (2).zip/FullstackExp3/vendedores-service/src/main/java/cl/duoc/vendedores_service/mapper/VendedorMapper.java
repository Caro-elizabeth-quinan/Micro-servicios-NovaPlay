package cl.duoc.vendedores_service.mapper;

import cl.duoc.vendedores_service.dto.VendedorDTO;
import cl.duoc.vendedores_service.model.Vendedor;
import org.springframework.stereotype.Component;

@Component
public class VendedorMapper {


    public VendedorDTO toDTO(Vendedor vendedor){
        if ( vendedor == null ) return null;
        VendedorDTO dto = new VendedorDTO();
        dto.setNombreCompleto( vendedor.getNombre() + " " + vendedor.getApellido() );
        return dto;
    }
}
