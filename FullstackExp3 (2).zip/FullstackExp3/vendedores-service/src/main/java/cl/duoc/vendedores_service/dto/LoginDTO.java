package cl.duoc.vendedores_service.dto;


import lombok.Data;

@Data
public class LoginDTO {
    private String email;
}
