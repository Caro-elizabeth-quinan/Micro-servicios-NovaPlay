package cl.duoc.vendedores_service.service;

import cl.duoc.vendedores_service.clients.LoginFeign;
import cl.duoc.vendedores_service.dto.LoginDTO;
import cl.duoc.vendedores_service.dto.VendedorDTO;
import cl.duoc.vendedores_service.exception.ResourceNotFoundException;
import cl.duoc.vendedores_service.mapper.VendedorMapper;
import cl.duoc.vendedores_service.model.Vendedor;
import cl.duoc.vendedores_service.repository.VendedorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class VendedorService {


    @Autowired
    private VendedorRepository vendedorRepository;

    @Autowired
    private VendedorMapper vendedorMapper;
    @Autowired
    private LoginFeign loginFeign;

    public List<Vendedor> findAll() {
        return vendedorRepository.findAll();
    }

    public VendedorDTO findById(Long id) {
        Vendedor vendedor = vendedorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                                "Vendedor no encontrado con id: " + id));

        // Convierte entity a DTO
        VendedorDTO dto = vendedorMapper.toDTO(vendedor);
        // Obtiene información del login
        LoginDTO loginDTO = loginFeign.buscarPorId(vendedor.getLogin());
        dto.setLogin(loginDTO);
        return dto;
    }

    public Vendedor save(Vendedor vendedor) {
        return vendedorRepository.save(vendedor);
    }

    public void delete(Long id){
        // Verifica existencia
        if(!vendedorRepository.existsById(id)){

            throw new ResourceNotFoundException(
                    "Vendedor no encontrado con id: " + id
            );
        }
        vendedorRepository.deleteById(id);
    }
    public Vendedor update(Long id, Vendedor vendedor){
            Vendedor vendedorActulizado = vendedorRepository.findById(id)
                    .orElseThrow(() -> new ResourceNotFoundException(
                            "Vendedor no encontrado con id: " + id)
                    );
            // Actualiza campos
            vendedorActulizado.setNombre(vendedor.getNombre());
            vendedorActulizado.setApellido(vendedor.getApellido());
            vendedorActulizado.setSueldo(vendedor.getSueldo());
            vendedorActulizado.setFechaContrato(vendedor.getFechaContrato());
            vendedorActulizado.setLogin(vendedor.getLogin());

            return vendedorRepository.save(vendedorActulizado);
    }

    public List<Vendedor> buscarPorApellido(String apellido) {
        return vendedorRepository.findByApellidoIgnoreCase(apellido);
    }

    public List<Vendedor> buscarSueldoMayor(int sueldo) {
        return vendedorRepository.findBySueldoGreaterThan(sueldo);
    }

    public List<Vendedor> buscarPorNombre(String nombre) {
        return vendedorRepository.findByNombre(nombre);
    }

    public List<Vendedor> buscarPorRangoFecha(LocalDate inicio, LocalDate fin) {
        return vendedorRepository.findByFechaContratoBetween(inicio, fin);
    }
}
