package cl.duoc.vendedores_service.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "vendedor")
public class Vendedor {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "El campo nombre no puede estar vacio")
    @Column(nullable = false)
    @Size(min = 3, max = 50)
    private String nombre;

    @NotBlank(message = "El campo apellido no puede estar vacio")
    @Column(nullable = false)
    @Size(min = 3, max = 50)
    private String apellido;

    @NotNull(message = "El campo sueldo no puede estar vacio")
    @Column(nullable = false)
    @PositiveOrZero(message = "El sueldo no puede tener valores negativos")
    private int sueldo;

    @NotNull(message = "El campo fecha de contrato no puede estar vacio")
    @Column(nullable = false)
    private LocalDate fechaContrato;

    @NotNull(message = "El campo login no puede estar vacio")
    @Column(nullable = false)
    private Long login; //id_login
}
