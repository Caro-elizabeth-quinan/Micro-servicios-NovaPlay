package cl.duoc.vendedores_service.repository;


import cl.duoc.vendedores_service.model.Vendedor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface VendedorRepository extends JpaRepository<Vendedor,Long> {
    // 1. Buscar por apellido (ignorando mayúsculas/minúsculas)
    List<Vendedor> findByApellidoIgnoreCase(String apellido);

    // 2. Buscar vendedores con sueldo superior a un valor
    List<Vendedor> findBySueldoGreaterThan(int sueldo);

    // 3. Buscar por nombre exacto
    List<Vendedor> findByNombre(String nombre);

    // 4. Buscar contratados entre dos fechas
    List<Vendedor> findByFechaContratoBetween(LocalDate inicio, LocalDate fin);
}
