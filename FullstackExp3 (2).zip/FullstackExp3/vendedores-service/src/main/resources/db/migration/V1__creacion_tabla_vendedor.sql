create table vendedor(
    id bigint auto_increment primary key,
    nombre varchar(50) not null,
    apellido varchar(50) not null,
    sueldo integer not null,
    fecha_contrato date not null,
    login bigint not null
);
