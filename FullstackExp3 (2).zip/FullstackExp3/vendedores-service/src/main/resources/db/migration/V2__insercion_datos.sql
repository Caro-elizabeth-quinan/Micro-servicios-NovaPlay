INSERT INTO vendedor (nombre, apellido, sueldo, fecha_contrato, login)
VALUES ('Ricardo', 'Sánchez', 650000, '2023-01-15', 6);

INSERT INTO vendedor (nombre, apellido, sueldo, fecha_contrato, login)
VALUES ('Patricia', 'Mendoza', 720000, '2023-03-20', 7);

INSERT INTO vendedor (nombre, apellido, sueldo, fecha_contrato, login)
VALUES ('Fernando', 'Araya', 580000, '2023-06-02', 8);

INSERT INTO vendedor (nombre, apellido, sueldo, fecha_contrato, login)
VALUES ('Claudia', 'Figueroa', 850000, '2022-11-10', 9);

INSERT INTO vendedor (nombre, apellido, sueldo, fecha_contrato, login)
VALUES ('Gonzalo', 'Tapia', 610000, '2024-01-05', 10);