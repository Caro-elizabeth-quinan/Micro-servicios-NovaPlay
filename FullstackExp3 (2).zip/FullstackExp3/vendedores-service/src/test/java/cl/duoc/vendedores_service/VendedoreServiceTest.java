package cl.duoc.vendedores_service;

import cl.duoc.vendedores_service.clients.LoginFeign;
import cl.duoc.vendedores_service.dto.LoginDTO;
import cl.duoc.vendedores_service.dto.VendedorDTO;
import cl.duoc.vendedores_service.mapper.VendedorMapper;
import cl.duoc.vendedores_service.model.Vendedor;
import cl.duoc.vendedores_service.repository.VendedorRepository;
import cl.duoc.vendedores_service.service.VendedorService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class VendedorServiceTest {

    @Mock
    private VendedorRepository vendedorRepository;

    @Mock
    private VendedorMapper vendedorMapper;

    @Mock
    private LoginFeign loginFeign;

    @InjectMocks
    private VendedorService vendedorService;

    @Test
    void findAll() {

        Vendedor vendedor = new Vendedor();
        vendedor.setNombre("Juan");

        when(vendedorRepository.findAll())
                .thenReturn(List.of(vendedor));

        List<Vendedor> resultado = vendedorService.findAll();

        assertNotNull(resultado);
        assertEquals(1, resultado.size());

        verify(vendedorRepository).findAll();
    }

    @Test
    void findById() {

        Vendedor vendedor = new Vendedor();
        vendedor.setLogin(1L);

        VendedorDTO vendedorDTO = new VendedorDTO();

        LoginDTO loginDTO = new LoginDTO();
        loginDTO.setEmail("juan@correo.cl");

        when(vendedorRepository.findById(1L))
                .thenReturn(Optional.of(vendedor));

        when(vendedorMapper.toDTO(vendedor))
                .thenReturn(vendedorDTO);

        when(loginFeign.buscarPorId(1L))
                .thenReturn(loginDTO);

        VendedorDTO resultado = vendedorService.findById(1L);

        assertNotNull(resultado);

        verify(vendedorRepository).findById(1L);
        verify(loginFeign).buscarPorId(1L);
    }

    @Test
    void save() {

        Vendedor vendedor = new Vendedor();
        vendedor.setNombre("Juan");

        when(vendedorRepository.save(any(Vendedor.class)))
                .thenReturn(vendedor);

        Vendedor resultado = vendedorService.save(vendedor);

        assertNotNull(resultado);

        verify(vendedorRepository).save(vendedor);
    }

    @Test
    void delete() {

        when(vendedorRepository.existsById(1L))
                .thenReturn(true);

        vendedorService.delete(1L);

        verify(vendedorRepository).existsById(1L);
        verify(vendedorRepository).deleteById(1L);
    }

    @Test
    void update() {

        Vendedor existente = new Vendedor();

        Vendedor nuevo = new Vendedor();
        nuevo.setNombre("Pedro");
        nuevo.setApellido("Perez");
        nuevo.setSueldo(800000);
        nuevo.setFechaContrato(LocalDate.now());
        nuevo.setLogin(1L);

        when(vendedorRepository.findById(1L))
                .thenReturn(Optional.of(existente));

        when(vendedorRepository.save(any(Vendedor.class)))
                .thenReturn(existente);

        Vendedor resultado =
                vendedorService.update(1L, nuevo);

        assertNotNull(resultado);

        verify(vendedorRepository).findById(1L);
        verify(vendedorRepository).save(any(Vendedor.class));
    }

    @Test
    void buscarPorApellido() {

        Vendedor vendedor = new Vendedor();

        when(vendedorRepository.findByApellidoIgnoreCase("Perez"))
                .thenReturn(List.of(vendedor));

        List<Vendedor> resultado =
                vendedorService.buscarPorApellido("Perez");

        assertEquals(1, resultado.size());
    }

    @Test
    void buscarSueldoMayor() {

        Vendedor vendedor = new Vendedor();

        when(vendedorRepository.findBySueldoGreaterThan(500000))
                .thenReturn(List.of(vendedor));

        List<Vendedor> resultado =
                vendedorService.buscarSueldoMayor(500000);

        assertEquals(1, resultado.size());
    }

    @Test
    void buscarPorNombre() {

        Vendedor vendedor = new Vendedor();

        when(vendedorRepository.findByNombre("Juan"))
                .thenReturn(List.of(vendedor));

        List<Vendedor> resultado =
                vendedorService.buscarPorNombre("Juan");

        assertEquals(1, resultado.size());
    }

    @Test
    void buscarPorRangoFecha() {

        Vendedor vendedor = new Vendedor();

        LocalDate inicio = LocalDate.of(2024, 1, 1);
        LocalDate fin = LocalDate.of(2025, 12, 31);

        when(vendedorRepository.findByFechaContratoBetween(inicio, fin))
                .thenReturn(List.of(vendedor));

        List<Vendedor> resultado =
                vendedorService.buscarPorRangoFecha(inicio, fin);

        assertEquals(1, resultado.size());
    }
}
