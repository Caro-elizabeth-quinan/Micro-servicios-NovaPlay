package cl.duoc.ventas_service;

import cl.duoc.ventas_service.clients.*;
import cl.duoc.ventas_service.dto.*;
import cl.duoc.ventas_service.mapper.VentasMapper;
import cl.duoc.ventas_service.model.Venta;
import cl.duoc.ventas_service.repository.VentaRepository;
import cl.duoc.ventas_service.service.VentaService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.*;

public class VentaServiceTest {

    @Mock
    private VentaRepository ventaRepository;

    @Mock
    private VentasMapper ventasMapper;

    @Mock
    private BoletaFeign boletaFeign;

    @Mock
    private ClientesFeign clientesFeign;

    @Mock
    private VendedorFeign vendedorFeign;

    @Mock
    private SucursalFeign sucursalFeign;

    @Mock
    private VideojuegosFeign videojuegoFeignClient;

    @InjectMocks
    private VentaService ventaService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void buscarVentaExistente() {
        // 1. Datos de origen (Entidad)
        Venta venta = new Venta();
        venta.setId(1L);
        venta.setBoleta(100L);
        venta.setCliente(1L);
        venta.setVendedor(2L);
        venta.setSucursal(3L);
        venta.setDetalles(new ArrayList<>());

        // 2. Mockeo de Feign según tus DTOs reales
        BoletaDTO boletaDTO = new BoletaDTO();
        boletaDTO.setId(100L);

        ClienteDTO clienteDTO = new ClienteDTO();
        clienteDTO.setNombreCompleto("Esteban Quito");

        VendedorDTO vendedorDTO = new VendedorDTO();
        vendedorDTO.setNombreCompleto("Ana María");

        SucursalDTO sucursalDTO = new SucursalDTO();
        sucursalDTO.setNombre("Sucursal Central");

        // 3. Estructura de VentaDTO basada estrictamente en tu VentasMapper
        VentaDTO dto = new VentaDTO();
        dto.setTotal(50000);
        dto.setDetalles(new ArrayList<>());

        // Comportamientos de los Mocks
        when(ventaRepository.findById(1L)).thenReturn(Optional.of(venta));
        when(ventasMapper.toDTO(venta)).thenReturn(dto);

        when(boletaFeign.buscarPorId(anyLong())).thenReturn(boletaDTO);
        when(clientesFeign.buscarPorId(anyLong())).thenReturn(clienteDTO);
        when(vendedorFeign.buscarPorId(anyLong())).thenReturn(vendedorDTO);
        when(sucursalFeign.buscarPorid(anyLong())).thenReturn(sucursalDTO);

        // 4. Ejecución del método real
        VentaDTO resultado = ventaService.buscar(1L);

        // 5. Verificaciones
        assertNotNull(resultado);
        assertEquals(50000, resultado.getTotal());
        assertNotNull(resultado.getDetalles());

        verify(ventaRepository).findById(1L);
    }

    @Test
    void guardarVenta() {
        // 1. Instanciamos el objeto Request esperado por tu método crearVenta()
        VentaRequest request = new VentaRequest();
        request.setBoleta(100L);
        request.setCliente(1L);
        request.setVendedor(2L);
        request.setSucursal(3L);

        // Creamos un detalle simulado para que pase por el bucle "for" del servicio
        DetalleVentaRequest detalleReq = new DetalleVentaRequest();
        detalleReq.setVideojuegoId(10L);
        detalleReq.setCantidad(2);
        request.setDetalles(List.of(detalleReq));

        // 2. Mock de respuesta del Microservicio de Videojuegos usado en el ciclo
        VideojuegosDTO videojuegoDTO = new VideojuegosDTO();
        videojuegoDTO.setId(10L);
        videojuegoDTO.setTitulo("Zelda: Tears of the Kingdom");
        videojuegoDTO.setPrecio(45000);

        // 3. Entidad que guardará el repositorio y el DTO final mapeado
        Venta ventaGuardada = new Venta();
        ventaGuardada.setId(99L);
        ventaGuardada.setTotal(90000);
        ventaGuardada.setDetalles(new ArrayList<>());

        VentaDTO dtoEsperado = new VentaDTO();
        dtoEsperado.setTotal(90000);
        dtoEsperado.setDetalles(new ArrayList<>());

        // 4. Configuración de reglas para Mockito
        when(videojuegoFeignClient.obtenerVideojuego(anyLong())).thenReturn(videojuegoDTO);
        when(ventaRepository.save(any(Venta.class))).thenReturn(ventaGuardada);
        when(ventasMapper.toDTO(any(Venta.class))).thenReturn(dtoEsperado);

        // Opcional: Evitar fallas en el método auxiliar de enriquecimiento si es que busca nulos
        when(boletaFeign.buscarPorId(anyLong())).thenReturn(new BoletaDTO());

        // 5. Ejecución con el nombre real de tu método: crearVenta
        VentaDTO resultado = ventaService.crearVenta(request);

        // 6. Verificaciones válidas
        assertNotNull(resultado);
        assertEquals(90000, resultado.getTotal());
        verify(ventaRepository).save(any(Venta.class));
        verify(videojuegoFeignClient).obtenerVideojuego(10L);
    }

    @Test
    void listarVentas() {
        Venta venta1 = new Venta();
        Venta venta2 = new Venta();
        List<Venta> listaEntidades = List.of(venta1, venta2);

        VentaDTO dto1 = new VentaDTO();
        VentaDTO dto2 = new VentaDTO();

        when(ventaRepository.findAll()).thenReturn(listaEntidades);
        when(ventasMapper.toDTO(any(Venta.class))).thenReturn(dto1, dto2);

        var resultado = ventaService.listar();

        assertNotNull(resultado);
        assertEquals(2, resultado.size());
        verify(ventaRepository).findAll();
    }

    @Test
    void buscarPorCliente() {
        Long clienteId = 1L;
        Venta venta = new Venta();
        VentaDTO dto = new VentaDTO();

        when(ventaRepository.findByCliente(clienteId)).thenReturn(List.of(venta));
        when(ventasMapper.toDTO(any(Venta.class))).thenReturn(dto);

        var resultado = ventaService.buscarPorCliente(clienteId);

        assertNotNull(resultado);
        assertEquals(1, resultado.size());
        verify(ventaRepository).findByCliente(clienteId);
    }

    @Test
    void buscarPorSucursal() {
        Long sucursalId = 1L;
        Venta venta = new Venta();
        VentaDTO dto = new VentaDTO();

        when(ventaRepository.findBySucursal(sucursalId)).thenReturn(List.of(venta));
        when(ventasMapper.toDTO(any(Venta.class))).thenReturn(dto);

        var resultado = ventaService.buscarPorSucursal(sucursalId);

        assertNotNull(resultado);
        assertEquals(1, resultado.size());
        verify(ventaRepository).findBySucursal(sucursalId);
    }

    @Test
    void buscarPorRangoTotal() {
        Integer minimo = 10000;
        Integer maximo = 50000;
        Venta venta = new Venta();
        VentaDTO dto = new VentaDTO();

        when(ventaRepository.findByTotalBetween(minimo, maximo)).thenReturn(List.of(venta));
        when(ventasMapper.toDTO(any(Venta.class))).thenReturn(dto);

        var resultado = ventaService.buscarPorRangoTotal(minimo, maximo);

        assertNotNull(resultado);
        assertEquals(1, resultado.size());
        verify(ventaRepository).findByTotalBetween(minimo, maximo);
    }

    @Test
    void buscarPorFecha() {
        String fechaStr = "2026-06-20";
        Venta venta = new Venta();
        VentaDTO dto = new VentaDTO();

        when(ventaRepository.findByFecha(any(LocalDate.class))).thenReturn(List.of(venta));
        when(ventasMapper.toDTO(any(Venta.class))).thenReturn(dto);

        var resultado = ventaService.buscarPorFecha(fechaStr);

        assertNotNull(resultado);
        assertEquals(1, resultado.size());
        verify(ventaRepository).findByFecha(any(LocalDate.class));
    }
}