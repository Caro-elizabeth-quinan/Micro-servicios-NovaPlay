INSERT INTO detalle_venta (videojuego_id, titulo_videojuego, cantidad, precio_unitario, subtotal, venta_id)
VALUES (101, 'The Legend of Zelda: Tears of the Kingdom', 1, 10000, 10000, 1);

INSERT INTO detalle_venta (videojuego_id, titulo_videojuego, cantidad, precio_unitario, subtotal, venta_id)
VALUES (102, 'Elden Ring', 1, 25500, 25500, 2);

INSERT INTO detalle_venta (videojuego_id, titulo_videojuego, cantidad, precio_unitario, subtotal, venta_id)
VALUES (103, 'Stardew Valley', 1, 5400, 5400, 3);

INSERT INTO detalle_venta (videojuego_id, titulo_videojuego, cantidad, precio_unitario, subtotal, venta_id)
VALUES (104, 'PlayStation 5 Console', 1, 120000, 120000, 4);

INSERT INTO detalle_venta (videojuego_id, titulo_videojuego, cantidad, precio_unitario, subtotal, venta_id)
VALUES (105, 'Hollow Knight', 1, 8990, 8990, 5);