CREATE TABLE detalle_venta (

                               id BIGINT AUTO_INCREMENT PRIMARY KEY,

                               videojuego_id BIGINT NOT NULL,

                               titulo_videojuego VARCHAR(255) NOT NULL,

                               cantidad INT NOT NULL,

                               precio_unitario INT NOT NULL,

                               subtotal INT NOT NULL,

                               venta_id BIGINT NOT NULL,

                               CONSTRAINT fk_detalle_venta
                                   FOREIGN KEY (venta_id)
                                       REFERENCES venta(id)
                                       ON DELETE CASCADE
);