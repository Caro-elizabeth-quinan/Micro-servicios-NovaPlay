INSERT INTO venta (boleta, fecha, hora, cliente, vendedor, sucursal, total)
VALUES (1, '2024-03-01', '10:45:00', 1, 1, 1, 11900);

INSERT INTO venta (boleta, fecha, hora, cliente, vendedor, sucursal, total)
VALUES (2, '2024-03-02', '14:30:15', 2, 2, 2, 30345);

INSERT INTO venta (boleta, fecha, hora, cliente, vendedor, sucursal, total)
VALUES (3, '2024-03-05', '09:15:00', 3, 3, 3, 6426);

INSERT INTO venta (boleta, fecha, hora, cliente, vendedor, sucursal, total)
VALUES (4, '2024-03-10', '18:20:45', 4, 4, 4, 142800);

INSERT INTO venta (boleta, fecha, hora, cliente, vendedor, sucursal, total)
VALUES (5, '2024-03-12', '12:00:30', 5, 5, 5, 10698);