CREATE TABLE venta (

                       id BIGINT AUTO_INCREMENT PRIMARY KEY,

                       boleta BIGINT NOT NULL,

                       fecha DATE NOT NULL,

                       hora TIME NOT NULL,

                       cliente BIGINT NOT NULL,

                       vendedor BIGINT NOT NULL,

                       sucursal BIGINT NOT NULL,

                       total INT NOT NULL
);
