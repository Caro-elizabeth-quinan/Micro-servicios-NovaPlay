package cl.duoc.ventas_service.dto;

import lombok.Data;

import java.time.LocalDate;

@Data
public class BoletaDTO {
    private Long id;
    private int monto;
    private LocalDate fechaEmision;
    private String iva;
}
