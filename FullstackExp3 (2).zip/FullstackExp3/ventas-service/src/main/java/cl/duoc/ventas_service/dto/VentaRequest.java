package cl.duoc.ventas_service.dto;

import lombok.Data;

import java.util.List;

@Data
public class VentaRequest {
    private Long boleta;

    private Long cliente;

    private Long vendedor;

    private Long sucursal;

    private List<DetalleVentaRequest> detalles;
}
