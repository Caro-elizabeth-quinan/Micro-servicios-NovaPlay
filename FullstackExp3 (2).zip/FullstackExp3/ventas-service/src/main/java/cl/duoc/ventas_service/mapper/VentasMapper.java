package cl.duoc.ventas_service.mapper;

import cl.duoc.ventas_service.dto.DetalleVentaDTO;
import cl.duoc.ventas_service.dto.VentaDTO;
import cl.duoc.ventas_service.model.DetalleVenta;
import cl.duoc.ventas_service.model.Venta;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class VentasMapper {

    public VentaDTO toDTO(Venta venta) {
        VentaDTO dto = new VentaDTO();
        dto.setFecha(venta.getFecha());
        dto.setHora(venta.getHora());
        dto.setTotal(venta.getTotal());

        List<DetalleVentaDTO> detallesDTO =
                venta.getDetalles()
                        .stream()
                        .map(this::detalleToDTO)
                        .collect(Collectors.toList());

        dto.setDetalles(detallesDTO);
        return dto;
    }

    private DetalleVentaDTO detalleToDTO(DetalleVenta detalle) {
        DetalleVentaDTO dto = new DetalleVentaDTO();
        dto.setId(detalle.getId());
        dto.setVideojuegoId(detalle.getVideojuegoId());
        dto.setCantidad(detalle.getCantidad());
        dto.setPrecioUnitario(detalle.getPrecioUnitario());
        dto.setSubtotal(detalle.getSubtotal());

        return dto;
    }
}
