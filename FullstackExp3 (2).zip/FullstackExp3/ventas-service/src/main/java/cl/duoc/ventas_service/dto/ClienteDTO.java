package cl.duoc.ventas_service.dto;

import lombok.Data;

@Data
public class ClienteDTO {
    private String nombreCompleto;
}

