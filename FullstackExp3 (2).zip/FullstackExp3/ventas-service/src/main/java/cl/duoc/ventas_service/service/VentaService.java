package cl.duoc.ventas_service.service;

import cl.duoc.ventas_service.clients.*;
import cl.duoc.ventas_service.dto.*;
import cl.duoc.ventas_service.exception.ResourceNotFoundException;
import cl.duoc.ventas_service.mapper.VentasMapper;
import cl.duoc.ventas_service.model.DetalleVenta;
import cl.duoc.ventas_service.model.Venta;
import cl.duoc.ventas_service.repository.VentaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class VentaService {

    @Autowired
    private VentaRepository ventaRepository;

    @Autowired
    private VideojuegosFeign videojuegoFeignClient;

    @Autowired
    private VentasMapper ventasMapper;

    @Autowired
    private BoletaFeign boletaFeign;

    @Autowired
    private ClientesFeign clientesFeign;

    @Autowired
    private VendedorFeign vendedorFeign;

    @Autowired
    private SucursalFeign sucursalFeign;

    // 1. Cambiado el retorno a VentaDTO
    public VentaDTO crearVenta(VentaRequest request) {
        Venta venta = new Venta();
        venta.setBoleta(request.getBoleta());
        venta.setCliente(request.getCliente());
        venta.setVendedor(request.getVendedor());
        venta.setSucursal(request.getSucursal());
        venta.setFecha(LocalDate.now());
        venta.setHora(LocalTime.now());

        List<DetalleVenta> detalles = new ArrayList<>();
        int total = 0;

        for (DetalleVentaRequest item : request.getDetalles()) {
            VideojuegosDTO videojuego = videojuegoFeignClient.obtenerVideojuego(item.getVideojuegoId());
            DetalleVenta detalle = new DetalleVenta();
            detalle.setVideojuegoId(videojuego.getId());
            detalle.setTituloVideojuego(videojuego.getTitulo());
            detalle.setCantidad(item.getCantidad());
            detalle.setPrecioUnitario(videojuego.getPrecio());

            int subtotal = videojuego.getPrecio() * item.getCantidad();
            detalle.setSubtotal(subtotal);
            detalle.setVenta(venta);
            detalles.add(detalle);
            total += subtotal;
        }

        venta.setDetalles(detalles);
        venta.setTotal(total);

        // Se guarda la entidad física en la base de datos
        Venta ventaGuardada = ventaRepository.save(venta);

        // Se transforma y retorna como DTO enriquecido (ocultando el título)
        return enriquecerVentaConFeign(ventaGuardada);
    }

    // 2. Cambiado el retorno a List<VentaDTO>
    public List<VentaDTO> listar() {
        // .stream() activa el flujo de datos (pone las Ventas en una "cinta transportadora")
        // .map() transforma cada Venta de la BD en un VentaDTO limpio usando el método auxiliar
        // .collect() junta todos los DTOs procesados y los guarda en una nueva Lista
        return ventaRepository.findAll()
                .stream()
                .map(this::enriquecerVentaConFeign) // Mapea cada elemento a VentaDTO
                .collect(Collectors.toList());
    }

    // Método auxiliar interno reutilizable para rellenar los datos Feign de cada venta individual
    private VentaDTO enriquecerVentaConFeign(Venta ventaOriginal) {
        VentaDTO dto = ventasMapper.toDTO(ventaOriginal);
        try { dto.setBoleta(boletaFeign.buscarPorId(ventaOriginal.getBoleta())); } catch(Exception e) { dto.setBoleta(null); }
        try { dto.setCliente(clientesFeign.buscarPorId(ventaOriginal.getCliente())); } catch(Exception e) { dto.setCliente(null); }
        try { dto.setVendedor(vendedorFeign.buscarPorId(ventaOriginal.getVendedor())); } catch(Exception e) { dto.setVendedor(null); }
        try { dto.setSucursal(sucursalFeign.buscarPorid(ventaOriginal.getSucursal())); } catch(Exception e) { dto.setSucursal(null); }
        return dto;
    }

    public VentaDTO buscar(Long id) {
        Venta ventaOriginal = ventaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Venta no encontrada con id: " + id));
        return enriquecerVentaConFeign(ventaOriginal);
    }

    // Consulta 1 - Buscar por Fecha con control de 404
    public List<VentaDTO> buscarPorFecha(String fechaStr) {
        LocalDate fecha = LocalDate.parse(fechaStr);
        List<Venta> ventas = ventaRepository.findByFecha(fecha);
        if (ventas.isEmpty()) {
            throw new ResourceNotFoundException("No se encontraron ventas para la fecha: " + fechaStr);
        }
        // .stream() abre el flujo, .map() convierte cada Venta a VentaDTO y .collect() los agrupa en la lista de retorno
        return ventas.stream().map(this::enriquecerVentaConFeign).collect(Collectors.toList());
    }

    // Consulta 2 - Buscar por Cliente con control de 404
    public List<VentaDTO> buscarPorCliente(Long idCliente) {
        List<Venta> ventas = ventaRepository.findByCliente(idCliente);
        if (ventas.isEmpty()) {
            throw new ResourceNotFoundException("El cliente con ID " + idCliente + " no registra ventas en el sistema.");
        }
        // .stream() abre el flujo, .map() convierte cada Venta a VentaDTO y .collect() los agrupa en la lista de retorno
        return ventas.stream().map(this::enriquecerVentaConFeign).collect(Collectors.toList());
    }

    // Consulta 3 - Buscar por Sucursal con control de 404
    public List<VentaDTO> buscarPorSucursal(Long idSucursal) {
        List<Venta> ventas = ventaRepository.findBySucursal(idSucursal);
        if (ventas.isEmpty()) {
            throw new ResourceNotFoundException("La sucursal con ID " + idSucursal + " no registra ventas.");
        }
        // .stream() abre el flujo, .map() convierte cada Venta a VentaDTO y .collect() los agrupa en la lista de retorno
        return ventas.stream().map(this::enriquecerVentaConFeign).collect(Collectors.toList());
    }

    // Consulta 4 - Buscar por Rango de Montos con control de 404
    public List<VentaDTO> buscarPorRangoTotal(Integer min, Integer max) {
        List<Venta> ventas = ventaRepository.findByTotalBetween(min, max);
        if (ventas.isEmpty()) {
            throw new ResourceNotFoundException("No existen ventas dentro del rango de montos: " + min + " y " + max);
        }
        // .stream() abre el flujo, .map() convierte cada Venta a VentaDTO y .collect() los agrupa en la lista de retorno
        return ventas.stream().map(this::enriquecerVentaConFeign).collect(Collectors.toList());
    }
}