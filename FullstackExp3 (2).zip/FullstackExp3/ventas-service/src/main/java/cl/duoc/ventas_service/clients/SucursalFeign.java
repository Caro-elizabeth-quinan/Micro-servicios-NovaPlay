package cl.duoc.ventas_service.clients;

import cl.duoc.ventas_service.dto.SucursalDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "sucursales-service")
public interface SucursalFeign {

    @GetMapping("/api/v1/sucursales/{cod}")
    SucursalDTO buscarPorid(@PathVariable Long cod);
}
