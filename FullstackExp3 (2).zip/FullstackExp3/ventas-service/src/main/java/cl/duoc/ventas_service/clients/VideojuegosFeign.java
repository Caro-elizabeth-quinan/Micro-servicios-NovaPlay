package cl.duoc.ventas_service.clients;

import cl.duoc.ventas_service.dto.VideojuegosDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "videojuegos-service")
public interface VideojuegosFeign {

    @GetMapping("/api/v1/videojuegos/{id}")
    VideojuegosDTO obtenerVideojuego(@PathVariable Long id);
}
