package cl.duoc.ventas_service.clients;

import cl.duoc.ventas_service.dto.BoletaDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "boleta-service")
public interface BoletaFeign {

    @GetMapping("/api/v1/boletas/{id}")
    BoletaDTO buscarPorId(@PathVariable Long id);
}
