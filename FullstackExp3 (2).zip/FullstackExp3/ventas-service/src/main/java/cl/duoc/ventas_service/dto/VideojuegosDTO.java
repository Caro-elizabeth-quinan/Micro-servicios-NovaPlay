package cl.duoc.ventas_service.dto;

import lombok.Data;

@Data
public class VideojuegosDTO {
    private Long id;

    private String titulo;

    private String genero;

    private String descripcion;

    private int precio;
}
