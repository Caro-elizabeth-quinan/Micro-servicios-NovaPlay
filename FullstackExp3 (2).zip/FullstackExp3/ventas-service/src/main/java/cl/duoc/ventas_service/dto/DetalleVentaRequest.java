package cl.duoc.ventas_service.dto;

import lombok.Data;

@Data
public class DetalleVentaRequest {

    private Long videojuegoId;

    private Integer cantidad;
}
