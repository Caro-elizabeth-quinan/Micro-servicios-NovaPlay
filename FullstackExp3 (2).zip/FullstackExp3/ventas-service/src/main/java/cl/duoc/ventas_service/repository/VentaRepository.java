package cl.duoc.ventas_service.repository;

import cl.duoc.ventas_service.model.Venta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface VentaRepository extends JpaRepository<Venta, Long> {

    // 1. Buscar ventas por una fecha específica
    List<Venta> findByFecha(LocalDate fecha);

    // 2. Buscar ventas de un cliente específico
    List<Venta> findByCliente(Long clienteId);

    // 3. Buscar ventas por sucursal
    List<Venta> findBySucursal(Long sucursalId);

    // 4. Buscar ventas cuyo total esté entre un rango de precios (Optimización de búsqueda)
    List<Venta> findByTotalBetween(Integer min, Integer max);
}
