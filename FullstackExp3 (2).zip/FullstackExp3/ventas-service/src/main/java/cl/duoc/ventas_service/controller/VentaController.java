package cl.duoc.ventas_service.controller;

import cl.duoc.ventas_service.dto.VentaDTO;
import cl.duoc.ventas_service.dto.VentaRequest;
import cl.duoc.ventas_service.exception.ErrorResponse;
import cl.duoc.ventas_service.service.VentaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/v1/ventas")
@Tag(name = "Venta", description = "API para la gestión de Ventas y Detalles de Ventas")
public class VentaController {

    @Autowired
    private VentaService ventaService;

    public VentaController(VentaService ventaService) {
        this.ventaService = ventaService;
    }

    @PostMapping
    @Operation(
            summary = "Registra una Venta",
            description = "Método que registra una Venta en el sistema"
    )
    @ApiResponse(
            responseCode = "201",
            description = "Venta creada con éxito",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = VentaDTO.class)
            )
    )
    public ResponseEntity<VentaDTO> crear(@Valid @RequestBody VentaRequest request) {
        return new ResponseEntity<>(ventaService.crearVenta(request), HttpStatus.CREATED);
    }

    @Operation(
            summary = "Listar Ventas",
            description = "Método que lista todas las ventas realizadas por el sistema."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Ventas encontradas",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = VentaDTO.class)) // Cambiado a VentaDTO
            )
    )
    @GetMapping
    public ResponseEntity<List<VentaDTO>> listar() { // Cambiado a VentaDTO
        return ResponseEntity.ok(ventaService.listar());
    }

    @Operation(
            summary = "Buscar Venta por ID",
            description = "Método que busca una venta en el sistema a través del ID. Este id es de tipo numérico (LONG)"
    )
    @ApiResponse(
            responseCode = "200",
            description = "Venta encontrada",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = VentaDTO.class)
            )
    )
    @ApiResponse(
            responseCode = "404",
            description = "Venta no encontrada",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class)
            )
    )
    @GetMapping("/{id}")
    public ResponseEntity<VentaDTO> buscarPorId(@PathVariable Long id){
        return ResponseEntity.ok(ventaService.buscar(id));
    }

    // 1. Buscar por fecha
    @Operation(
            summary = "Buscar ventas por fecha",
            description = "Obtiene todas las ventas registradas en una fecha específica."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Ventas encontradas",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = VentaDTO.class))
            )
    )
    @ApiResponse(
            responseCode = "404",
            description = "Venta no encontrada",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class)
            )
    )
    @GetMapping("/buscar/fecha/{fecha}")
    public ResponseEntity<List<VentaDTO>> porFecha(
            @Parameter(description = "Fecha de búsqueda en formato yyyy-MM-dd", example = "2024-05-13")
            @PathVariable String fecha
    ) {
        return ResponseEntity.ok(ventaService.buscarPorFecha(fecha));
    }

    // 2. Buscar por cliente
    @Operation(
            summary = "Buscar ventas por cliente",
            description = "Obtiene todas las ventas asociadas a un cliente."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Ventas encontradas",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = VentaDTO.class))
            )
    )
    @ApiResponse(
            responseCode = "404",
            description = "Venta no encontrada",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class)
            )
    )
    @GetMapping("/buscar/cliente/{idCliente}")
    public ResponseEntity<List<VentaDTO>> porCliente(
            @Parameter(description = "ID del cliente", example = "5")
            @PathVariable Long idCliente
    ) {
        return ResponseEntity.ok(ventaService.buscarPorCliente(idCliente));
    }

    // 3. Buscar por sucursal
    @Operation(
            summary = "Buscar ventas por sucursal",
            description = "Obtiene todas las ventas realizadas en una sucursal."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Ventas encontradas",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = VentaDTO.class))
            )
    )
    @ApiResponse(
            responseCode = "404",
            description = "Venta no encontrada",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class)
            )
    )
    @GetMapping("/buscar/sucursal/{idSucursal}")
    public ResponseEntity<List<VentaDTO>> porSucursal(
            @Parameter(description = "ID de la sucursal", example = "10")
            @PathVariable Long idSucursal
    ) {
        return ResponseEntity.ok(ventaService.buscarPorSucursal(idSucursal));
    }

    // 4. Buscar por rango de total
    @Operation(
            summary = "Buscar ventas por rango de total",
            description = "Obtiene todas las ventas cuyo total se encuentra dentro del rango indicado."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Ventas encontradas",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = VentaDTO.class))
            )
    )
    @ApiResponse(
            responseCode = "404",
            description = "Venta no encontrada",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class)
            )
    )
    @GetMapping("/buscar/rango")
    public ResponseEntity<List<VentaDTO>> porRangoTotal(
            @Parameter(description = "Monto mínimo", example = "10000") @RequestParam Integer min,
            @Parameter(description = "Monto máximo", example = "50000") @RequestParam Integer max
    ) {
        return ResponseEntity.ok(ventaService.buscarPorRangoTotal(min, max));
    }
}