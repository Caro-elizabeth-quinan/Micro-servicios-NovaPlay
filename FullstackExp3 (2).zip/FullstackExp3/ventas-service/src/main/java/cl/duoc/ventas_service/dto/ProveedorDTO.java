package cl.duoc.ventas_service.dto;

import lombok.Data;

@Data
public class ProveedorDTO {
    private String rut;
    private String nombre;
    private String direccion;
}
