package cl.duoc.ventas_service.dto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Data
@JsonPropertyOrder({"boleta","fecha","hora","cliente","vendedor","sucursal","detalles","total"})
public class VentaDTO {

    private BoletaDTO boleta;

    private LocalDate fecha;

    private LocalTime hora;

    private ClienteDTO cliente;

    private VendedorDTO vendedor;

    private SucursalDTO sucursal;

    private List<DetalleVentaDTO> detalles;

    private Integer total;
}
