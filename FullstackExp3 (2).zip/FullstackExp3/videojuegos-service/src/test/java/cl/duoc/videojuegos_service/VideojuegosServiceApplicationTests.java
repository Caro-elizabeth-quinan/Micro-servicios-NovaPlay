package cl.duoc.videojuegos_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VideojuegosServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
