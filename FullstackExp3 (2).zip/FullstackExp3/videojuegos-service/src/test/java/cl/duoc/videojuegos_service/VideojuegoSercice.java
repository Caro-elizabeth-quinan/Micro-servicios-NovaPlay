package cl.duoc.videojuegos_service;

import cl.duoc.videojuegos_service.dto.VideojuegoDTO;
import cl.duoc.videojuegos_service.mapper.VideojuegoMapper;
import cl.duoc.videojuegos_service.model.Videojuego;
import cl.duoc.videojuegos_service.repository.VideojuegoRepository;
import cl.duoc.videojuegos_service.service.VideojuegoService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class VideojuegoSercice {

    @Mock
    private VideojuegoRepository videojuegoRepository;

    @Mock
    private VideojuegoMapper videojuegoMapper;

    @InjectMocks
    private VideojuegoService videojuegoService;

    @Test
    void findAll() {

        Videojuego videojuego = new Videojuego();
        videojuego.setTitulo("God of War");

        VideojuegoDTO dto = new VideojuegoDTO();
        dto.setTitulo("God of War");

        when(videojuegoRepository.findAll())
                .thenReturn(List.of(videojuego));

        when(videojuegoMapper.toDTO(videojuego))
                .thenReturn(dto);

        List<VideojuegoDTO> resultado = videojuegoService.findAll();

        assertNotNull(resultado);
        assertEquals(1, resultado.size());

        verify(videojuegoRepository).findAll();
    }

    @Test
    void findById() {

        Videojuego videojuego = new Videojuego();
        videojuego.setTitulo("God of War");

        VideojuegoDTO dto = new VideojuegoDTO();
        dto.setTitulo("God of War");

        when(videojuegoRepository.findById(1L))
                .thenReturn(Optional.of(videojuego));

        when(videojuegoMapper.toDTO(videojuego))
                .thenReturn(dto);

        VideojuegoDTO resultado = videojuegoService.findById(1L);

        assertNotNull(resultado);
        assertEquals("God of War", resultado.getTitulo());

        verify(videojuegoRepository).findById(1L);
    }

    @Test
    void save() {

        Videojuego videojuego = new Videojuego();
        videojuego.setTitulo("God of War");

        VideojuegoDTO dto = new VideojuegoDTO();
        dto.setTitulo("God of War");

        when(videojuegoRepository.save(any(Videojuego.class)))
                .thenReturn(videojuego);

        when(videojuegoMapper.toDTO(videojuego))
                .thenReturn(dto);

        VideojuegoDTO resultado = videojuegoService.save(videojuego);

        assertNotNull(resultado);
        assertEquals("God of War", resultado.getTitulo());

        verify(videojuegoRepository).save(any(Videojuego.class));
    }

    @Test
    void delete() {

        when(videojuegoRepository.existsById(1L))
                .thenReturn(true);

        videojuegoService.delete(1L);

        verify(videojuegoRepository).existsById(1L);
        verify(videojuegoRepository).deleteById(1L);
    }

    @Test
    void update() {

        Videojuego existente = new Videojuego();
        existente.setTitulo("Antiguo");

        Videojuego nuevo = new Videojuego();
        nuevo.setTitulo("Nuevo");
        nuevo.setGenero("Accion");
        nuevo.setDescripcion("Descripcion");
        nuevo.setFechaLanzamiento(LocalDate.now());
        nuevo.setPrecio(50000);

        VideojuegoDTO dto = new VideojuegoDTO();
        dto.setTitulo("Nuevo");

        when(videojuegoRepository.findById(1L))
                .thenReturn(Optional.of(existente));

        when(videojuegoRepository.save(any(Videojuego.class)))
                .thenReturn(existente);

        when(videojuegoMapper.toDTO(any(Videojuego.class)))
                .thenReturn(dto);

        VideojuegoDTO resultado =
                videojuegoService.update(1L, nuevo);

        assertNotNull(resultado);
        assertEquals("Nuevo", resultado.getTitulo());

        verify(videojuegoRepository).findById(1L);
        verify(videojuegoRepository).save(any(Videojuego.class));
    }

    @Test
    void buscarPorGenero() {

        Videojuego videojuego = new Videojuego();
        videojuego.setGenero("Accion");

        VideojuegoDTO dto = new VideojuegoDTO();
        dto.setGenero("Accion");

        when(videojuegoRepository.findByGenero("Accion"))
                .thenReturn(List.of(videojuego));

        when(videojuegoMapper.toDTO(videojuego))
                .thenReturn(dto);

        List<VideojuegoDTO> resultado =
                videojuegoService.buscarPorGenero("Accion");

        assertEquals(1, resultado.size());

        verify(videojuegoRepository).findByGenero("Accion");
    }

    @Test
    void buscarPorTitulo() {

        Videojuego videojuego = new Videojuego();
        videojuego.setTitulo("God of War");

        VideojuegoDTO dto = new VideojuegoDTO();
        dto.setTitulo("God of War");

        when(videojuegoRepository.findByTituloContainingIgnoreCase("God"))
                .thenReturn(List.of(videojuego));

        when(videojuegoMapper.toDTO(videojuego))
                .thenReturn(dto);

        List<VideojuegoDTO> resultado =
                videojuegoService.buscarPorTitulo("God");

        assertEquals(1, resultado.size());

        verify(videojuegoRepository)
                .findByTituloContainingIgnoreCase("God");
    }

    @Test
    void buscarPorPrecioMaximo() {

        Videojuego videojuego = new Videojuego();
        videojuego.setPrecio(50000);

        VideojuegoDTO dto = new VideojuegoDTO();
        dto.setPrecio(50000);

        when(videojuegoRepository.findByPrecioLessThanEqual(50000))
                .thenReturn(List.of(videojuego));

        when(videojuegoMapper.toDTO(videojuego))
                .thenReturn(dto);

        List<VideojuegoDTO> resultado =
                videojuegoService.buscarPorPrecioMaximo(50000);

        assertEquals(1, resultado.size());

        verify(videojuegoRepository)
                .findByPrecioLessThanEqual(50000);
    }
}