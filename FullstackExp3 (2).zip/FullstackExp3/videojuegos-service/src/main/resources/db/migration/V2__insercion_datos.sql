INSERT INTO videojuego (titulo, genero, descripcion, fecha_lanzamiento, precio, stock)
VALUES ('The Legend of Zelda: Tears of the Kingdom', 'Acción-Aventura', 'Exploración épica en el reino de Hyrule.', '2023-05-12', 10000, 50);

INSERT INTO videojuego (titulo, genero, descripcion, fecha_lanzamiento, precio, stock)
VALUES ('Elden Ring', 'RPG de Acción', 'Desafiante viaje por las Tierras Intermedias.', '2022-02-25', 25500, 30);

INSERT INTO videojuego (titulo, genero, descripcion, fecha_lanzamiento, precio, stock)
VALUES ('Stardew Valley', 'Simulación', 'Gestión de granja y vida rural con estética retro.', '2016-02-26', 5400, 100);

INSERT INTO videojuego (titulo, genero, descripcion, fecha_lanzamiento, precio, stock)
VALUES ('PlayStation 5 Console', 'Hardware', 'Consola de última generación de Sony.', '2020-11-12', 120000, 15);

INSERT INTO videojuego (titulo, genero, descripcion, fecha_lanzamiento, precio, stock)
VALUES ('Hollow Knight', 'Metroidvania', 'Aventura de acción en un reino de insectos en ruinas.', '2017-02-24', 8990, 80);