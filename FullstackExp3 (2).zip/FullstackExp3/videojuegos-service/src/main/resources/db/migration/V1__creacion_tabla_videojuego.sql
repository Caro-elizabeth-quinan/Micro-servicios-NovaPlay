create table videojuego(
                           id BIGINT AUTO_INCREMENT PRIMARY KEY,

                           titulo VARCHAR(255) NOT NULL,

                           genero VARCHAR(255) NOT NULL,

                           descripcion VARCHAR(500),

                           fecha_lanzamiento DATE,

                           precio INT NOT NULL,

                           stock INT DEFAULT 0
)
