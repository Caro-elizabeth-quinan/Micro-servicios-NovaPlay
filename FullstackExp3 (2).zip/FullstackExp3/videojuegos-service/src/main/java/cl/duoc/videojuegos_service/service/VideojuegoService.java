package cl.duoc.videojuegos_service.service;

import cl.duoc.videojuegos_service.dto.VideojuegoDTO;
import cl.duoc.videojuegos_service.exception.ResourceNotFoundException;
import cl.duoc.videojuegos_service.mapper.VideojuegoMapper;
import cl.duoc.videojuegos_service.model.Videojuego;
import cl.duoc.videojuegos_service.repository.VideojuegoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class VideojuegoService {

    @Autowired
    private VideojuegoRepository videojuegoRepository;

    @Autowired
    private VideojuegoMapper videojuegoMapper;

    public List<VideojuegoDTO> findAll() {
        return videojuegoRepository.findAll()
                .stream()
                .map(videojuegoMapper::toDTO)
                .collect(Collectors.toList());
    }

    public VideojuegoDTO findById(Long id) {
        Videojuego videojuego = videojuegoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Videojuego no encontrado con id: " + id));
        return videojuegoMapper.toDTO(videojuego);
    }

    public VideojuegoDTO save(Videojuego videojuego) {
        Videojuego nuevo = videojuegoRepository.save(videojuego);
        return videojuegoMapper.toDTO(nuevo);
    }

    public void delete(Long id) {
        if (!videojuegoRepository.existsById(id)) {
            throw new ResourceNotFoundException("Videojuego no encontrado con id: " + id);
        }
        videojuegoRepository.deleteById(id);
    }

    public VideojuegoDTO update(Long id, Videojuego videojuego) {
        Videojuego v = videojuegoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Videojuego no encontrado con id: " + id));

        v.setTitulo(videojuego.getTitulo());
        v.setGenero(videojuego.getGenero());
        v.setDescripcion(videojuego.getDescripcion());
        v.setFechaLanzamiento(videojuego.getFechaLanzamiento());
        v.setPrecio(videojuego.getPrecio());

        return videojuegoMapper.toDTO(videojuegoRepository.save(v));
    }

    public List<VideojuegoDTO> buscarPorGenero(String genero) {
        return videojuegoRepository.findByGenero(genero)
                .stream()
                .map(videojuegoMapper::toDTO)
                .collect(Collectors.toList());
    }

    public List<VideojuegoDTO> buscarPorTitulo(String titulo) {
        return videojuegoRepository.findByTituloContainingIgnoreCase(titulo)
                .stream()
                .map(videojuegoMapper::toDTO)
                .collect(Collectors.toList());
    }

    public List<VideojuegoDTO> buscarPorPrecioMaximo(int precio) {
        return videojuegoRepository.findByPrecioLessThanEqual(precio)
                .stream()
                .map(videojuegoMapper::toDTO)
                .collect(Collectors.toList());
    }
}