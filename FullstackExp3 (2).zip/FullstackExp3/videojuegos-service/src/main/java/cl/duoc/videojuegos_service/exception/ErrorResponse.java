package cl.duoc.videojuegos_service.exception;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ErrorResponse {
    /*utilice esto para sacar los errores
    fecha	cuándo ocurrió
    status	código HTTP
    error	nombre del error
    mensaje	explicación personalizada
    path	endpoint que falló
     */
    @Schema(example = "2026-06-19T12:48:01.816")
    private LocalDateTime fecha;

    @Schema(example = "404")
    private Integer status;

    @Schema(example = "Not Found")
    private String error;

    @Schema(example = "Videojuego no encontrado con id: 1")
    private String mensaje;

    @Schema(example = "/api/v1/videojuego/1")
    private String path;
}

