package cl.duoc.videojuegos_service.repository;

import cl.duoc.videojuegos_service.model.Videojuego;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface VideojuegoRepository extends JpaRepository<Videojuego, Long> {

    // 1. Buscar por género exacto
    List<Videojuego> findByGenero(String genero);

    // 2. Buscar por coincidencia en el título (Like)
    List<Videojuego> findByTituloContainingIgnoreCase(String titulo);

    // 3. Buscar videojuegos en un rango de precio (Menor o igual a)
    List<Videojuego> findByPrecioLessThanEqual(int precioMax);
}
