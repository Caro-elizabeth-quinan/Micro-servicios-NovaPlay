package cl.duoc.videojuegos_service;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

@OpenAPIDefinition(
		info = @Info(
				title = "API para gestión de Videojuegos",
				version = "1.0.1",
				description = "API que gestiona el catálogo de videojuegos, incluyendo búsqueda y detalle.",
				contact = @Contact(
						name = "Carolina Elizabeth Quinan Perot",
						email = "ca.quinan@duocuc.cl"
				)
		)
)
@EnableDiscoveryClient
@EnableFeignClients
@SpringBootApplication
public class VideojuegosServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(VideojuegosServiceApplication.class, args);
	}
}