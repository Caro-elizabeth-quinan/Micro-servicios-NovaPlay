package cl.duoc.videojuegos_service.dto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;

import java.time.LocalDate;

@Data
@JsonPropertyOrder({"titulo","genero","descripcion","fechaLanzamiento","precio"})
public class VideojuegoDTO {
    private String titulo;
    private String genero;
    private String descripcion;
    private LocalDate fechaLanzamiento;
    private int precio;

}