package cl.duoc.clientes_service;

import cl.duoc.clientes_service.clients.LoginFeign;
import cl.duoc.clientes_service.dto.ClienteDTO;
import cl.duoc.clientes_service.dto.LoginDTO;
import cl.duoc.clientes_service.mapper.ClienteMapper;
import cl.duoc.clientes_service.model.Cliente;
import cl.duoc.clientes_service.repository.ClienteRepository;
import cl.duoc.clientes_service.service.ClienteService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
class ClienteServiceTest {

    @Mock
    private ClienteRepository clienteRepository;

    @Mock
    private ClienteMapper clienteMapper;

    @Mock
    private LoginFeign loginFeign;

    @InjectMocks
    private ClienteService clienteService;

    @Test
    void findAll() {

        Cliente cliente = new Cliente();
        cliente.setNombre("Juan");

        when(clienteRepository.findAll())
                .thenReturn(List.of(cliente));

        List<Cliente> resultado = clienteService.findAll();

        assertNotNull(resultado);
        assertEquals(1, resultado.size());

        verify(clienteRepository).findAll();
    }

    @Test
    void findById() {

        Cliente cliente = new Cliente();
        cliente.setLogin(1L);

        ClienteDTO dto = new ClienteDTO();

        LoginDTO loginDTO = new LoginDTO();
        loginDTO.setEmail("juan@correo.cl");

        when(clienteRepository.findById(1L))
                .thenReturn(Optional.of(cliente));

        when(clienteMapper.toDTO(cliente))
                .thenReturn(dto);

        when(loginFeign.buscarPorId(1L))
                .thenReturn(loginDTO);

        ClienteDTO resultado = clienteService.findById(1L);

        assertNotNull(resultado);

        verify(clienteRepository).findById(1L);
        verify(loginFeign).buscarPorId(1L);
    }

    @Test
    void save() {

        Cliente cliente = new Cliente();
        cliente.setNombre("Juan");

        when(clienteRepository.save(any(Cliente.class)))
                .thenReturn(cliente);

        Cliente resultado = clienteService.save(cliente);

        assertNotNull(resultado);

        verify(clienteRepository).save(cliente);
    }

    @Test
    void delete() {

        when(clienteRepository.existsById(1L))
                .thenReturn(true);

        clienteService.delete(1L);

        verify(clienteRepository).existsById(1L);
        verify(clienteRepository).deleteById(1L);
    }

    @Test
    void update() {

        Cliente existente = new Cliente();

        Cliente nuevo = new Cliente();
        nuevo.setNombre("Pedro");
        nuevo.setApellido("Perez");
        nuevo.setFechaNacimiento(LocalDate.of(2000, 1, 1));
        nuevo.setLogin(1L);

        when(clienteRepository.findById(1L))
                .thenReturn(Optional.of(existente));

        when(clienteRepository.save(any(Cliente.class)))
                .thenReturn(existente);

        Cliente resultado =
                clienteService.update(1L, nuevo);

        assertNotNull(resultado);

        verify(clienteRepository).findById(1L);
        verify(clienteRepository).save(any(Cliente.class));
    }

    @Test
    void buscarPorRut() {

        Cliente cliente = new Cliente();
        cliente.setRut("12345678-9");

        when(clienteRepository.findByRut("12345678-9"))
                .thenReturn(Optional.of(cliente));

        Cliente resultado =
                clienteService.buscarPorRut("12345678-9");

        assertNotNull(resultado);

        verify(clienteRepository)
                .findByRut("12345678-9");
    }

    @Test
    void buscarPorApellido() {

        Cliente cliente = new Cliente();
        cliente.setApellido("Perez");

        when(clienteRepository
                .findByApellidoContainingIgnoreCase("Perez"))
                .thenReturn(List.of(cliente));

        List<Cliente> resultado =
                clienteService.buscarPorApellido("Perez");

        assertEquals(1, resultado.size());
    }

    @Test
    void buscarPorRangoFecha() {

        Cliente cliente = new Cliente();

        LocalDate inicio = LocalDate.of(1990, 1, 1);
        LocalDate fin = LocalDate.of(2005, 12, 31);

        when(clienteRepository
                .findByFechaNacimientoBetween(inicio, fin))
                .thenReturn(List.of(cliente));

        List<Cliente> resultado =
                clienteService.buscarPorRangoFecha(inicio, fin);

        assertEquals(1, resultado.size());
    }

    @Test
    void buscarMayoresEdad() {

        Cliente cliente = new Cliente();

        when(clienteRepository
                .findByFechaNacimientoBefore(any(LocalDate.class)))
                .thenReturn(List.of(cliente));

        List<Cliente> resultado =
                clienteService.buscarMayoresEdad();

        assertEquals(1, resultado.size());

        verify(clienteRepository)
                .findByFechaNacimientoBefore(any(LocalDate.class));
    }
}