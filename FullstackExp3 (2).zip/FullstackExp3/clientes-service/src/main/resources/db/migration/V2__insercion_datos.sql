INSERT INTO cliente (rut, nombre, apellido, fecha_nacimiento, login)
VALUES ('12.345.678-9', 'Juan', 'Pérez', '1990-05-15', 1);

INSERT INTO cliente (rut, nombre, apellido, fecha_nacimiento, login)
VALUES ('15.987.654-3', 'María José', 'García', '1985-11-22', 2);

INSERT INTO cliente (rut, nombre, apellido, fecha_nacimiento, login)
VALUES ('18.456.123-k', 'Carlos', 'Ruiz', '1998-02-03', 3);

INSERT INTO cliente (rut, nombre, apellido, fecha_nacimiento, login)
VALUES ('20.111.222-4', 'Ana', 'Soto', '2001-08-30', 4);

INSERT INTO cliente (rut, nombre, apellido, fecha_nacimiento, login)
VALUES ('9.876.543-2', 'Roberto', 'Lagos', '1975-12-12', 5);