create table cliente(
    id bigint auto_increment primary key,
    rut varchar(20) not null ,
    nombre varchar(50) not null,
    apellido varchar(50) not null,
    fecha_nacimiento date not null,
    login bigint not null
)
