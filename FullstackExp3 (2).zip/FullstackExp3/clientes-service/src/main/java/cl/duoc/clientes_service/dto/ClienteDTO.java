package cl.duoc.clientes_service.dto;

import lombok.Data;

import java.time.LocalDate;

@Data
public class ClienteDTO {
    private String nombreCompleto;
    private LocalDate fechaNacimiento;
    private LoginDTO login;
}
