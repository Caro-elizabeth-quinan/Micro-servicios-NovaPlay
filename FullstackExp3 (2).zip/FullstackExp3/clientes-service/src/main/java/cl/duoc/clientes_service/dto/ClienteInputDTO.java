package cl.duoc.clientes_service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.time.LocalDate;

@Data
@Schema(description = "Estructura de entrada para la creación o actualización de un Cliente")
public class ClienteInputDTO {

    @Schema(description = "RUT identificador del cliente", example = "12.345.678-9")
    @NotBlank(message = "El campo RUT no puede estar vacio")
    private String rut;

    @Schema(description = "Nombre de pila del cliente", example = "Juan")
    @NotBlank(message = "El campo nombre no puede estar vacio")
    @Size(min = 3, max = 50, message = "El nombre debe tener entre 3 y 50 caracteres")
    private String nombre;

    @Schema(description = "Apellido del cliente", example = "Pérez")
    @NotBlank(message = "El campo apellido no puede estar vacio")
    @Size(min = 3, max = 50, message = "El apellido debe tener entre 3 y 50 caracteres")
    private String apellido;

    @Schema(description = "Fecha de nacimiento", example = "2000-05-15")
    @NotNull(message = "El campo fecha no puede estar vacio")
    private LocalDate fechaNacimiento;

    @Schema(description = "ID único del login asociado en el microservicio de acceso", example = "1")
    @NotNull(message = "El campo login no puede estar vacio")
    private Long login;
}