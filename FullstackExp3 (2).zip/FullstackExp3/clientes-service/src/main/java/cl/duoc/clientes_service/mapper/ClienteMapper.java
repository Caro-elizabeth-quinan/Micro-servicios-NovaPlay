package cl.duoc.clientes_service.mapper;

import cl.duoc.clientes_service.dto.ClienteDTO;
import cl.duoc.clientes_service.model.Cliente;
import org.springframework.stereotype.Component;

@Component
public class ClienteMapper {

    public ClienteDTO toDTO( Cliente cliente ){
        if ( cliente == null ) return null;
        ClienteDTO dto = new ClienteDTO();
        dto.setNombreCompleto( cliente.getNombre() + " " + cliente.getApellido() );
        dto.setFechaNacimiento(cliente.getFechaNacimiento());
        return dto;
    }
}
