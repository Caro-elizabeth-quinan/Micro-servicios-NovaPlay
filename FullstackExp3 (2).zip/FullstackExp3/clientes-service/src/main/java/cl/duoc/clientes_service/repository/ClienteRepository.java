package cl.duoc.clientes_service.repository;

import cl.duoc.clientes_service.model.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface ClienteRepository extends JpaRepository<Cliente, Long> {

    // Busca un cliente específico por su RUT
    Optional<Cliente> findByRut(String rut);

    // Busca todos los clientes cuyo apellido contenga el texto ingresado
    List<Cliente> findByApellidoContainingIgnoreCase(String apellido);

    // Busca clientes nacidos entre dos fechas dadas
    List<Cliente> findByFechaNacimientoBetween(LocalDate inicio, LocalDate fin);
 //buscar mayores de edad
    List<Cliente> findByFechaNacimientoBefore(LocalDate fecha);
}
