package cl.duoc.clientes_service.dto;


import lombok.Data;

@Data
public class LoginDTO {
    private String email;
}
