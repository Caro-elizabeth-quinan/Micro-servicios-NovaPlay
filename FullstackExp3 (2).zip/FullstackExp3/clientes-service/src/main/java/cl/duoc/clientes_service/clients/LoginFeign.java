package cl.duoc.clientes_service.clients;


import cl.duoc.clientes_service.dto.LoginDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "login-service")
public interface LoginFeign {

    @GetMapping("/api/v1/loganizas/{id}")
    LoginDTO buscarPorId(@PathVariable Long id);

}
