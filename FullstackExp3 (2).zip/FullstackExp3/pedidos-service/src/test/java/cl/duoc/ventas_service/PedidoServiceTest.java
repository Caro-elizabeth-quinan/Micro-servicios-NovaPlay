package cl.duoc.ventas_service;

import cl.duoc.ventas_service.clients.ClientesFeign;
import cl.duoc.ventas_service.dto.ClienteDTO;
import cl.duoc.ventas_service.dto.PedidoDTO;
import cl.duoc.ventas_service.mapper.PedidoMapper;
import cl.duoc.ventas_service.model.Pedido;
import cl.duoc.ventas_service.repository.PedidoRepository;
import cl.duoc.ventas_service.service.PedidoService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
class PedidoServiceTest {

    @Mock
    private PedidoRepository pedidoRepository;

    @Mock
    private ClientesFeign clientesFeign;

    @Mock
    private PedidoMapper pedidoMapper;

    @InjectMocks
    private PedidoService pedidoService;

    @Test
    void findAll() {

        Pedido pedido = new Pedido();

        when(pedidoRepository.findAll())
                .thenReturn(List.of(pedido));

        List<Pedido> resultado = pedidoService.findAll();

        assertNotNull(resultado);
        assertEquals(1, resultado.size());

        verify(pedidoRepository).findAll();
    }

    @Test
    void findById() {

        Pedido pedido = new Pedido();
        pedido.setCliente(1L);

        PedidoDTO dto = new PedidoDTO();

        ClienteDTO clienteDTO = new ClienteDTO();
        clienteDTO.setId(1L);
        clienteDTO.setNombre("Juan");

        when(pedidoRepository.findById(1L))
                .thenReturn(Optional.of(pedido));

        when(pedidoMapper.toDTO(pedido))
                .thenReturn(dto);

        when(clientesFeign.buscarPorId(1L))
                .thenReturn(clienteDTO);

        PedidoDTO resultado = pedidoService.findById(1L);

        assertNotNull(resultado);

        verify(pedidoRepository).findById(1L);
        verify(clientesFeign).buscarPorId(1L);
    }

    @Test
    void save() {

        Pedido pedido = new Pedido();

        when(pedidoRepository.save(any(Pedido.class)))
                .thenReturn(pedido);

        Pedido resultado = pedidoService.save(pedido);

        assertNotNull(resultado);

        verify(pedidoRepository).save(pedido);
    }

    @Test
    void delete() {

        when(pedidoRepository.existsById(1L))
                .thenReturn(true);

        pedidoService.delete(1L);

        verify(pedidoRepository).deleteById(1L);
    }

    @Test
    void update() {

        Pedido existente = new Pedido();

        Pedido nuevo = new Pedido();
        nuevo.setMonto(50000);
        nuevo.setFecha(LocalDate.now());
        nuevo.setHora(LocalTime.now());
        nuevo.setCliente(1L);

        when(pedidoRepository.findById(1L))
                .thenReturn(Optional.of(existente));

        when(pedidoRepository.save(any(Pedido.class)))
                .thenReturn(existente);

        Pedido resultado =
                pedidoService.update(1L, nuevo);

        assertNotNull(resultado);

        verify(pedidoRepository).findById(1L);
        verify(pedidoRepository).save(any(Pedido.class));
    }

    @Test
    void buscarPorFecha() {

        Pedido pedido = new Pedido();
        pedido.setCliente(1L);

        PedidoDTO dto = new PedidoDTO();

        ClienteDTO clienteDTO = new ClienteDTO();

        LocalDate fecha = LocalDate.now();

        when(pedidoRepository.findByFecha(fecha))
                .thenReturn(List.of(pedido));

        when(pedidoMapper.toDTO(pedido))
                .thenReturn(dto);

        when(clientesFeign.buscarPorId(1L))
                .thenReturn(clienteDTO);

        List<PedidoDTO> resultado =
                pedidoService.buscarPorFecha(fecha);

        assertEquals(1, resultado.size());
    }

    @Test
    void buscarPorMontoMinimo() {

        Pedido pedido = new Pedido();
        pedido.setCliente(1L);

        PedidoDTO dto = new PedidoDTO();

        ClienteDTO clienteDTO = new ClienteDTO();

        when(pedidoRepository.findByMontoGreaterThanEqual(10000))
                .thenReturn(List.of(pedido));

        when(pedidoMapper.toDTO(pedido))
                .thenReturn(dto);

        when(clientesFeign.buscarPorId(1L))
                .thenReturn(clienteDTO);

        List<PedidoDTO> resultado =
                pedidoService.buscarPorMontoMinimo(10000);

        assertEquals(1, resultado.size());
    }

    @Test
    void buscarPorCliente() {

        Pedido pedido = new Pedido();
        pedido.setCliente(1L);

        PedidoDTO dto = new PedidoDTO();

        ClienteDTO clienteDTO = new ClienteDTO();

        when(pedidoRepository.findByCliente(1L))
                .thenReturn(List.of(pedido));

        when(pedidoMapper.toDTO(pedido))
                .thenReturn(dto);

        when(clientesFeign.buscarPorId(1L))
                .thenReturn(clienteDTO);

        List<PedidoDTO> resultado =
                pedidoService.buscarPorCliente(1L);

        assertEquals(1, resultado.size());
    }

    @Test
    void buscarPorRangoFechas() {

        Pedido pedido = new Pedido();
        pedido.setCliente(1L);

        PedidoDTO dto = new PedidoDTO();

        ClienteDTO clienteDTO = new ClienteDTO();

        LocalDate inicio = LocalDate.of(2025,1,1);
        LocalDate fin = LocalDate.of(2025,12,31);

        when(pedidoRepository.findByFechaBetween(inicio, fin))
                .thenReturn(List.of(pedido));

        when(pedidoMapper.toDTO(pedido))
                .thenReturn(dto);

        when(clientesFeign.buscarPorId(1L))
                .thenReturn(clienteDTO);

        List<PedidoDTO> resultado =
                pedidoService.buscarPorRangoFechas(inicio, fin);

        assertEquals(1, resultado.size());
    }
}