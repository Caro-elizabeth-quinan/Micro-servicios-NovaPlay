INSERT INTO pedido (monto, fecha, hora, cliente)
VALUES (15000, '2024-03-15', '10:30:00', 1);

INSERT INTO pedido (monto, fecha, hora, cliente)
VALUES (45000, '2024-03-15', '14:20:15', 2);

INSERT INTO pedido (monto, fecha, hora, cliente)
VALUES (12500, '2024-03-16', '09:15:00', 3);

INSERT INTO pedido (monto, fecha, hora, cliente)
VALUES (67000, '2024-03-16', '18:45:30', 4);

INSERT INTO pedido (monto, fecha, hora, cliente)
VALUES (22900, '2024-03-17', '12:00:00', 5);