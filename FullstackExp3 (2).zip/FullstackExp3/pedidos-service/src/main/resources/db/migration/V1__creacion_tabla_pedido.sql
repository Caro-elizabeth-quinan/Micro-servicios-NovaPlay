create table pedido(
    id bigint auto_increment primary key,
    monto integer not null,
    fecha date not null,
    hora time not null,
    cliente bigint not null
)
