package cl.duoc.ventas_service.repository;

import cl.duoc.ventas_service.model.Pedido;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface PedidoRepository extends JpaRepository<Pedido, Long> {
    // 1. Buscar pedidos realizados en una fecha específica
    List<Pedido> findByFecha(LocalDate fecha);

    // 2. Buscar pedidos cuyo monto sea mayor o igual a un valor (Ej: para pedidos grandes)
    List<Pedido> findByMontoGreaterThanEqual(int monto);

    // 3. Buscar todos los pedidos de un cliente específico usando su ID
    List<Pedido> findByCliente(Long clienteId);

    // 4. Buscar pedidos entre un rango de fechas (Ideal para reportes mensuales)
    List<Pedido> findByFechaBetween(LocalDate inicio, LocalDate fin);

    //List<Pedido> findByEstado(String estado);
}
