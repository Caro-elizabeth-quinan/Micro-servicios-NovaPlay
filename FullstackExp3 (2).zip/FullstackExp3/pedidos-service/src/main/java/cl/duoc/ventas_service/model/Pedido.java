package cl.duoc.ventas_service.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Pedido {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    @NotNull(message = "El campo monto no puede estar vacio")
    @PositiveOrZero(message = "El monto no puede ser un valor negativo")
    private int monto;

    @Column(nullable = false)
    @NotNull(message = "El campo fecha no puede estar vacio")
    private LocalDate fecha;

    @Column(nullable = false)
    @NotNull(message = "El campo hora no puede estar vacio")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "HH:mm:ss")
    private LocalTime hora;

    @Column(nullable = false)
    @NotNull(message = "El campo cliente no puede estar vacio")
    private Long cliente;

    /*@Column(nullable = false)
    private String estado;

    */
}
