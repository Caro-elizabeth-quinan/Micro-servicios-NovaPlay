package cl.duoc.ventas_service.clients;

import cl.duoc.ventas_service.dto.ClienteDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "clientes-service")
public interface ClientesFeign {

    @GetMapping("/api/v1/clientes/{id}")
    ClienteDTO buscarPorId(@PathVariable Long id);

}
