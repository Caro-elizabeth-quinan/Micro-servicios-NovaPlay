package cl.duoc.ventas_service.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import java.time.LocalDate;
import java.time.LocalTime;

@Data
public class PedidoInputDTO {
    private Integer monto;
    @Schema(type = "string", pattern = "dd:MM:yyyy", example = "20:06:2026")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd:MM:yyyy")
    private LocalDate fecha;


    @Schema(type = "string", pattern = "HH:mm:ss", example = "10:06:20")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "HH:mm:ss")
    private LocalTime hora;
    private Long cliente;
}