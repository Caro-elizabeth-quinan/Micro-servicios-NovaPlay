package cl.duoc.ventas_service.dto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;

@Data
@JsonPropertyOrder({"nombre", "calle", "nro_sucursal"})
public class SucursalDTO {
    private String nombre;
    private String calle;
    private int nroSucursal;
}
