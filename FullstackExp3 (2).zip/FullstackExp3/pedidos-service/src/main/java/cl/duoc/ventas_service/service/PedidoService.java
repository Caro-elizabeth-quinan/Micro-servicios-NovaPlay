package cl.duoc.ventas_service.service;

import cl.duoc.ventas_service.clients.ClientesFeign;
import cl.duoc.ventas_service.dto.PedidoDTO;
import cl.duoc.ventas_service.exception.ResourceNotFoundException;
import cl.duoc.ventas_service.mapper.PedidoMapper;
import cl.duoc.ventas_service.model.Pedido;
import cl.duoc.ventas_service.repository.PedidoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class PedidoService {

    @Autowired
    private PedidoRepository pedidoRepository;

    @Autowired
    private ClientesFeign clientesFeign;

    @Autowired
    private PedidoMapper pedidoMapper;

    public List<Pedido> findAll() {
        return pedidoRepository.findAll();
    }
    public PedidoDTO findById(Long id) {
        Pedido pedido = pedidoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Pedido no encontrado con id: " + id));

        // Usamos tu mapper y le agregamos el cliente
        PedidoDTO dto = pedidoMapper.toDTO(pedido);
        dto.setCliente(clientesFeign.buscarPorId(pedido.getCliente()));
        return dto;
    }

    public Pedido save(Pedido pedido) {
        return pedidoRepository.save(pedido);
    }

    public void delete(Long id){
        // Verifica existencia
        if(!pedidoRepository.existsById(id)){
            throw new ResourceNotFoundException(
                    "Pedido no encontrado con id: " + id
            );
        }

        pedidoRepository.deleteById(id);

    }
    public Pedido update(Long id, Pedido pedido){
        Pedido pedidoActualizar = pedidoRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Pedido no encontrado con id: " + id
                        )
                );

        pedidoActualizar.setMonto(pedido.getMonto());
        pedidoActualizar.setFecha(pedido.getFecha());
        pedidoActualizar.setHora(pedido.getHora());
        pedidoActualizar.setCliente(pedido.getCliente());

        return pedidoRepository.save(pedidoActualizar);
    }

    // Métodos de Consultas que ahora usan tu PedidoMapper de forma automática:
    public List<PedidoDTO> buscarPorFecha(LocalDate fecha) {
        return pedidoRepository.findByFecha(fecha).stream()
                .map(pedido -> {
                    PedidoDTO dto = pedidoMapper.toDTO(pedido);
                    dto.setCliente(clientesFeign.buscarPorId(pedido.getCliente()));
                    return dto;
                })
                .toList();
    }

    public List<PedidoDTO> buscarPorMontoMinimo(int monto) {
        return pedidoRepository.findByMontoGreaterThanEqual(monto).stream()
                .map(pedido -> {
                    PedidoDTO dto = pedidoMapper.toDTO(pedido);
                    dto.setCliente(clientesFeign.buscarPorId(pedido.getCliente()));
                    return dto;
                })
                .toList();
    }

    public List<PedidoDTO> buscarPorCliente(Long clienteId) {
        return pedidoRepository.findByCliente(clienteId).stream()
                .map(pedido -> {
                    PedidoDTO dto = pedidoMapper.toDTO(pedido);
                    dto.setCliente(clientesFeign.buscarPorId(pedido.getCliente()));
                    return dto;
                })
                .toList();
    }

    public List<PedidoDTO> buscarPorRangoFechas(LocalDate inicio, LocalDate fin) {
        return pedidoRepository.findByFechaBetween(inicio, fin).stream()
                .map(pedido -> {
                    PedidoDTO dto = pedidoMapper.toDTO(pedido);
                    dto.setCliente(clientesFeign.buscarPorId(pedido.getCliente()));
                    return dto;
                })
                .toList();
    }


    /*public List<Pedido> buscarPedidosPendientes() {
        return pedidoRepository.findByEstado("PENDIENTE");
    }*/

}
