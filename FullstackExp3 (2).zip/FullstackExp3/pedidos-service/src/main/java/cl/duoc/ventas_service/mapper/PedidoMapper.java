package cl.duoc.ventas_service.mapper;

import cl.duoc.ventas_service.dto.PedidoDTO;
import cl.duoc.ventas_service.model.Pedido;
import org.springframework.stereotype.Component;

@Component
public class PedidoMapper {
    public PedidoDTO toDTO(Pedido pedido){
        PedidoDTO dto = new PedidoDTO();
        dto.setId(pedido.getId());
        dto.setMonto(pedido.getMonto());
        dto.setFecha(pedido.getFecha());
        dto.setHora(pedido.getHora());

        return dto;
    }
}
