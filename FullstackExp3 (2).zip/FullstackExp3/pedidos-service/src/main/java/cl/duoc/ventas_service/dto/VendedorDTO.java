package cl.duoc.ventas_service.dto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;

@Data
@JsonPropertyOrder({"id","nombre","apellido"})
public class VendedorDTO {
    private Long id;
    private String nombre;
    private String apellido;
}
