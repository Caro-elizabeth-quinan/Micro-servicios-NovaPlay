package cl.duoc.ventas_service.controller;

import cl.duoc.ventas_service.dto.PedidoDTO;
import cl.duoc.ventas_service.dto.PedidoInputDTO;
import cl.duoc.ventas_service.exception.ErrorResponse;
import cl.duoc.ventas_service.model.Pedido;
import cl.duoc.ventas_service.service.PedidoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("api/v1/pedidos")
@Tag(name = "Pedido", description = "API para la gestión de Pedidos de los clientes")
public class PedidoController {
    @Autowired
    private PedidoService pedidoService;

    @Operation(
            summary = "Listar Pedidos",
            description = "Método que lista todos los pedidos registrados en el sistema."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Pedidos encontrados",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(
                            schema = @Schema(implementation = Pedido.class)),
                    examples = @ExampleObject(
                            name = "Ejemplo Lista de Pedidos",
                            value = "[\n" +
                                    "  { \"id\": 1, \"cliente\": 10, \"fecha\": \"2026-06-19\", \"monto\": 15000 },\n" +
                                    "  { \"id\": 2, \"cliente\": 15, \"fecha\": \"2026-06-19\", \"monto\": 8500 }\n" +
                                    "]"
                    )
            )
    )
    @GetMapping
    public ResponseEntity<?> listar(){
        return  ResponseEntity.ok(pedidoService.findAll());
    }

    @Operation(
            summary = "Buscar Pedido por ID",
            description = "Método que busca un pedido en el sistema a través de su ID numérico (LONG)."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Pedido encontrado",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = PedidoDTO.class),
                    examples = @ExampleObject(
                            name = "Ejemplo Detalle Pedido",
                            value = "{\n" +
                                    "  \"id\": 1,\n" +
                                    "  \"monto\": 15000,\n" +
                                    "  \"fecha\": \"2024-03-15\",\n" +
                                    "  \"hora\": \"10:30:00\",\n" +
                                    "  \"cliente\": {\n" +
                                    "    \"id\": 10,\n" +
                                    "    \"nombre\": \"Juan Pérez\"\n" +
                                    "  }\n" +
                                    "}"
                    )
            )
    )
    @ApiResponse(
            responseCode = "404",
            description = "Pedido no encontrado",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = @ExampleObject(
                            name = "Error: Pedido No Encontrado",
                            value = "{\n" +
                                    "  \"fecha\": \"2026-06-19T13:00:00\",\n" +
                                    "  \"status\": 404,\n" +
                                    "  \"error\": \"Not Found\",\n" +
                                    "  \"mensaje\": \"Pedido no encontrado con id: 1\",\n" +
                                    "  \"path\": \"/api/v1/pedidos/1\"\n" +
                                    "}"
                    )
            )
    )
    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(
            @Parameter(description = "ID del pedido a buscar", example = "1")
            @PathVariable("id") Long id
    ){
        return ResponseEntity.ok(
                pedidoService.findById(id)
        );
    }

    @Operation(
            summary = "Registrar un Pedido",
            description = "Método que registra un nuevo pedido en el sistema sin necesidad de enviar un ID manual."
    )
    @ApiResponse(
            responseCode = "201",
            description = "Pedido creado exitosamente",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = Pedido.class),
                    examples = @ExampleObject(
                            name = "Ejemplo Pedido Creado",
                            value = "{ \"id\": 3, \"cliente\": 12, \"fecha\": \"2026-06-19\", \"monto\": 5000, \"hora\": \"14:20:00\" }"
                    )
            )
    )
    @ApiResponse(
            responseCode = "404",
            description = "Pedido no registrado",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = @ExampleObject(
                            name = "Error: Cliente no existe",
                            value = "{\n" +
                                    "  \"fecha\": \"2026-06-19T13:02:10\",\n" +
                                    "  \"status\": 404,\n" +
                                    "  \"error\": \"Not Found\",\n" +
                                    "  \"mensaje\": \"No se puede crear el pedido. El cliente con id 12 no existe.\",\n" +
                                    "  \"path\": \"/api/v1/pedidos\"\n" +
                                    "}"
                    )
            )
    )
    @PostMapping
    public ResponseEntity<?> registrar(@Valid @RequestBody PedidoInputDTO input){
        Pedido pedido = new Pedido();
        pedido.setMonto(input.getMonto());
        pedido.setFecha(input.getFecha());
        pedido.setHora(input.getHora());
        pedido.setCliente(input.getCliente());

        Pedido nuevo = pedidoService.save(pedido);
        return new ResponseEntity<>(nuevo, HttpStatus.CREATED);
    }

    @Operation(
            summary = "Eliminar un Pedido",
            description = "Método que elimina un pedido del sistema por su ID."
    )
    @ApiResponse(
            responseCode = "204",
            description = "Pedido eliminado correctamente (Sin contenido)",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(hidden = true))
    )
    @ApiResponse(
            responseCode = "404",
            description = "Pedido no encontrado para eliminar",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = @ExampleObject(
                            name = "Ejemplo de Pedido No Encontrado",
                            value = "{\n" +
                                    "  \"fecha\": \"2026-06-19T12:48:01.8167\",\n" +
                                    "  \"status\": 404,\n" +
                                    "  \"error\": \"Not Found\",\n" +
                                    "  \"mensaje\": \"Pedido no encontrado con id: 3\",\n" +
                                    "  \"path\": \"/api/v1/pedidos/3\"\n" +
                                    "}"
                    )
            )
    )
    @DeleteMapping("/{id}")
    public ResponseEntity<?> borrar(@PathVariable Long id){
        pedidoService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @Operation(
            summary = "Actualizar un Pedido",
            description = "Método que actualiza los datos de un pedido existente a partir de su ID."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Pedido actualizado exitosamente",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = Pedido.class),
                    examples = @ExampleObject(
                            name = "Ejemplo Pedido Actualizado",
                            value = "{ \"id\": 1, \"cliente\": 10, \"fecha\": \"2026-06-19\", \"monto\": 18000, \"hora\": \"10:30:00\" }"
                    )
            )
    )
    @ApiResponse(
            responseCode = "404",
            description = "Pedido no encontrado para actualizar",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = @ExampleObject(
                            name = "Error: Pedido Inexistente",
                            value = "{\n" +
                                    "  \"fecha\": \"2026-06-19T13:05:00\",\n" +
                                    "  \"status\": 404,\n" +
                                    "  \"error\": \"Not Found\",\n" +
                                    "  \"mensaje\": \"No se pudo actualizar. Pedido no encontrado con id: 99\",\n" +
                                    "  \"path\": \"/api/v1/pedidos/99\"\n" +
                                    "}"
                    )
            )
    )
    @PutMapping("/{id}")
    public ResponseEntity<?> actualizar(
            @PathVariable Long id,
            @Valid @RequestBody PedidoInputDTO input
    ){
        Pedido pedido = new Pedido();
        pedido.setMonto(input.getMonto());
        pedido.setFecha(input.getFecha());
        pedido.setHora(input.getHora());
        pedido.setCliente(input.getCliente());

        return ResponseEntity.ok(
                pedidoService.update(id, pedido)
        );
    }

    @Operation(
            summary = "Buscar pedidos por fecha",
            description = "Obtiene todos los pedidos registrados en una fecha específica."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Pedidos encontrados",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = PedidoDTO.class)),
                    examples = @ExampleObject(
                            name = "Pedidos por Fecha",
                            value = "[\n" +
                                    "  { \"id\": 5, \"monto\": 12000, \"fecha\": \"2023-10-25\", \"hora\": \"18:00:00\", \"cliente\": { \"id\": 3, \"nombre\": \"Ana Maria\" } }\n" +
                                    "]"
                    )
            )
    )
    @ApiResponse(
            responseCode = "404",
            description = "Pedido no encontrado",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = @ExampleObject(
                            name = "Error: Sin Pedidos en esa Fecha",
                            value = "{\n" +
                                    "  \"fecha\": \"2026-06-19T13:06:22\",\n" +
                                    "  \"status\": 404,\n" +
                                    "  \"error\": \"Not Found\",\n" +
                                    "  \"mensaje\": \"No se encontraron pedidos para la fecha: 2023-10-25\",\n" +
                                    "  \"path\": \"/api/v1/pedidos/buscar-fecha\"\n" +
                                    "}"
                    )
            )
    )
    @GetMapping("/buscar-fecha")
    public ResponseEntity<List<PedidoDTO>> buscarPorFecha(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fecha) {
        return ResponseEntity.ok(pedidoService.buscarPorFecha(fecha));
    }

    @Operation(
            summary = "Buscar pedidos por monto mínimo",
            description = "Obtiene los pedidos cuyo monto total sea igual o superior al indicado."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Pedidos encontrados",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = PedidoDTO.class)),
                    examples = @ExampleObject(
                            name = "Pedidos Sobre Monto Mínimo",
                            value = "[\n" +
                                    "  { \"id\": 1, \"monto\": 15000, \"fecha\": \"2026-06-19\", \"hora\": \"10:30:00\", \"cliente\": { \"id\": 10, \"nombre\": \"Juan Pérez\" } }\n" +
                                    "]"
                    )
            )
    )
    @ApiResponse(
            responseCode = "404",
            description = "Pedido no encontrado",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = @ExampleObject(
                            name = "Error: Ningún pedido supera el monto",
                            value = "{\n" +
                                    "  \"fecha\": \"2026-06-19T13:08:11\",\n" +
                                    "  \"status\": 404,\n" +
                                    "  \"error\": \"Not Found\",\n" +
                                    "  \"mensaje\": \"No existen pedidos con monto superior a: 500000\",\n" +
                                    "  \"path\": \"/api/v1/pedidos/monto-minimo/500000\"\n" +
                                    "}"
                    )
            )
    )
    @GetMapping("/monto-minimo/{monto}")
    public ResponseEntity<List<PedidoDTO>> buscarPorMonto(@PathVariable int monto) {
        return ResponseEntity.ok(pedidoService.buscarPorMontoMinimo(monto));
    }

    @Operation(
            summary = "Buscar pedidos por cliente",
            description = "Obtiene todos los pedidos asociados a un cliente específico."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Pedidos encontrados",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = PedidoDTO.class)),
                    examples = @ExampleObject(
                            name = "Pedidos del Cliente",
                            value = "[\n" +
                                    "  { \"id\": 1, \"monto\": 25000, \"fecha\": \"2026-06-15\", \"hora\": \"11:00:00\", \"cliente\": { \"id\": 1, \"nombre\": \"Carlos Soto\" } },\n" +
                                    "  { \"id\": 4, \"monto\": 4500, \"fecha\": \"2026-06-18\", \"hora\": \"16:15:00\", \"cliente\": { \"id\": 1, \"nombre\": \"Carlos Soto\" } }\n" +
                                    "]"
                    )
            )
    )
    @ApiResponse(
            responseCode = "404",
            description = "Pedido no encontrado",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = @ExampleObject(
                            name = "Error: Cliente sin Pedidos",
                            value = "{\n" +
                                    "  \"fecha\": \"2026-06-19T13:09:40\",\n" +
                                    "  \"status\": 404,\n" +
                                    "  \"error\": \"Not Found\",\n" +
                                    "  \"mensaje\": \"El cliente con ID 1 no registra pedidos en el sistema\",\n" +
                                    "  \"path\": \"/api/v1/pedidos/cliente/1\"\n" +
                                    "}"
                    )
            )
    )
    @GetMapping("/cliente/{clienteId}")
    public ResponseEntity<List<PedidoDTO>> buscarPorCliente(@PathVariable Long clienteId) {
        return ResponseEntity.ok(pedidoService.buscarPorCliente(clienteId));
    }

    @Operation(
            summary = "Buscar pedidos por rango de fechas",
            description = "Obtiene todos los pedidos que se encuentran dentro del rango de fechas estipulado."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Pedidos encontrados",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = PedidoDTO.class)),
                    examples = @ExampleObject(
                            name = "Pedidos en Rango de Fechas",
                            value = "[\n" +
                                    "  { \"id\": 2, \"monto\": 8500, \"fecha\": \"2023-05-10\", \"hora\": \"09:15:00\", \"cliente\": { \"id\": 15, \"nombre\": \"Lucia Fernandez\" } }\n" +
                                    "]"
                    )
            )
    )
    @ApiResponse(
            responseCode = "404",
            description = "Pedido no encontrado",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class),
                    examples = @ExampleObject(
                            name = "Error: Rango sin Pedidos",
                            value = "{\n" +
                                    "  \"fecha\": \"2026-06-19T13:10:05\",\n" +
                                    "  \"status\": 404,\n" +
                                    "  \"error\": \"Not Found\",\n" +
                                    "  \"mensaje\": \"No se encontraron pedidos entre las fechas 2023-01-01 y 2023-12-31\",\n" +
                                    "  \"path\": \"/api/v1/pedidos/rango\"\n" +
                                    "}"
                    )
            )
    )
    @GetMapping("/rango")
    public ResponseEntity<List<PedidoDTO>> buscarPorRango(
            @Parameter(description = "Fecha de inicio (yyyy-MM-dd)", example = "2023-01-01")
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate inicio,
            @Parameter(description = "Fecha de término (yyyy-MM-dd)", example = "2023-12-31")
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fin) {
        return ResponseEntity.ok(pedidoService.buscarPorRangoFechas(inicio, fin));
    }
}