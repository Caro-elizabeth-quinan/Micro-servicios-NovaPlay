package cl.duoc.ventas_service.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalTime;

@Data
@JsonPropertyOrder({"id", "monto", "fecha", "hora", "cliente"})
public class PedidoDTO {
    private Long id;
    private Integer monto;
    private LocalDate fecha;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "HH:mm:ss")
    private LocalTime hora;
    private ClienteDTO cliente;
}
