package cl.duoc.vendedores_service.controller;

import cl.duoc.vendedores_service.dto.VendedorDTO;
import cl.duoc.vendedores_service.model.Vendedor;
import cl.duoc.vendedores_service.service.VendedorService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("api/v1/vendedores")
public class VendedorController {
    @Autowired
    private VendedorService vendedorService;

    @GetMapping
    public ResponseEntity<?> listar() {
        return ResponseEntity.ok(vendedorService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(
            // Id vendedor
            @PathVariable Long id) {
        // Busca vendedor por id.
        // Si no existe, el service lanzará error 404.
        return ResponseEntity.ok(
                vendedorService.findById(id)
        );
    }

    @PostMapping
    public ResponseEntity<?> registrar(
            // @Valid activa validaciones
            @Valid @RequestBody Vendedor vendedor
    ) {
        // Guarda vendedor
        Vendedor nuevo = vendedorService.save(vendedor);
        // Retorna status 201
        return new ResponseEntity<>(
                nuevo,
                HttpStatus.CREATED
        );
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> borrar(@PathVariable Long id) {
        vendedorService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> actualizar(
            @PathVariable Long id,
             @Valid @RequestBody Vendedor vendedor
    ) {
        Vendedor vendedor1 = vendedorService.update(id, vendedor);
        if (vendedor1 == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(vendedor1);
    }

    // 1. GET /api/v1/vendedores/buscar/apellido/Perez
    @GetMapping("/buscar/apellido/{apellido}")
    public ResponseEntity<List<Vendedor>> buscarApellido(@PathVariable String apellido) {
        return ResponseEntity.ok(vendedorService.buscarPorApellido(apellido));
    }

    // 2. GET /api/v1/vendedores/buscar/sueldo-mayor/500000
    @GetMapping("/buscar/sueldo-mayor/{monto}")
    public ResponseEntity<List<Vendedor>> buscarSueldo(@PathVariable int monto) {
        return ResponseEntity.ok(vendedorService.buscarSueldoMayor(monto));
    }

    // 3. GET /api/v1/vendedores/buscar/nombre?valor=Juan
    @GetMapping("/buscar/nombre")
    public ResponseEntity<List<Vendedor>> buscarNombre(@RequestParam String valor) {
        return ResponseEntity.ok(vendedorService.buscarPorNombre(valor));
    }

    // 4. GET /api/v1/vendedores/buscar/fecha?inicio=2023-01-01&fin=2023-12-31
    @GetMapping("/buscar/fecha")
    public ResponseEntity<List<Vendedor>> buscarPorFecha(
            @RequestParam String inicio,
            @RequestParam String fin) {
        return ResponseEntity.ok(vendedorService.buscarPorRangoFecha(
                LocalDate.parse(inicio),
                LocalDate.parse(fin)));
    }

}