package cl.duoc.boleta_service.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Boleta {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotNull(message = "El campo monto no puede estar vacio")
    @Column(nullable = false)
    @PositiveOrZero
    private int monto;

    @NotNull(message = "El campo fecha Emision no puede estar vacio")
    @Column(nullable = false)
    private LocalDate fechaEmision;

    @NotNull(message = "El campo iva no puede estar vacio")
    @PositiveOrZero(message = "El iva no puede un valor negativo")
    @Column(nullable = false)
    private int iva;
}
