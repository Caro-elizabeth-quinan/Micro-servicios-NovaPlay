package cl.duoc.login_service.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Login {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "El campo email no puede estar vacío")
    @Column(nullable = false)
    @Size(min = 3, max = 50)
    @Email(message = "El campo email debe tener formato correo [@ y Dom]")
    private String email;

    @NotBlank(message = "El campo contraseña no puede estar vacio")
    @Column(nullable = false)
    private String contrasena;
    //En el producto final el email y contraseña seria autogenerado con informacion del cliente
}
