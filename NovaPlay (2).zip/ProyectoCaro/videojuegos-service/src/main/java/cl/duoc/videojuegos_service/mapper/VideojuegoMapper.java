package cl.duoc.videojuegos_service.mapper;

import cl.duoc.videojuegos_service.dto.VideojuegoDTO;
import cl.duoc.videojuegos_service.model.Videojuego;
import org.springframework.stereotype.Component;

@Component
public class VideojuegoMapper {
    public VideojuegoDTO toDTO(Videojuego videojuego){
        VideojuegoDTO dto = new VideojuegoDTO();
        dto.setTitulo(videojuego.getTitulo());
        dto.setGenero(videojuego.getGenero());
        dto.setDescripcion(videojuego.getDescripcion());
        dto.setFechaLanzamiento(videojuego.getFechaLanzamiento());
        dto.setPrecio(videojuego.getPrecio());

        return dto;
    }
}
