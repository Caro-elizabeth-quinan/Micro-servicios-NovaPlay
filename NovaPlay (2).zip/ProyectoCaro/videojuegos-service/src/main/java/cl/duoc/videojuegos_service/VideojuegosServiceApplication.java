package cl.duoc.videojuegos_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@EnableDiscoveryClient
@SpringBootApplication
public class VideojuegosServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(VideojuegosServiceApplication.class, args);
	}

}
