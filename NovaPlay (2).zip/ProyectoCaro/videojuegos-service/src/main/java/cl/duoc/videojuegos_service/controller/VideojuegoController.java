package cl.duoc.videojuegos_service.controller;

import cl.duoc.videojuegos_service.dto.VideojuegoDTO;
import cl.duoc.videojuegos_service.model.Videojuego;
import cl.duoc.videojuegos_service.service.VideojuegoService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/v1/videojuegos")
public class VideojuegoController {
    @Autowired
    private VideojuegoService videojuegoService;

    @GetMapping
    public ResponseEntity<?> listar(){
        return  ResponseEntity.ok(videojuegoService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(@PathVariable Long id){
            // Busca videojuego por id.
            // Si no existe, el service lanzará error 404.
            return ResponseEntity.ok(
                    videojuegoService.findById(id)
            );
        }

    @PostMapping
    public ResponseEntity<?> registrar(
            // @Valid activa validaciones
            @Valid @RequestBody Videojuego videojuego
    ){
        // Guarda videojuego
        Videojuego nuevo = videojuegoService.save(videojuego);
        // Retorna status 201
        return new ResponseEntity<>(
                nuevo,
                HttpStatus.CREATED
        );
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> borrar(@PathVariable Long id){
        videojuegoService.delete(id);
        return ResponseEntity.noContent().build();
    }
    @PutMapping("/{id}")
    public ResponseEntity<?> actualizar(
            @PathVariable Long id,
            @Valid @RequestBody Videojuego videojuego
    ){
        // Actualiza videojuego.
        // Si no existe, el service lanzará error 404.
        return ResponseEntity.ok(
                videojuegoService.update(id, videojuego)
        );
    }

    // 1. GET /api/v1/videojuegos/buscar/genero/RPG
    @GetMapping("/buscar/genero/{genero}")
    public ResponseEntity<List<Videojuego>> filtrarPorGenero(@PathVariable String genero) {
        return ResponseEntity.ok(videojuegoService.buscarPorGenero(genero));
    }

    // 2. GET /api/v1/videojuegos/buscar/titulo?nombre=Zelda
    @GetMapping("/buscar/titulo")
    public ResponseEntity<List<Videojuego>> filtrarPorTitulo(@RequestParam String nombre) {
        return ResponseEntity.ok(videojuegoService.buscarPorTitulo(nombre));
    }

    // 3. GET /api/v1/videojuegos/buscar/ofertas/29990
    @GetMapping("/buscar/ofertas/{precioMax}")
    public ResponseEntity<List<Videojuego>> filtrarPorPrecio(@PathVariable int precioMax) {
        return ResponseEntity.ok(videojuegoService.buscarPorPrecioMaximo(precioMax));
    }
}
