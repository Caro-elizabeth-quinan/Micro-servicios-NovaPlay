package cl.duoc.videojuegos_service.dto;

import lombok.Data;
import java.time.LocalDate;

@Data
public class VideojuegoDTO {
    private String titulo;
    private String genero;
    private String descripcion;
    private LocalDate fechaLanzamiento;
    private int precio;
}
