package cl.duoc.videojuegos_service.service;

import cl.duoc.videojuegos_service.dto.VideojuegoDTO;
import cl.duoc.videojuegos_service.exception.ResourceNotFoundException;
import cl.duoc.videojuegos_service.mapper.VideojuegoMapper;
import cl.duoc.videojuegos_service.model.Videojuego;
import cl.duoc.videojuegos_service.repository.VideojuegoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VideojuegoService {

    @Autowired
    private VideojuegoRepository videojuegoRepository;

    @Autowired
    private VideojuegoMapper videojuegoMapper;

    public List<Videojuego> findAll() {
        return videojuegoRepository.findAll();
    }

    public Videojuego findById(Long id) {
        return videojuegoRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Videojuego no encontrado con id: " + id
                        )
                );
    }

    public Videojuego save(Videojuego videojuego) {
        return videojuegoRepository.save(videojuego);
    }

    public void delete(Long id) {
        // Verifica existencia
        if(!videojuegoRepository.existsById(id)){

            throw new ResourceNotFoundException(
                    "Videojuego no encontrado con id: " + id
            );
        }
        videojuegoRepository.deleteById(id);
    }

    public Videojuego update(Long id, Videojuego videojuego) {
        Videojuego videojuegoActualizar =
                videojuegoRepository.findById(id)
                        .orElseThrow(() -> new ResourceNotFoundException(
                                "Videojuego no encontrado con id: " + id)
                        );

        // Actualiza campos
        videojuegoActualizar.setTitulo(videojuego.getTitulo());
        videojuegoActualizar.setGenero(videojuego.getGenero());
        videojuegoActualizar.setDescripcion(videojuego.getDescripcion());
        videojuegoActualizar.setFechaLanzamiento(videojuego.getFechaLanzamiento());
        videojuegoActualizar.setPrecio(videojuego.getPrecio());

        return videojuegoRepository.save(videojuegoActualizar);
    }

    // Consulta 1: Por Género
    public List<Videojuego> buscarPorGenero(String genero) {
        return videojuegoRepository.findByGenero(genero);
    }

    // Consulta 2: Por Título
    public List<Videojuego> buscarPorTitulo(String titulo) {
        return videojuegoRepository.findByTituloContainingIgnoreCase(titulo);
    }

    // Consulta 3: Por Precio Máximo
    public List<Videojuego> buscarPorPrecioMaximo(int precio) {
        return videojuegoRepository.findByPrecioLessThanEqual(precio);
    }
}
