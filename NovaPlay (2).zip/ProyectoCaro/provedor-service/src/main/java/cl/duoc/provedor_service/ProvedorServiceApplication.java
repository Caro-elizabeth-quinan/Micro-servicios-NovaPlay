package cl.duoc.provedor_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@EnableDiscoveryClient
@SpringBootApplication
public class ProvedorServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProvedorServiceApplication.class, args);
	}

}
