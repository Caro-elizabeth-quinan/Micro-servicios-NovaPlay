package cl.duoc.provedor_service.controller;

import cl.duoc.provedor_service.dto.ProveedorDTO;
import cl.duoc.provedor_service.model.Proveedor;
import cl.duoc.provedor_service.service.ProveedorService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("api/v1/proveedores")
public class ProveedorControler {

    @Autowired
    private ProveedorService proveedorService;

    @GetMapping
    public ResponseEntity<?> listar(){
        return ResponseEntity.ok(proveedorService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(
            // Id del proveedor
            @PathVariable Long id
    ){
        // Busca proveedor por id.
        // Si no existe, el service lanzará error 404.
        return ResponseEntity.ok(
                proveedorService.findById(id)
        );
    }

    // Consulta 1: Nuevo Endpoint por RUT
    @GetMapping("/rut/{rut}")
    public ResponseEntity<?> buscarPorRut(
            // Rut del proveedor
            @PathVariable String rut
    ){
        // Busca proveedor por rut.
        // Si no existe, lanza error 404.
        return ResponseEntity.ok(
                proveedorService.findByRut(rut)
        );
    }

    // Consulta 2: Nuevo Endpoint Filtrar por nombre
    @GetMapping("/buscar")
    public ResponseEntity<?> buscarPorNombre(@RequestParam String nombre){
        List<Proveedor> lista = proveedorService.findByNombre(nombre);
        if (lista.isEmpty()) return ResponseEntity.noContent().build();
        return ResponseEntity.ok(lista);
    }

    @PostMapping
    public ResponseEntity<?> registrar(
            // @Valid activa validaciones
            @Valid @RequestBody Proveedor proveedor
    ){
        // Guarda proveedor
        Proveedor nuevo = proveedorService.save(proveedor);
        // Retorna status 201
        return new ResponseEntity<>(
                nuevo,
                HttpStatus.CREATED
        );
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> borrar(@PathVariable Long id){
        proveedorService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> actualizar(
            // Id del proveedor
            @PathVariable Long id,
            // Datos nuevos
            @Valid @RequestBody Proveedor proveedor
    ){
        // Actualiza proveedor.
        // Si no existe, lanza error 404.
        return ResponseEntity.ok(
                proveedorService.update(id, proveedor)
        );
    }



}
