package cl.duoc.ventas_service.dto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalTime;

@Data
@JsonPropertyOrder({"id","monto","fecha"})
public class PedidoDTO {
    private Long id;
    private Integer monto;
    private LocalDate fecha;
    private LocalTime hora;
    private ClienteDTO cliente;
}
