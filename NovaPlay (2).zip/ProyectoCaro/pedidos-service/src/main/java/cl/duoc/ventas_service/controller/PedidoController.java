package cl.duoc.ventas_service.controller;

import cl.duoc.ventas_service.dto.PedidoDTO;
import cl.duoc.ventas_service.model.Pedido;
import cl.duoc.ventas_service.service.PedidoService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("api/v1/pedidos")
public class PedidoController {
    @Autowired
    private PedidoService pedidoService;

    @GetMapping
    public ResponseEntity<?> listar(){
        return  ResponseEntity.ok(pedidoService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(
            // Id del pedido
            @PathVariable Long id
    ){
        // Busca pedido por id.
        // Si no existe, el service lanzará error 404.
        return ResponseEntity.ok(
                pedidoService.findById(id)
        );
    }

    @PostMapping
    public ResponseEntity<?> registrar(@Valid @RequestBody Pedido pedido){
        Pedido nuevo = pedidoService.save(pedido);
        return new ResponseEntity<>(nuevo, HttpStatus.CREATED);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> borrar(@PathVariable Long id){
        pedidoService.delete(id);
        return ResponseEntity.noContent().build();
    }
    @PutMapping("/{id}")
    public ResponseEntity<?> actualizar(
            @PathVariable Long id,
            @Valid @RequestBody Pedido pedido
    ){
        return ResponseEntity.ok(
                pedidoService.update(id, pedido)
        );
    }

    // Ejemplo: GET /api/v1/pedidos/buscar-fecha?fecha=2023-10-25
    @GetMapping("/buscar-fecha")
    public ResponseEntity<List<Pedido>> buscarPorFecha(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fecha) {
        return ResponseEntity.ok(pedidoService.buscarPorFecha(fecha));
    }

    // Ejemplo: GET /api/v1/pedidos/monto-minimo/5000
    @GetMapping("/monto-minimo/{monto}")
    public ResponseEntity<List<Pedido>> buscarPorMonto(@PathVariable int monto) {
        return ResponseEntity.ok(pedidoService.buscarPorMontoMinimo(monto));
    }

    // Ejemplo: GET /api/v1/pedidos/cliente/1
    @GetMapping("/cliente/{clienteId}")
    public ResponseEntity<List<Pedido>> buscarPorCliente(@PathVariable Long clienteId) {
        return ResponseEntity.ok(pedidoService.buscarPorCliente(clienteId));
    }

    // Ejemplo: GET /api/v1/pedidos/rango?inicio=2023-01-01&fin=2023-12-31
    @GetMapping("/rango")
    public ResponseEntity<List<Pedido>> buscarPorRango(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate inicio,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fin) {
        return ResponseEntity.ok(pedidoService.buscarPorRangoFechas(inicio, fin));
    }

    @GetMapping("/pendientes")
    public ResponseEntity<List<Pedido>> pedidosPendientes() {
        return ResponseEntity.ok(
                pedidoService.buscarPedidosPendientes()
        );
    }
}
