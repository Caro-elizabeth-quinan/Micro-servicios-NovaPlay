package cl.duoc.ventas_service.dto;

import lombok.Data;

@Data
public class DetalleVentaDTO {

    private Long id;

    private Long videojuegoId;

    private String tituloVideojuego;

    private Integer cantidad;

    private Integer precioUnitario;

    private Integer subtotal;
}