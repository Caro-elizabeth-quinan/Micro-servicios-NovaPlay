package cl.duoc.ventas_service.model;

import cl.duoc.ventas_service.dto.VentaDTO;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class DetalleVenta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // ID DEL VIDEOJUEGO
    private Long videojuegoId;

    // DATOS HISTORICOS
    private String tituloVideojuego;

    private Integer cantidad;

    private Integer precioUnitario;

    private Integer subtotal;
    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "venta_id")
    private Venta venta;
}