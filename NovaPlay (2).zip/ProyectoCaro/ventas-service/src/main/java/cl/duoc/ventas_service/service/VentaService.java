package cl.duoc.ventas_service.service;

import cl.duoc.ventas_service.clients.*;
import cl.duoc.ventas_service.dto.*;
import cl.duoc.ventas_service.exception.ResourceNotFoundException;
import cl.duoc.ventas_service.mapper.VentasMapper;
import cl.duoc.ventas_service.model.DetalleVenta;
import cl.duoc.ventas_service.model.Venta;
import cl.duoc.ventas_service.repository.VentaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class VentaService {

    @Autowired
    private VentaRepository ventaRepository;

    @Autowired
    private VideojuegosFeign videojuegoFeignClient;

    @Autowired
    private VentasMapper ventasMapper;

    @Autowired
    private BoletaFeign boletaFeign;

    @Autowired
    private ClientesFeign clientesFeign;

    @Autowired
    private VendedorFeign vendedorFeign;

    @Autowired
    private SucursalFeign sucursalFeign;

    public Venta crearVenta(VentaRequest request) {

        Venta venta = new Venta();

        venta.setBoleta(request.getBoleta());
        venta.setCliente(request.getCliente());
        venta.setVendedor(request.getVendedor());
        venta.setSucursal(request.getSucursal());

        venta.setFecha(LocalDate.now());
        venta.setHora(LocalTime.now());

        List<DetalleVenta> detalles = new ArrayList<>();

        int total = 0;

        for (DetalleVentaRequest item : request.getDetalles()) {

            // Consulta al microservicio videojuegos
            VideojuegosDTO videojuego =
                    videojuegoFeignClient.obtenerVideojuego(
                            item.getVideojuegoId()
                    );

            DetalleVenta detalle = new DetalleVenta();

            detalle.setVideojuegoId(videojuego.getId());

            detalle.setTituloVideojuego(
                    videojuego.getTitulo()
            );

            detalle.setCantidad(item.getCantidad());

            detalle.setPrecioUnitario(
                    videojuego.getPrecio()
            );

            int subtotal =
                    videojuego.getPrecio()
                            * item.getCantidad();

            detalle.setSubtotal(subtotal);

            // Relación con la venta
            detalle.setVenta(venta);

            detalles.add(detalle);

            total += subtotal;
        }

        venta.setDetalles(detalles);

        venta.setTotal(total);

        return ventaRepository.save(venta);
    }

    public List<Venta> listar() {
        return ventaRepository.findAll();
    }

    public VentaDTO buscar(Long id) {

        // Busca venta por id.
        // Si no existe, lanza error 404.
        Venta ventaOriginal = ventaRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Venta no encontrada con id: " + id
                        )
                );

        VentaDTO dto = ventasMapper.toDTO(ventaOriginal);

        // Obtiene datos de otros microservicios
        dto.setBoleta(
                boletaFeign.buscarPorId(ventaOriginal.getBoleta())
        );

        dto.setCliente(
                clientesFeign.buscarPorId(ventaOriginal.getCliente())
        );

        dto.setVendedor(
                vendedorFeign.buscarPorId(ventaOriginal.getVendedor())
        );

        dto.setSucursal(
                sucursalFeign.buscarPorid(ventaOriginal.getSucursal())
        );

        return dto;
    }

    // Consulta 1
    public List<Venta> buscarPorFecha(LocalDate fecha) {
        return ventaRepository.findByFecha(fecha);
    }

    // Consulta 2
    public List<Venta> buscarPorCliente(Long idCliente) {
        return ventaRepository.findByCliente(idCliente);
    }

    // Consulta 3
    public List<Venta> buscarPorSucursal(Long idSucursal) {
        return ventaRepository.findBySucursal(idSucursal);
    }

    // Consulta 4
    public List<Venta> buscarPorRangoTotal(Integer min, Integer max) {
        return ventaRepository.findByTotalBetween(min, max);
    }
}