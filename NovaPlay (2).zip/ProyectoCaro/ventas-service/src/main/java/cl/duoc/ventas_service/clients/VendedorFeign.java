package cl.duoc.ventas_service.clients;

import cl.duoc.ventas_service.dto.VendedorDTO;
import cl.duoc.ventas_service.dto.VentaDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "vendedores-service")
public interface VendedorFeign {

    @GetMapping("/api/v1/vendedores/{id}")
    VendedorDTO buscarPorId(@PathVariable Long id);
}
