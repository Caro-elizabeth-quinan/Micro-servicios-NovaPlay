package cl.duoc.ventas_service.controller;

import cl.duoc.ventas_service.dto.VentaDTO;
import cl.duoc.ventas_service.dto.VentaRequest;
import cl.duoc.ventas_service.model.Venta;
import cl.duoc.ventas_service.service.VentaService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
    @RequestMapping("api/v1/ventas")
public class VentaController {

    private final VentaService ventaService;

    public VentaController(VentaService ventaService) {
        this.ventaService = ventaService;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Venta crear(

            // @Valid activa validaciones
            @Valid @RequestBody VentaRequest request
    ) {

        // Crea nueva venta
        return ventaService.crearVenta(request);
    }

    @GetMapping
    public List<Venta> listar() {

        // Lista todas las ventas
        return ventaService.listar();
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(
            @PathVariable Long id
    ){

        // Busca venta por id.
        // Si no existe, el service lanza error 404.
        return ResponseEntity.ok(
                ventaService.buscar(id)
        );
    }

    // 1. Buscar por fecha
    // GET /api/v1/ventas/buscar/fecha/2024-05-13
    @GetMapping("/buscar/fecha/{fecha}")
    public List<Venta> porFecha(
            @PathVariable String fecha
    ) {

        return ventaService.buscarPorFecha(
                LocalDate.parse(fecha)
        );
    }

    // 2. Buscar por cliente
    // GET /api/v1/ventas/buscar/cliente/5
    @GetMapping("/buscar/cliente/{idCliente}")
    public List<Venta> porCliente(
            @PathVariable Long idCliente
    ) {

        return ventaService.buscarPorCliente(idCliente);
    }

    // 3. Buscar por sucursal
    // GET /api/v1/ventas/buscar/sucursal/10
    @GetMapping("/buscar/sucursal/{idSucursal}")
    public List<Venta> porSucursal(
            @PathVariable Long idSucursal
    ) {

        return ventaService.buscarPorSucursal(idSucursal);
    }

    // 4. Buscar por rango de total
    // GET /api/v1/ventas/buscar/rango?min=10000&max=50000
    @GetMapping("/buscar/rango")
    public List<Venta> porRangoTotal(
            @RequestParam Integer min,
            @RequestParam Integer max
    ) {

        return ventaService.buscarPorRangoTotal(min, max);
    }
}


