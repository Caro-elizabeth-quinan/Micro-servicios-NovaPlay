package cl.duoc.ventas_service.repository;

import cl.duoc.ventas_service.model.DetalleVenta;
import cl.duoc.ventas_service.model.Venta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DetalleVentaRepository extends JpaRepository<DetalleVenta, Long> {
}
