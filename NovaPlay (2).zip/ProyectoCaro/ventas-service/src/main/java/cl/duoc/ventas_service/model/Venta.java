package cl.duoc.ventas_service.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Venta {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    @NotNull(message = "El campo boleta no puede estar vacio")
    private Long boleta;

    @Column(nullable = false)
    @NotNull(message = "El campo fecha no puede estar vacio")
    private LocalDate fecha;

    @Column(nullable = false)
    @NotNull(message = "El campo hora no puede estar vacio")
    private LocalTime hora;

    @Column(nullable = false)
    @NotNull(message = "El campo cliente no puede estar vacio")
    private Long cliente;

    @Column(nullable = false)
    @NotNull(message = "El campo vendedor no puede estar vacio")//id_cliente
    private Long vendedor;  //id_vendedor

    @Column(nullable = false)
    @NotNull(message = "El campo sucursal no puede estar vacio")
    private Long sucursal;//cod_sucursal

    // RELACION 1 A MUCHOS
    @OneToMany(mappedBy = "venta",
            cascade = CascadeType.ALL,
            orphanRemoval = true)
    private List<DetalleVenta> detalles;

    private Integer total;


}
