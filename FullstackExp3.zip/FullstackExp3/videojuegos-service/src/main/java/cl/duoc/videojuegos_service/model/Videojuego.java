package cl.duoc.videojuegos_service.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;
import jakarta.validation.constraints.Size;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Videojuego {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long id;

    @NotBlank(message = "El campo titulo no puede estar vacio")
    @Column(nullable = false)
    @Size(min = 3, max = 50)
    private String titulo;

    @NotBlank(message = "El campo genero no puede estar vacio")
    @Column(nullable = false)
    private String genero;

    @Size(min = 3, max = 150)
    @NotBlank(message = "El campo descripcion no puede estar vacio")
    @Column(nullable = false)
    private String descripcion;

    @NotNull(message = "El campo fecha de lanzamiento no puede estar vacio")
    @Column(nullable = false)
    private LocalDate fechaLanzamiento;

    @NotNull(message = "El campo precio no puede estar vacio")
    @Column(nullable = false)
    @PositiveOrZero(message = "El campo precio no puede ser un valor negativo")
    private int precio;
}