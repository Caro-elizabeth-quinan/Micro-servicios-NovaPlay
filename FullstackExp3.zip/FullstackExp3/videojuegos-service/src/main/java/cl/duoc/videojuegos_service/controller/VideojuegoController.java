package cl.duoc.videojuegos_service.controller;

import cl.duoc.videojuegos_service.dto.VideojuegoInputDTO;
import cl.duoc.videojuegos_service.dto.VideojuegoDTO;
import cl.duoc.videojuegos_service.exception.ErrorResponse;
import cl.duoc.videojuegos_service.model.Videojuego;
import cl.duoc.videojuegos_service.service.VideojuegoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/v1/videojuegos")
@Tag(name = "Videojuego", description = "API para la gestión del catálogo de Videojuegos")
public class VideojuegoController {

    @Autowired
    private VideojuegoService videojuegoService;

    @Operation(
            summary = "Listar Videojuegos",
            description = "Método que lista todos los videojuegos registrados en el catálogo."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Videojuegos encontrados",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = VideojuegoDTO.class)),
                    examples = @ExampleObject(
                            name = "Ejemplo Catálogo",
                            value = "[\n" +
                                    "  { \"id\": 1, \"titulo\": \"The Last of Us Part I\", \"genero\": \"Acción\", \"precio\": 45000 },\n" +
                                    "  { \"id\": 2, \"titulo\": \"Factorio\", \"genero\": \"Estrategia\", \"precio\": 18500 }\n" +
                                    "]"
                    )
            )
    )
    @GetMapping
    public ResponseEntity<?> listar() {
        return ResponseEntity.ok(videojuegoService.findAll());
    }

    @Operation(
            summary = "Buscar Videojuego por ID",
            description = "Método que busca un videojuego a través de su ID numérico."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Videojuego encontrado",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = VideojuegoDTO.class)
            )
    )
    @ApiResponse(
            responseCode = "404",
            description = "Videojuego no encontrado",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class)
            )
    )
    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(
            @Parameter(description = "ID del videojuego a buscar", example = "1")
            @PathVariable("id") Long id
    ) {
        return ResponseEntity.ok(videojuegoService.findById(id));
    }

    @Operation(
            summary = "Registrar un Videojuego",
            description = "Método que registra un nuevo videojuego sin requerir un ID manual."
    )
    @ApiResponse(
            responseCode = "201",
            description = "Videojuego creado exitosamente",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = VideojuegoDTO.class)
            )
    )
    @ApiResponse(
            responseCode = "400",
            description = "Datos inválidos",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class)
            )
    )
    @PostMapping
    public ResponseEntity<?> registrar(@Valid @RequestBody VideojuegoInputDTO input) {
        Videojuego videojuego = new Videojuego();
        videojuego.setTitulo(input.getTitulo());
        videojuego.setGenero(input.getGenero());
        videojuego.setDescripcion(input.getDescripcion());
        videojuego.setFechaLanzamiento(input.getFechaLanzamiento());
        videojuego.setPrecio(input.getPrecio());

        Object nuevo = videojuegoService.save(videojuego);
        return new ResponseEntity<>(nuevo, HttpStatus.CREATED);
    }

    @Operation(
            summary = "Actualizar un Videojuego",
            description = "Método que actualiza los datos de un videojuego existente a partir de su ID."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Videojuego actualizado correctamente",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = VideojuegoDTO.class)
            )
    )
    @ApiResponse(
            responseCode = "400",
            description = "Datos inválidos",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class)
            )
    )
    @ApiResponse(
            responseCode = "404",
            description = "Videojuego no encontrado",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class)
            )
    )
    @PutMapping("/{id}")
    public ResponseEntity<?> actualizar(
            @PathVariable Long id,
            @Valid @RequestBody VideojuegoInputDTO input
    ) {
        Videojuego videojuego = new Videojuego();
        videojuego.setTitulo(input.getTitulo());
        videojuego.setGenero(input.getGenero());
        videojuego.setDescripcion(input.getDescripcion());
        videojuego.setFechaLanzamiento(input.getFechaLanzamiento());
        videojuego.setPrecio(input.getPrecio());

        return ResponseEntity.ok(videojuegoService.update(id, videojuego));
    }

    @Operation(
            summary = "Eliminar un Videojuego",
            description = "Método que elimina un videojuego del catálogo por su ID."
    )
    @ApiResponse(
            responseCode = "204",
            description = "Videojuego eliminado correctamente"
    )
    @ApiResponse(
            responseCode = "404",
            description = "Videojuego no encontrado",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class)
            )
    )
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> borrar(@PathVariable Long id) {
        videojuegoService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @Operation(
            summary = "Buscar videojuegos por título",
            description = "Obtiene los videojuegos cuyo título coincida de manera parcial."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Videojuegos encontrados",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = VideojuegoDTO.class))
            )
    )
    @ApiResponse(
            responseCode = "404",
            description = "No se encontraron videojuegos",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class)
            )
    )
    @GetMapping("/buscar/titulo")
    public ResponseEntity<List<VideojuegoDTO>> buscarPorTitulo(
            @Parameter(description = "Nombre o parte del título del videojuego", example = "Hollow Knight")
            @RequestParam String titulo
    ) {
        return ResponseEntity.ok(videojuegoService.buscarPorTitulo(titulo));
    }

    @Operation(
            summary = "Buscar ofertas por precio máximo",
            description = "Obtiene los videojuegos que tienen un precio menor o igual al indicado."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Videojuegos en oferta encontrados",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = VideojuegoDTO.class))
            )
    )
    @ApiResponse(
            responseCode = "404",
            description = "No se encontraron videojuegos",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class)
            )
    )
    @GetMapping("/buscar/ofertas/{precioMax}")
    public ResponseEntity<List<VideojuegoDTO>> buscarPorPrecioMaximo(
            @Parameter(description = "Monto tope del precio", example = "20000")
            @PathVariable int precioMax
    ) {
        return ResponseEntity.ok(videojuegoService.buscarPorPrecioMaximo(precioMax));
    }

    @Operation(
            summary = "Buscar videojuegos por género",
            description = "Obtiene todos los videojuegos asociados a un género específico."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Videojuegos del género encontrados",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = VideojuegoDTO.class))
            )
    )
    @ApiResponse(
            responseCode = "404",
            description = "No se encontraron videojuegos para el género indicado",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ErrorResponse.class)
            )
    )
    @GetMapping("/buscar/genero/{genero}")
    public ResponseEntity<List<VideojuegoDTO>> buscarPorGenero(
            @Parameter(description = "Género del videojuego", example = "Metroidvania")
            @PathVariable String genero
    ) {
        return ResponseEntity.ok(videojuegoService.buscarPorGenero(genero));
    }
}