package cl.duoc.videojuegos_service;

import cl.duoc.videojuegos_service.controller.VideojuegoController;
import cl.duoc.videojuegos_service.dto.VideojuegoDTO;
import cl.duoc.videojuegos_service.dto.VideojuegoInputDTO;
import cl.duoc.videojuegos_service.model.Videojuego;
import cl.duoc.videojuegos_service.service.VideojuegoService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import tools.jackson.databind.ObjectMapper;

import java.time.LocalDate;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.doNothing;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(VideojuegoController.class)
@DisplayName("Pruebas en la capa Controller de videojuegos")
class VideojuegoControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private VideojuegoService videojuegoService;

    private VideojuegoDTO videojuegoDTO;
    private VideojuegoInputDTO videojuegoInputDTO;

    @Autowired
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        // DTO de respuesta (lo que devuelve el service, ya con el ID generado por la BD)
        videojuegoDTO = new VideojuegoDTO();
        videojuegoDTO.setId(1L);
        videojuegoDTO.setTitulo("Hollow Knight");
        videojuegoDTO.setGenero("Metroidvania");
        videojuegoDTO.setDescripcion("Un metroidvania ambientado en el reino de Hallownest");
        videojuegoDTO.setFechaLanzamiento(LocalDate.of(2017, 2, 24));
        videojuegoDTO.setPrecio(15000);

        // Input que envía el cliente al crear/actualizar (sin ID)
        videojuegoInputDTO = new VideojuegoInputDTO();
        videojuegoInputDTO.setTitulo("Hollow Knight");
        videojuegoInputDTO.setGenero("Metroidvania");
        videojuegoInputDTO.setDescripcion("Un metroidvania ambientado en el reino de Hallownest");
        videojuegoInputDTO.setFechaLanzamiento(LocalDate.of(2017, 2, 24));
        videojuegoInputDTO.setPrecio(15000);
    }

    @Test
    @DisplayName("GET /api/v1/videojuegos - Debería retornar 200 OK y la lista de videojuegos")
    void testEndpointListar() throws Exception {
        // Arrange
        when(videojuegoService.findAll()).thenReturn(List.of(videojuegoDTO));

        // Act & Assert
        mockMvc.perform(get("/api/v1/videojuegos"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].titulo").value("Hollow Knight"))
                .andExpect(jsonPath("$[0].genero").value("Metroidvania"))
                .andExpect(jsonPath("$[0].precio").value(15000));
    }

    @Test
    @DisplayName("GET /api/v1/videojuegos/{id} - Debería retornar 200 OK y el videojuego encontrado")
    void testEndpointBuscarPorId() throws Exception {
        // Arrange
        when(videojuegoService.findById(1L)).thenReturn(videojuegoDTO);

        // Act & Assert
        mockMvc.perform(get("/api/v1/videojuegos/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.titulo").value("Hollow Knight"))
                .andExpect(jsonPath("$.genero").value("Metroidvania"))
                .andExpect(jsonPath("$.descripcion").value("Un metroidvania ambientado en el reino de Hallownest"))
                .andExpect(jsonPath("$.fechaLanzamiento").value("2017-02-24"))
                .andExpect(jsonPath("$.precio").value(15000));
    }

    @Test
    @DisplayName("POST /api/v1/videojuegos - Debería retornar 201 CREATED y el videojuego creado")
    void testEndpointRegistrar() throws Exception {
        // Arrange
        when(videojuegoService.save(any(Videojuego.class))).thenReturn(videojuegoDTO);

        // Act & Assert
        mockMvc.perform(post("/api/v1/videojuegos")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(videojuegoInputDTO)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.titulo").value("Hollow Knight"))
                .andExpect(jsonPath("$.genero").value("Metroidvania"))
                .andExpect(jsonPath("$.precio").value(15000));
    }

    @Test
    @DisplayName("PUT /api/v1/videojuegos/{id} - Debería retornar 200 OK y el videojuego actualizado")
    void testEndpointActualizar() throws Exception {
        // Arrange
        VideojuegoDTO actualizado = new VideojuegoDTO();
        actualizado.setId(1L);
        actualizado.setTitulo("Hollow Knight: Silksong");
        actualizado.setGenero("Metroidvania");
        actualizado.setDescripcion("La esperada secuela de Hollow Knight");
        actualizado.setFechaLanzamiento(LocalDate.of(2025, 9, 4));
        actualizado.setPrecio(20000);

        when(videojuegoService.update(eq(1L), any(Videojuego.class))).thenReturn(actualizado);

        // Act & Assert
        mockMvc.perform(put("/api/v1/videojuegos/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(videojuegoInputDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.titulo").value("Hollow Knight: Silksong"))
                .andExpect(jsonPath("$.precio").value(20000));
    }

    @Test
    @DisplayName("DELETE /api/v1/videojuegos/{id} - Debería retornar 204 NO CONTENT")
    void testEndpointBorrar() throws Exception {
        // Arrange
        doNothing().when(videojuegoService).delete(1L);

        // Act & Assert
        mockMvc.perform(delete("/api/v1/videojuegos/1"))
                .andExpect(status().isNoContent());
    }

    @Test
    @DisplayName("GET /api/v1/videojuegos/buscar/titulo - Debería retornar 200 OK y los videojuegos encontrados")
    void testEndpointBuscarPorTitulo() throws Exception {
        // Arrange
        when(videojuegoService.buscarPorTitulo("Hollow Knight")).thenReturn(List.of(videojuegoDTO));

        // Act & Assert
        mockMvc.perform(get("/api/v1/videojuegos/buscar/titulo")
                        .param("titulo", "Hollow Knight"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].titulo").value("Hollow Knight"))
                .andExpect(jsonPath("$[0].genero").value("Metroidvania"));
    }

    @Test
    @DisplayName("GET /api/v1/videojuegos/buscar/ofertas/{precioMax} - Debería retornar 200 OK y los videojuegos en oferta")
    void testEndpointBuscarPorPrecioMaximo() throws Exception {
        // Arrange
        when(videojuegoService.buscarPorPrecioMaximo(20000)).thenReturn(List.of(videojuegoDTO));

        // Act & Assert
        mockMvc.perform(get("/api/v1/videojuegos/buscar/ofertas/20000"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].titulo").value("Hollow Knight"))
                .andExpect(jsonPath("$[0].precio").value(15000));
    }

    @Test
    @DisplayName("GET /api/v1/videojuegos/buscar/genero/{genero} - Debería retornar 200 OK y los videojuegos del género")
    void testEndpointBuscarPorGenero() throws Exception {
        // Arrange
        when(videojuegoService.buscarPorGenero("Metroidvania")).thenReturn(List.of(videojuegoDTO));

        // Act & Assert
        mockMvc.perform(get("/api/v1/videojuegos/buscar/genero/Metroidvania"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].titulo").value("Hollow Knight"))
                .andExpect(jsonPath("$[0].genero").value("Metroidvania"));
    }
}
