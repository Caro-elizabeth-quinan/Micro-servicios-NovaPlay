package cl.duoc.ventas_service.dto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@Data
@JsonPropertyOrder({"id","nombre"})
public class ClienteDTO {
    private Long id;
    private String nombre;
}

