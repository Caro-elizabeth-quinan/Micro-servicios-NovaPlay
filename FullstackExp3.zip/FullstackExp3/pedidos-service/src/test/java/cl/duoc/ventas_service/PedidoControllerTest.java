package cl.duoc.ventas_service.controller;

import cl.duoc.ventas_service.dto.ClienteDTO;
import cl.duoc.ventas_service.dto.PedidoDTO;
import cl.duoc.ventas_service.dto.PedidoInputDTO;
import cl.duoc.ventas_service.exception.ResourceNotFoundException;
import cl.duoc.ventas_service.model.Pedido;
import cl.duoc.ventas_service.service.PedidoService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import tools.jackson.databind.ObjectMapper;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(PedidoController.class)
@DisplayName("Pruebas en la capa Controller de pedidos")
class PedidoControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private PedidoService pedidoService;

    private Pedido pedido;
    private PedidoDTO pedidoDTO;
    private PedidoInputDTO pedidoInputDTO;

    @Autowired
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        // Entidad tal como la devuelve el repository (listar, registrar, actualizar)
        pedido = new Pedido();
        pedido.setId(1L);
        pedido.setMonto(15000);
        pedido.setFecha(LocalDate.of(2026, 6, 19));
        pedido.setHora(LocalTime.of(10, 30));
        pedido.setCliente(10L);

        // DTO compuesto que devuelve findById y las búsquedas, enriquecido con el cliente vía Feign
        ClienteDTO clienteDTO = new ClienteDTO();
        clienteDTO.setId(10L);
        clienteDTO.setNombre("Juan Pérez");

        pedidoDTO = new PedidoDTO();
        pedidoDTO.setId(1L);
        pedidoDTO.setMonto(15000);
        pedidoDTO.setFecha(LocalDate.of(2026, 6, 19));
        pedidoDTO.setHora(LocalTime.of(10, 30));
        pedidoDTO.setCliente(clienteDTO);

        // Input que envía el cliente al crear/actualizar (sin ID)
        pedidoInputDTO = new PedidoInputDTO();
        pedidoInputDTO.setMonto(15000);
        pedidoInputDTO.setFecha(LocalDate.of(2026, 6, 19));
        pedidoInputDTO.setHora(LocalTime.of(10, 30));
        pedidoInputDTO.setCliente(10L);
    }

    @Test
    @DisplayName("GET /api/v1/pedidos - Debería retornar 200 OK y la lista de pedidos")
    void testEndpointListar() throws Exception {
        // Arrange
        when(pedidoService.findAll()).thenReturn(List.of(pedido));

        // Act & Assert
        mockMvc.perform(get("/api/v1/pedidos"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].monto").value(15000))
                .andExpect(jsonPath("$[0].fecha").value("2026-06-19"))
                .andExpect(jsonPath("$[0].cliente").value(10));
    }

    @Test
    @DisplayName("GET /api/v1/pedidos/{id} - Debería retornar 200 OK y el PedidoDTO con cliente")
    void testEndpointBuscarPorId() throws Exception {
        // Arrange
        when(pedidoService.findById(1L)).thenReturn(pedidoDTO);

        // Act & Assert
        mockMvc.perform(get("/api/v1/pedidos/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.monto").value(15000))
                .andExpect(jsonPath("$.fecha").value("2026-06-19"))
                .andExpect(jsonPath("$.hora").value("10:30:00"))
                .andExpect(jsonPath("$.cliente.id").value(10))
                .andExpect(jsonPath("$.cliente.nombre").value("Juan Pérez"));
    }

    @Test
    @DisplayName("GET /api/v1/pedidos/{id} - Debería retornar 404 NOT FOUND cuando el pedido no existe")
    void testEndpointBuscarPorIdNoEncontrado() throws Exception {
        // Arrange
        when(pedidoService.findById(99L))
                .thenThrow(new ResourceNotFoundException("Pedido no encontrado con id: 99"));

        // Act & Assert
        mockMvc.perform(get("/api/v1/pedidos/99"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.status").value(404))
                .andExpect(jsonPath("$.error").value("NOT FOUND"))
                .andExpect(jsonPath("$.mensaje").value("Pedido no encontrado con id: 99"))
                .andExpect(jsonPath("$.path").value("/api/v1/pedidos/99"));
    }

    @Test
    @DisplayName("POST /api/v1/pedidos - Debería retornar 201 CREATED y el pedido creado")
    void testEndpointRegistrar() throws Exception {
        // Arrange
        when(pedidoService.save(any(Pedido.class))).thenReturn(pedido);

        // Act & Assert
        mockMvc.perform(post("/api/v1/pedidos")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(pedidoInputDTO)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.monto").value(15000))
                .andExpect(jsonPath("$.cliente").value(10));
    }

    @Test
    @DisplayName("DELETE /api/v1/pedidos/{id} - Debería retornar 204 NO CONTENT")
    void testEndpointBorrar() throws Exception {
        // Arrange
        doNothing().when(pedidoService).delete(1L);

        // Act & Assert
        mockMvc.perform(delete("/api/v1/pedidos/1"))
                .andExpect(status().isNoContent());
    }

    @Test
    @DisplayName("DELETE /api/v1/pedidos/{id} - Debería retornar 404 NOT FOUND cuando el pedido a eliminar no existe")
    void testEndpointBorrarNoEncontrado() throws Exception {
        // Arrange
        doThrow(new ResourceNotFoundException("Pedido no encontrado con id: 3"))
                .when(pedidoService).delete(3L);

        // Act & Assert
        mockMvc.perform(delete("/api/v1/pedidos/3"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.mensaje").value("Pedido no encontrado con id: 3"));
    }

    @Test
    @DisplayName("PUT /api/v1/pedidos/{id} - Debería retornar 200 OK y el pedido actualizado")
    void testEndpointActualizar() throws Exception {
        // Arrange
        Pedido actualizado = new Pedido();
        actualizado.setId(1L);
        actualizado.setMonto(18000);
        actualizado.setFecha(LocalDate.of(2026, 6, 19));
        actualizado.setHora(LocalTime.of(10, 30));
        actualizado.setCliente(10L);

        when(pedidoService.update(eq(1L), any(Pedido.class))).thenReturn(actualizado);

        // Act & Assert
        mockMvc.perform(put("/api/v1/pedidos/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(pedidoInputDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.monto").value(18000));
    }

    @Test
    @DisplayName("PUT /api/v1/pedidos/{id} - Debería retornar 404 NOT FOUND cuando el pedido a actualizar no existe")
    void testEndpointActualizarNoEncontrado() throws Exception {
        // Arrange
        when(pedidoService.update(eq(99L), any(Pedido.class)))
                .thenThrow(new ResourceNotFoundException("Pedido no encontrado con id: 99"));

        // Act & Assert
        mockMvc.perform(put("/api/v1/pedidos/99")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(pedidoInputDTO)))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.mensaje").value("Pedido no encontrado con id: 99"));
    }

    @Test
    @DisplayName("GET /api/v1/pedidos/buscar-fecha - Debería retornar 200 OK y los pedidos de esa fecha")
    void testEndpointBuscarPorFecha() throws Exception {
        // Arrange
        when(pedidoService.buscarPorFecha(LocalDate.of(2023, 10, 25)))
                .thenReturn(List.of(pedidoDTO));

        // Act & Assert
        mockMvc.perform(get("/api/v1/pedidos/buscar-fecha")
                        .param("fecha", "2023-10-25"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].cliente.nombre").value("Juan Pérez"));
    }

    @Test
    @DisplayName("GET /api/v1/pedidos/monto-minimo/{monto} - Debería retornar 200 OK y los pedidos sobre el monto")
    void testEndpointBuscarPorMonto() throws Exception {
        // Arrange
        when(pedidoService.buscarPorMontoMinimo(10000)).thenReturn(List.of(pedidoDTO));

        // Act & Assert
        mockMvc.perform(get("/api/v1/pedidos/monto-minimo/10000"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].monto").value(15000));
    }

    @Test
    @DisplayName("GET /api/v1/pedidos/cliente/{clienteId} - Debería retornar 200 OK y los pedidos del cliente")
    void testEndpointBuscarPorCliente() throws Exception {
        // Arrange
        when(pedidoService.buscarPorCliente(10L)).thenReturn(List.of(pedidoDTO));

        // Act & Assert
        mockMvc.perform(get("/api/v1/pedidos/cliente/10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].cliente.id").value(10));
    }

    @Test
    @DisplayName("GET /api/v1/pedidos/rango - Debería retornar 200 OK y los pedidos dentro del rango")
    void testEndpointBuscarPorRango() throws Exception {
        // Arrange
        when(pedidoService.buscarPorRangoFechas(
                LocalDate.of(2023, 1, 1),
                LocalDate.of(2023, 12, 31)))
                .thenReturn(List.of(pedidoDTO));

        // Act & Assert
        mockMvc.perform(get("/api/v1/pedidos/rango")
                        .param("inicio", "2023-01-01")
                        .param("fin", "2023-12-31"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1));
    }
}