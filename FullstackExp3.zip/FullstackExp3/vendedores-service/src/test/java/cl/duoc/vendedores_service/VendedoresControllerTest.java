package cl.duoc.vendedores_service.controller;

import cl.duoc.vendedores_service.dto.LoginDTO;
import cl.duoc.vendedores_service.dto.VendedorDTO;
import cl.duoc.vendedores_service.dto.VendedorInputDTO;
import cl.duoc.vendedores_service.exception.ResourceNotFoundException;
import cl.duoc.vendedores_service.model.Vendedor;
import cl.duoc.vendedores_service.service.VendedorService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import tools.jackson.databind.ObjectMapper;

import java.time.LocalDate;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(VendedorController.class)
@DisplayName("Pruebas en la capa Controller de vendedores")
class VendedorControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private VendedorService vendedorService;

    private Vendedor vendedor;
    private VendedorDTO vendedorDTO;
    private VendedorInputDTO vendedorInputDTO;

    @Autowired
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        // Entidad tal como la devuelve el repository (listar, registrar, actualizar)
        vendedor = new Vendedor();
        vendedor.setId(1L);
        vendedor.setNombre("Juan");
        vendedor.setApellido("Pérez");
        vendedor.setSueldo(650000);
        vendedor.setFechaContrato(LocalDate.of(2025, 3, 10));
        vendedor.setLogin(2L);

        // DTO compuesto que devuelve buscarPorId, enriquecido con el login vía Feign
        LoginDTO loginDTO = new LoginDTO();
        loginDTO.setEmail("juan.perez@mail.com");

        vendedorDTO = new VendedorDTO();
        vendedorDTO.setNombreCompleto("Juan Pérez");
        vendedorDTO.setLogin(loginDTO);

        // Input que envía el cliente al crear/actualizar (sin ID)
        vendedorInputDTO = new VendedorInputDTO();
        vendedorInputDTO.setNombre("Juan");
        vendedorInputDTO.setApellido("Pérez");
        vendedorInputDTO.setSueldo(650000);
        vendedorInputDTO.setFechaContrato(LocalDate.of(2025, 3, 10));
        vendedorInputDTO.setLogin(2L);
    }

    @Test
    @DisplayName("GET /api/v1/vendedores - Debería retornar 200 OK y la lista de vendedores")
    void testEndpointListar() throws Exception {
        // Arrange
        when(vendedorService.findAll()).thenReturn(List.of(vendedor));

        // Act & Assert
        mockMvc.perform(get("/api/v1/vendedores"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].nombre").value("Juan"))
                .andExpect(jsonPath("$[0].apellido").value("Pérez"))
                .andExpect(jsonPath("$[0].sueldo").value(650000))
                .andExpect(jsonPath("$[0].fechaContrato").value("2025-03-10"))
                .andExpect(jsonPath("$[0].login").value(2));
    }

    @Test
    @DisplayName("GET /api/v1/vendedores/{id} - Debería retornar 200 OK y el VendedorDTO con login")
    void testEndpointBuscarPorId() throws Exception {
        // Arrange
        when(vendedorService.findById(1L)).thenReturn(vendedorDTO);

        // Act & Assert
        mockMvc.perform(get("/api/v1/vendedores/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nombreCompleto").value("Juan Pérez"))
                .andExpect(jsonPath("$.login.email").value("juan.perez@mail.com"));
    }

    @Test
    @DisplayName("GET /api/v1/vendedores/{id} - Debería retornar 404 NOT FOUND cuando el vendedor no existe")
    void testEndpointBuscarPorIdNoEncontrado() throws Exception {
        // Arrange
        when(vendedorService.findById(99L))
                .thenThrow(new ResourceNotFoundException("Vendedor no encontrado con id: 99"));

        // Act & Assert
        mockMvc.perform(get("/api/v1/vendedores/99"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.status").value(404))
                .andExpect(jsonPath("$.error").value("NOT FOUND"))
                .andExpect(jsonPath("$.mensaje").value("Vendedor no encontrado con id: 99"))
                .andExpect(jsonPath("$.path").value("/api/v1/vendedores/99"));
    }

    @Test
    @DisplayName("POST /api/v1/vendedores - Debería retornar 201 CREATED y el vendedor creado")
    void testEndpointRegistrar() throws Exception {
        // Arrange
        when(vendedorService.save(any(Vendedor.class))).thenReturn(vendedor);

        // Act & Assert
        mockMvc.perform(post("/api/v1/vendedores")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(vendedorInputDTO)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.nombre").value("Juan"))
                .andExpect(jsonPath("$.apellido").value("Pérez"))
                .andExpect(jsonPath("$.sueldo").value(650000))
                .andExpect(jsonPath("$.login").value(2));
    }

    @Test
    @DisplayName("PUT /api/v1/vendedores/{id} - Debería retornar 200 OK y el vendedor actualizado")
    void testEndpointActualizar() throws Exception {
        // Arrange
        Vendedor actualizado = new Vendedor();
        actualizado.setId(1L);
        actualizado.setNombre("Juan");
        actualizado.setApellido("Pérez");
        actualizado.setSueldo(750000);
        actualizado.setFechaContrato(LocalDate.of(2025, 3, 10));
        actualizado.setLogin(2L);

        when(vendedorService.update(eq(1L), any(Vendedor.class))).thenReturn(actualizado);

        // Act & Assert
        mockMvc.perform(put("/api/v1/vendedores/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(vendedorInputDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.sueldo").value(750000));
    }

    @Test
    @DisplayName("PUT /api/v1/vendedores/{id} - Debería retornar 404 NOT FOUND cuando el vendedor a actualizar no existe")
    void testEndpointActualizarNoEncontrado() throws Exception {
        // Arrange
        when(vendedorService.update(eq(88L), any(Vendedor.class)))
                .thenThrow(new ResourceNotFoundException("Vendedor no encontrado con id: 88"));

        // Act & Assert
        mockMvc.perform(put("/api/v1/vendedores/88")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(vendedorInputDTO)))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.mensaje").value("Vendedor no encontrado con id: 88"));
    }

    @Test
    @DisplayName("DELETE /api/v1/vendedores/{id} - Debería retornar 204 NO CONTENT")
    void testEndpointBorrar() throws Exception {
        // Arrange
        doNothing().when(vendedorService).delete(1L);

        // Act & Assert
        mockMvc.perform(delete("/api/v1/vendedores/1"))
                .andExpect(status().isNoContent());
    }

    @Test
    @DisplayName("DELETE /api/v1/vendedores/{id} - Debería retornar 404 NOT FOUND cuando el vendedor a eliminar no existe")
    void testEndpointBorrarNoEncontrado() throws Exception {
        // Arrange
        doThrow(new ResourceNotFoundException("Vendedor no encontrado con id: 99"))
                .when(vendedorService).delete(99L);

        // Act & Assert
        mockMvc.perform(delete("/api/v1/vendedores/99"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.mensaje").value("Vendedor no encontrado con id: 99"));
    }

    @Test
    @DisplayName("GET /api/v1/vendedores/buscar/apellido/{apellido} - Debería retornar 200 OK y los vendedores encontrados")
    void testEndpointBuscarApellido() throws Exception {
        // Arrange
        when(vendedorService.buscarPorApellido("Pérez")).thenReturn(List.of(vendedor));

        // Act & Assert
        mockMvc.perform(get("/api/v1/vendedores/buscar/apellido/Pérez"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].apellido").value("Pérez"));
    }

    @Test
    @DisplayName("GET /api/v1/vendedores/buscar/sueldo-mayor/{monto} - Debería retornar 200 OK y los vendedores con sueldo mayor")
    void testEndpointBuscarSueldo() throws Exception {
        // Arrange
        when(vendedorService.buscarSueldoMayor(500000)).thenReturn(List.of(vendedor));

        // Act & Assert
        mockMvc.perform(get("/api/v1/vendedores/buscar/sueldo-mayor/500000"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].sueldo").value(650000));
    }

    @Test
    @DisplayName("GET /api/v1/vendedores/buscar/nombre - Debería retornar 200 OK y los vendedores encontrados")
    void testEndpointBuscarNombre() throws Exception {
        // Arrange
        when(vendedorService.buscarPorNombre("Juan")).thenReturn(List.of(vendedor));

        // Act & Assert
        mockMvc.perform(get("/api/v1/vendedores/buscar/nombre")
                        .param("valor", "Juan"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].nombre").value("Juan"));
    }

    @Test
    @DisplayName("GET /api/v1/vendedores/buscar/fecha - Debería retornar 200 OK y los vendedores dentro del rango")
    void testEndpointBuscarPorFecha() throws Exception {
        // Arrange
        when(vendedorService.buscarPorRangoFecha(
                LocalDate.of(2023, 1, 1),
                LocalDate.of(2023, 12, 31)))
                .thenReturn(List.of(vendedor));

        // Act & Assert
        mockMvc.perform(get("/api/v1/vendedores/buscar/fecha")
                        .param("inicio", "2023-01-01")
                        .param("fin", "2023-12-31"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].nombre").value("Juan"));
    }
}
