package cl.duoc.vendedores_service.dto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;


import lombok.Data;

@Data
@JsonPropertyOrder({"email"})
public class LoginDTO {
    private String email;
}
