package cl.duoc.vendedores_service.dto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;


import lombok.Data;

@Data
@JsonPropertyOrder({"nombreCompleto","login"})
public class VendedorDTO {
    private String nombreCompleto;
    private LoginDTO login;
}
