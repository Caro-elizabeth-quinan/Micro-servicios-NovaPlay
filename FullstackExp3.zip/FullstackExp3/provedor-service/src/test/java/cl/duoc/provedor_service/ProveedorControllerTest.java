package cl.duoc.provedor_service;

import cl.duoc.provedor_service.controller.ProveedorControler;
import cl.duoc.provedor_service.dto.ProveedorDTO;
import cl.duoc.provedor_service.dto.ProveedorInputDTO;
import cl.duoc.provedor_service.exception.ResourceNotFoundException;
import cl.duoc.provedor_service.model.Proveedor;
import cl.duoc.provedor_service.service.ProveedorService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import tools.jackson.databind.ObjectMapper;

import java.util.Collections;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ProveedorControler.class)
@DisplayName("Pruebas en la capa Controller de proveedores")
class ProveedorControlerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private ProveedorService proveedorService;

    private Proveedor proveedor;
    private ProveedorDTO proveedorDTO;
    private ProveedorInputDTO proveedorInputDTO;

    @Autowired
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        // Entidad tal como la devuelve el repository (listar, registrar, actualizar)
        proveedor = new Proveedor();
        proveedor.setId(1L);
        proveedor.setRut("76.123.456-7");
        proveedor.setNombre("Proveedor Mayorista SpA");
        proveedor.setDireccion("Santiago Centro");

        // DTO resumido que devuelven findById y findByRut
        proveedorDTO = new ProveedorDTO();
        proveedorDTO.setRut("76.123.456-7");
        proveedorDTO.setNombre("Proveedor Mayorista SpA");
        proveedorDTO.setDireccion("Santiago Centro");

        // Input que envía el cliente al crear/actualizar (sin ID)
        proveedorInputDTO = new ProveedorInputDTO();
        proveedorInputDTO.setRut("76.123.456-7");
        proveedorInputDTO.setNombre("Proveedor Mayorista SpA");
        proveedorInputDTO.setDireccion("Santiago Centro");
    }

    @Test
    @DisplayName("GET /api/v1/proveedores/{id} - Debería retornar 200 OK y el ProveedorDTO encontrado")
    void testEndpointBuscarPorId() throws Exception {
        // Arrange
        when(proveedorService.findById(1L)).thenReturn(proveedorDTO);

        // Act & Assert
        mockMvc.perform(get("/api/v1/proveedores/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.rut").value("76.123.456-7"))
                .andExpect(jsonPath("$.nombre").value("Proveedor Mayorista SpA"))
                .andExpect(jsonPath("$.direccion").value("Santiago Centro"));
    }

    @Test
    @DisplayName("GET /api/v1/proveedores/{id} - Debería retornar 404 NOT FOUND cuando el proveedor no existe")
    void testEndpointBuscarPorIdNoEncontrado() throws Exception {
        // Arrange
        when(proveedorService.findById(99L))
                .thenThrow(new ResourceNotFoundException("Proveedor no encontrado con id: 99"));

        // Act & Assert
        mockMvc.perform(get("/api/v1/proveedores/99"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.status").value(404))
                .andExpect(jsonPath("$.error").value("NOT FOUND"))
                .andExpect(jsonPath("$.mensaje").value("Proveedor no encontrado con id: 99"))
                .andExpect(jsonPath("$.path").value("/api/v1/proveedores/99"));
    }

    @Test
    @DisplayName("PUT /api/v1/proveedores/{id} - Debería retornar 200 OK y el proveedor actualizado")
    void testEndpointActualizar() throws Exception {
        // Arrange
        Proveedor actualizado = new Proveedor();
        actualizado.setId(1L);
        actualizado.setRut("76.123.456-7");
        actualizado.setNombre("Proveedor Mayorista SpA");
        actualizado.setDireccion("Las Condes");

        when(proveedorService.update(eq(1L), any(Proveedor.class))).thenReturn(actualizado);

        // Act & Assert
        mockMvc.perform(put("/api/v1/proveedores/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(proveedorInputDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.direccion").value("Las Condes"));
    }

    @Test
    @DisplayName("PUT /api/v1/proveedores/{id} - Debería retornar 404 NOT FOUND cuando el proveedor a actualizar no existe")
    void testEndpointActualizarNoEncontrado() throws Exception {
        // Arrange
        when(proveedorService.update(eq(88L), any(Proveedor.class)))
                .thenThrow(new ResourceNotFoundException("Proveedor no encontrado con id: 88"));

        // Act & Assert
        mockMvc.perform(put("/api/v1/proveedores/88")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(proveedorInputDTO)))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.mensaje").value("Proveedor no encontrado con id: 88"));
    }

    @Test
    @DisplayName("DELETE /api/v1/proveedores/{id} - Debería retornar 204 NO CONTENT")
    void testEndpointBorrar() throws Exception {
        // Arrange
        doNothing().when(proveedorService).delete(1L);

        // Act & Assert
        mockMvc.perform(delete("/api/v1/proveedores/1"))
                .andExpect(status().isNoContent());
    }

    @Test
    @DisplayName("DELETE /api/v1/proveedores/{id} - Debería retornar 404 NOT FOUND cuando el proveedor a eliminar no existe")
    void testEndpointBorrarNoEncontrado() throws Exception {
        // Arrange
        doThrow(new ResourceNotFoundException("Proveedor no encontrado con id: 99"))
                .when(proveedorService).delete(99L);

        // Act & Assert
        mockMvc.perform(delete("/api/v1/proveedores/99"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.mensaje").value("Proveedor no encontrado con id: 99"));
    }

    @Test
    @DisplayName("GET /api/v1/proveedores - Debería retornar 200 OK y la lista de proveedores")
    void testEndpointListar() throws Exception {
        // Arrange
        when(proveedorService.findAll()).thenReturn(List.of(proveedor));

        // Act & Assert
        mockMvc.perform(get("/api/v1/proveedores"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].rut").value("76.123.456-7"))
                .andExpect(jsonPath("$[0].nombre").value("Proveedor Mayorista SpA"))
                .andExpect(jsonPath("$[0].direccion").value("Santiago Centro"));
    }

    @Test
    @DisplayName("POST /api/v1/proveedores - Debería retornar 201 CREATED y el proveedor creado")
    void testEndpointRegistrar() throws Exception {
        // Arrange
        when(proveedorService.save(any(Proveedor.class))).thenReturn(proveedor);

        // Act & Assert
        mockMvc.perform(post("/api/v1/proveedores")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(proveedorInputDTO)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.rut").value("76.123.456-7"))
                .andExpect(jsonPath("$.nombre").value("Proveedor Mayorista SpA"));
    }

    @Test
    @DisplayName("POST /api/v1/proveedores - Debería retornar 500 cuando el RUT ya está registrado")
    void testEndpointRegistrarRutDuplicado() throws Exception {
        // Arrange: el service lanza RuntimeException genérica (no ResourceNotFoundException),
        // por lo que la captura el handler de Exception.class -> 500, no 400, aunque el
        // Swagger documente 400. Este test refleja el comportamiento real del código actual.
        when(proveedorService.save(any(Proveedor.class)))
                .thenThrow(new RuntimeException("El RUT ya se encuentra registrado"));

        // Act & Assert
        mockMvc.perform(post("/api/v1/proveedores")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(proveedorInputDTO)))
                .andExpect(status().isInternalServerError())
                .andExpect(jsonPath("$.status").value(500))
                .andExpect(jsonPath("$.mensaje").value("El RUT ya se encuentra registrado"));
    }

    @Test
    @DisplayName("GET /api/v1/proveedores/rut/{rut} - Debería retornar 200 OK y el ProveedorDTO encontrado")
    void testEndpointBuscarPorRut() throws Exception {
        // Arrange
        when(proveedorService.findByRut("76.123.456-7")).thenReturn(proveedorDTO);

        // Act & Assert
        mockMvc.perform(get("/api/v1/proveedores/rut/76.123.456-7"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.rut").value("76.123.456-7"))
                .andExpect(jsonPath("$.nombre").value("Proveedor Mayorista SpA"));
    }

    @Test
    @DisplayName("GET /api/v1/proveedores/rut/{rut} - Debería retornar 404 NOT FOUND cuando el rut no existe")
    void testEndpointBuscarPorRutNoEncontrado() throws Exception {
        // Arrange
        when(proveedorService.findByRut("11.111.111-1"))
                .thenThrow(new ResourceNotFoundException("Proveedor no encontrado con rut: 11.111.111-1"));

        // Act & Assert
        mockMvc.perform(get("/api/v1/proveedores/rut/11.111.111-1"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.mensaje").value("Proveedor no encontrado con rut: 11.111.111-1"));
    }

    @Test
    @DisplayName("GET /api/v1/proveedores/buscar - Debería retornar 200 OK y los proveedores encontrados")
    void testEndpointBuscarPorNombre() throws Exception {
        // Arrange
        when(proveedorService.findByNombre("Mayorista")).thenReturn(List.of(proveedor));

        // Act & Assert
        mockMvc.perform(get("/api/v1/proveedores/buscar")
                        .param("nombre", "Mayorista"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].nombre").value("Proveedor Mayorista SpA"));
    }

    @Test
    @DisplayName("GET /api/v1/proveedores/buscar - Debería retornar 404 sin body cuando no hay coincidencias de nombre")
    void testEndpointBuscarPorNombreSinResultados() throws Exception {
        // Arrange: a diferencia de los demás 404, este lo construye el propio controller
        // (no el GlobalExceptionHandler), por lo que el body viene vacío, sin la forma
        // de ErrorResponse.
        when(proveedorService.findByNombre("Inexistente")).thenReturn(Collections.emptyList());

        // Act & Assert
        mockMvc.perform(get("/api/v1/proveedores/buscar")
                        .param("nombre", "Inexistente"))
                .andExpect(status().isNotFound())
                .andExpect(content().string(""));
    }
}
