package cl.duoc.clientes_service.controller;

import cl.duoc.clientes_service.dto.ClienteDTO;
import cl.duoc.clientes_service.dto.ClienteInputDTO;
import cl.duoc.clientes_service.dto.LoginDTO;
import cl.duoc.clientes_service.exception.ResourceNotFoundException;
import cl.duoc.clientes_service.model.Cliente;
import cl.duoc.clientes_service.service.ClienteService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import tools.jackson.databind.ObjectMapper;

import java.time.LocalDate;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ClienteController.class)
@DisplayName("Pruebas en la capa Controller de clientes")
class ClienteControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private ClienteService clienteService;

    private Cliente cliente;
    private ClienteDTO clienteDTO;
    private ClienteInputDTO clienteInputDTO;

    @Autowired
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        // Entidad tal como la devuelve el repository (listar, registrar, actualizar, búsquedas)
        cliente = new Cliente();
        cliente.setId(1L);
        cliente.setRut("12.345.678-9");
        cliente.setNombre("Juan");
        cliente.setApellido("Pérez");
        cliente.setFechaNacimiento(LocalDate.of(2000, 5, 15));
        cliente.setLogin(1L);

        // DTO compuesto que devuelve findById, enriquecido con el login vía Feign
        LoginDTO loginDTO = new LoginDTO();
        loginDTO.setEmail("juan.perez@mail.com");

        clienteDTO = new ClienteDTO();
        clienteDTO.setNombreCompleto("Juan Pérez");
        clienteDTO.setFechaNacimiento(LocalDate.of(2000, 5, 15));
        clienteDTO.setLogin(loginDTO);

        // Input que envía el cliente al crear/actualizar (sin ID)
        clienteInputDTO = new ClienteInputDTO();
        clienteInputDTO.setRut("12.345.678-9");
        clienteInputDTO.setNombre("Juan");
        clienteInputDTO.setApellido("Pérez");
        clienteInputDTO.setFechaNacimiento(LocalDate.of(2000, 5, 15));
        clienteInputDTO.setLogin(1L);
    }

    @Test
    @DisplayName("GET /api/v1/clientes/{id} - Debería retornar 200 OK y el ClienteDTO con login")
    void testEndpointBuscarPorId() throws Exception {
        // Arrange
        when(clienteService.findById(1L)).thenReturn(clienteDTO);

        // Act & Assert
        mockMvc.perform(get("/api/v1/clientes/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nombreCompleto").value("Juan Pérez"))
                .andExpect(jsonPath("$.fechaNacimiento").value("2000-05-15"))
                .andExpect(jsonPath("$.login.email").value("juan.perez@mail.com"));
    }

    @Test
    @DisplayName("GET /api/v1/clientes/{id} - Debería retornar 404 NOT FOUND cuando el cliente no existe")
    void testEndpointBuscarPorIdNoEncontrado() throws Exception {
        // Arrange
        when(clienteService.findById(99L))
                .thenThrow(new ResourceNotFoundException("Cliente no encontrado con id: 99"));

        // Act & Assert
        mockMvc.perform(get("/api/v1/clientes/99"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.status").value(404))
                .andExpect(jsonPath("$.error").value("NOT FOUND"))
                .andExpect(jsonPath("$.mensaje").value("Cliente no encontrado con id: 99"))
                .andExpect(jsonPath("$.path").value("/api/v1/clientes/99"));
    }

    @Test
    @DisplayName("PUT /api/v1/clientes/{id} - Debería retornar 200 OK y el cliente actualizado")
    void testEndpointActualizar() throws Exception {
        // Arrange
        Cliente actualizado = new Cliente();
        actualizado.setId(1L);
        actualizado.setRut("12.345.678-9");
        actualizado.setNombre("Juan");
        actualizado.setApellido("Pérez González");
        actualizado.setFechaNacimiento(LocalDate.of(2000, 5, 15));
        actualizado.setLogin(1L);

        when(clienteService.update(eq(1L), any(Cliente.class))).thenReturn(actualizado);

        // Act & Assert
        mockMvc.perform(put("/api/v1/clientes/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(clienteInputDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.apellido").value("Pérez González"));
    }

    @Test
    @DisplayName("PUT /api/v1/clientes/{id} - Debería retornar 404 NOT FOUND cuando el cliente a actualizar no existe")
    void testEndpointActualizarNoEncontrado() throws Exception {
        // Arrange
        when(clienteService.update(eq(99L), any(Cliente.class)))
                .thenThrow(new ResourceNotFoundException("Cliente no encontrado con id: 99"));

        // Act & Assert
        mockMvc.perform(put("/api/v1/clientes/99")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(clienteInputDTO)))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.mensaje").value("Cliente no encontrado con id: 99"));
    }

    @Test
    @DisplayName("DELETE /api/v1/clientes/{id} - Debería retornar 204 NO CONTENT")
    void testEndpointBorrar() throws Exception {
        // Arrange
        doNothing().when(clienteService).delete(1L);

        // Act & Assert
        mockMvc.perform(delete("/api/v1/clientes/1"))
                .andExpect(status().isNoContent());
    }

    @Test
    @DisplayName("DELETE /api/v1/clientes/{id} - Debería retornar 404 NOT FOUND cuando el cliente a eliminar no existe")
    void testEndpointBorrarNoEncontrado() throws Exception {
        // Arrange
        doThrow(new ResourceNotFoundException("Cliente no encontrado con id: 99"))
                .when(clienteService).delete(99L);

        // Act & Assert
        mockMvc.perform(delete("/api/v1/clientes/99"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.mensaje").value("Cliente no encontrado con id: 99"));
    }

    @Test
    @DisplayName("GET /api/v1/clientes - Debería retornar 200 OK y la lista de clientes")
    void testEndpointListar() throws Exception {
        // Arrange
        when(clienteService.findAll()).thenReturn(List.of(cliente));

        // Act & Assert
        mockMvc.perform(get("/api/v1/clientes"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].rut").value("12.345.678-9"))
                .andExpect(jsonPath("$[0].nombre").value("Juan"))
                .andExpect(jsonPath("$[0].apellido").value("Pérez"))
                .andExpect(jsonPath("$[0].fechaNacimiento").value("2000-05-15"))
                .andExpect(jsonPath("$[0].login").value(1));
    }

    @Test
    @DisplayName("POST /api/v1/clientes - Debería retornar 201 CREATED y el cliente creado")
    void testEndpointRegistrar() throws Exception {
        // Arrange
        when(clienteService.save(any(Cliente.class))).thenReturn(cliente);

        // Act & Assert
        mockMvc.perform(post("/api/v1/clientes")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(clienteInputDTO)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.rut").value("12.345.678-9"))
                .andExpect(jsonPath("$.nombre").value("Juan"))
                .andExpect(jsonPath("$.login").value(1));
    }

    @Test
    @DisplayName("GET /api/v1/clientes/mayores - Debería retornar 200 OK y los clientes mayores de edad")
    void testEndpointBuscarMayoresEdad() throws Exception {
        // Arrange
        when(clienteService.buscarMayoresEdad()).thenReturn(List.of(cliente));

        // Act & Assert
        mockMvc.perform(get("/api/v1/clientes/mayores"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].nombre").value("Juan"));
    }

    @Test
    @DisplayName("GET /api/v1/clientes/buscar-rut - Debería retornar 200 OK y el cliente encontrado")
    void testEndpointBuscarPorRut() throws Exception {
        // Arrange
        when(clienteService.buscarPorRut("12.345.678-9")).thenReturn(cliente);

        // Act & Assert
        mockMvc.perform(get("/api/v1/clientes/buscar-rut")
                        .param("rut", "12.345.678-9"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.rut").value("12.345.678-9"))
                .andExpect(jsonPath("$.nombre").value("Juan"));
    }

    @Test
    @DisplayName("GET /api/v1/clientes/buscar-rut - Debería retornar 404 NOT FOUND cuando el rut no existe")
    void testEndpointBuscarPorRutNoEncontrado() throws Exception {
        // Arrange
        when(clienteService.buscarPorRut("11.111.111-1"))
                .thenThrow(new ResourceNotFoundException("Cliente no encontrado con rut: 11.111.111-1"));

        // Act & Assert
        mockMvc.perform(get("/api/v1/clientes/buscar-rut")
                        .param("rut", "11.111.111-1"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.mensaje").value("Cliente no encontrado con rut: 11.111.111-1"));
    }

    @Test
    @DisplayName("GET /api/v1/clientes/buscar-fechas - Debería retornar 200 OK y los clientes dentro del rango")
    void testEndpointBuscarPorRangoFecha() throws Exception {
        // Arrange
        when(clienteService.buscarPorRangoFecha(
                LocalDate.of(1990, 1, 1),
                LocalDate.of(2005, 12, 31)))
                .thenReturn(List.of(cliente));

        // Act & Assert
        mockMvc.perform(get("/api/v1/clientes/buscar-fechas")
                        .param("inicio", "1990-01-01")
                        .param("fin", "2005-12-31"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].nombre").value("Juan"));
    }

    @Test
    @DisplayName("GET /api/v1/clientes/buscar-apellido - Debería retornar 200 OK y los clientes encontrados")
    void testEndpointBuscarPorApellido() throws Exception {
        // Arrange
        when(clienteService.buscarPorApellido("Pérez")).thenReturn(List.of(cliente));

        // Act & Assert
        mockMvc.perform(get("/api/v1/clientes/buscar-apellido")
                        .param("apellido", "Pérez"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].apellido").value("Pérez"));
    }
}