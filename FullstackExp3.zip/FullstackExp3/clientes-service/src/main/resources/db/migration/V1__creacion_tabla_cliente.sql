create table cliente(
    id bigint auto_increment primary key,
    rut VARCHAR(13) NOT NULL UNIQUE ,
    nombre varchar(50) not null,
    apellido varchar(50) not null,
    fecha_nacimiento date not null,
    login bigint not null
)
