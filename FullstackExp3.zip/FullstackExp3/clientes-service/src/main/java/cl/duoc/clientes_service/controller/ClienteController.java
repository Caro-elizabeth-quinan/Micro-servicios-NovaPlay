package cl.duoc.clientes_service.controller;

import cl.duoc.clientes_service.dto.ClienteDTO;
import cl.duoc.clientes_service.dto.ClienteInputDTO;
import cl.duoc.clientes_service.exception.ErrorResponse;
import cl.duoc.clientes_service.model.Cliente;
import cl.duoc.clientes_service.service.ClienteService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("api/v1/clientes")
@Tag(name = "Clientes", description = "API para la administración de clientes y consultas demográficas avanzadas")
public class ClienteController {

    @Autowired
    private ClienteService clienteService;

    @Operation(
            summary = "Buscar cliente por ID",
            description = "Recupera un cliente por su identificador único junto con sus datos de login consumidos por Feign."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Cliente localizado y mapeado a DTO con éxito",
            content = @Content(
                    mediaType = "application/json",
                    schema = @Schema(implementation = ClienteDTO.class)
            )
    )
    @ApiResponse(
            responseCode = "404",
            description = "Cliente no encontrado con el ID suministrado",
            content = @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))
    )
    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(
            @Parameter(description = "ID interno del cliente", example = "1")
            @PathVariable Long id
    ) {
        return ResponseEntity.ok(clienteService.findById(id));
    }

    @Operation(
            summary = "Actualizar cliente",
            description = "Actualiza el perfil completo del cliente localizándolo a través de su ID numérico."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Cliente modificado exitosamente",
            content = @Content(mediaType = "application/json", schema = @Schema(implementation = Cliente.class))
    )
    @ApiResponse(
            responseCode = "404",
            description = "No se pudo actualizar, cliente no existente",
            content = @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))
    )
    @PutMapping("/{id}")
    public ResponseEntity<?> actualizar(
            @Parameter(description = "ID interno del cliente", example = "1")
            @PathVariable Long id,
            @Valid @RequestBody ClienteInputDTO input
    ) {
        Cliente cliente = new Cliente();
        cliente.setRut(input.getRut());
        cliente.setNombre(input.getNombre());
        cliente.setApellido(input.getApellido());
        cliente.setFechaNacimiento(input.getFechaNacimiento());
        cliente.setLogin(input.getLogin());

        return ResponseEntity.ok(clienteService.update(id, cliente));
    }

    @Operation(
            summary = "Eliminar cliente",
            description = "Remueve permanentemente el registro de un cliente del sistema por su ID."
    )
    @ApiResponse(
            responseCode = "204",
            description = "Cliente borrado de forma satisfactoria (Sin contenido)",
            content = @Content(mediaType = "application/json", schema = @Schema(hidden = true))
    )
    @ApiResponse(
            responseCode = "404",
            description = "Cliente no encontrado para remover",
            content = @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))
    )
    @DeleteMapping("/{id}")
    public ResponseEntity<?> borrar(
            @Parameter(description = "ID interno del cliente", example = "1")
            @PathVariable Long id) {
        clienteService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @Operation(
            summary = "Listar clientes",
            description = "Obtiene una lista global con todos los registros de clientes de la base de datos."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Colección de clientes recuperada",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = Cliente.class))
            )
    )
    @GetMapping
    public ResponseEntity<?> listar() {
        return ResponseEntity.ok(clienteService.findAll());
    }

    @Operation(
            summary = "Registrar cliente",
            description = "Crea una nueva ficha de cliente validando los datos obligatorios solicitados."
    )
    @ApiResponse(
            responseCode = "201",
            description = "Cliente registrado en la plataforma",
            content = @Content(mediaType = "application/json", schema = @Schema(implementation = Cliente.class))
    )
    @ApiResponse(
            responseCode = "400",
            description = "Datos inválidos en el cuerpo de la petición",
            content = @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))
    )
    @PostMapping
    public ResponseEntity<?> registrar(@Valid @RequestBody ClienteInputDTO input) {
        Cliente cliente = new Cliente();
        cliente.setRut(input.getRut());
        cliente.setNombre(input.getNombre());
        cliente.setApellido(input.getApellido());
        cliente.setFechaNacimiento(input.getFechaNacimiento());
        cliente.setLogin(input.getLogin());

        Cliente nuevo = clienteService.save(cliente);
        return new ResponseEntity<>(nuevo, HttpStatus.CREATED);
    }

    @Operation(
            summary = "Listar clientes mayores de edad",
            description = "Filtra de manera automática los clientes cuya edad calculada supera los 18 años."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Lista filtrada por mayoría de edad",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = Cliente.class))
            )
    )
    @GetMapping("/mayores")
    public ResponseEntity<?> buscarMayoresEdad() {
        return ResponseEntity.ok(clienteService.buscarMayoresEdad());
    }

    @Operation(
            summary = "Buscar por RUT",
            description = "Busca de forma directa un cliente ingresando su número de RUT único."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Cliente localizado por RUT",
            content = @Content(mediaType = "application/json", schema = @Schema(implementation = Cliente.class))
    )
    @ApiResponse(
            responseCode = "404",
            description = "No existe un cliente registrado con ese RUT",
            content = @Content(mediaType = "application/json", schema = @Schema(implementation = ErrorResponse.class))
    )
    @GetMapping("/buscar-rut")
    public ResponseEntity<?> buscarPorRut(
            @Parameter(description = "RUT completo del cliente a buscar", example = "12.345.678-9")
            @RequestParam String rut
    ) {
        return ResponseEntity.ok(clienteService.buscarPorRut(rut));
    }

    @Operation(
            summary = "Buscar por rango de fechas",
            description = "Filtra la lista de clientes que nacieron dentro de un periodo de tiempo determinado."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Clientes que cumplen con el rango de fechas",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = Cliente.class))
            )
    )
    @GetMapping("/buscar-fechas")
    public ResponseEntity<?> buscarPorRangoFecha(
            @Parameter(description = "Fecha inicial del rango (yyyy-MM-dd)", example = "1990-01-01")
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate inicio,
            @Parameter(description = "Fecha final del rango (yyyy-MM-dd)", example = "2005-12-31")
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fin
    ) {
        return ResponseEntity.ok(clienteService.buscarPorRangoFecha(inicio, fin));
    }

    @Operation(
            summary = "Buscar por apellido",
            description = "Encuentra clientes realizando coincidencias parciales por texto en el apellido."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Clientes localizados por apellido",
            content = @Content(
                    mediaType = "application/json",
                    array = @ArraySchema(schema = @Schema(implementation = Cliente.class))
            )
    )
    @GetMapping("/buscar-apellido")
    public ResponseEntity<?> buscarPorApellido(
            @Parameter(description = "Apellido o parte del apellido a buscar", example = "Perez")
            @RequestParam String apellido
    ) {
        return ResponseEntity.ok(clienteService.buscarPorApellido(apellido));
    }
}