package cl.duoc.clientes_service.dto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

import java.time.LocalDate;

@Data
@JsonPropertyOrder({"nombreCompleto","fechaNacimiento","login"})
public class ClienteDTO {
    private String nombreCompleto;
    private LocalDate fechaNacimiento;
    private LoginDTO login;
}
