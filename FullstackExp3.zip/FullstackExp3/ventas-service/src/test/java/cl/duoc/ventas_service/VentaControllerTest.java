package cl.duoc.ventas_service;

import cl.duoc.ventas_service.controller.VentaController;
import cl.duoc.ventas_service.dto.BoletaDTO;
import cl.duoc.ventas_service.dto.ClienteDTO;
import cl.duoc.ventas_service.dto.DetalleVentaDTO;
import cl.duoc.ventas_service.dto.DetalleVentaRequest;
import cl.duoc.ventas_service.dto.ProveedorDTO;
import cl.duoc.ventas_service.dto.SucursalDTO;
import cl.duoc.ventas_service.dto.VendedorDTO;
import cl.duoc.ventas_service.dto.VentaDTO;
import cl.duoc.ventas_service.dto.VentaRequest;
import cl.duoc.ventas_service.service.VentaService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import tools.jackson.databind.ObjectMapper;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(VentaController.class)
@DisplayName("Pruebas en la capa Controller de ventas")
class VentaControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private VentaService ventaService;

    private VentaDTO ventaDTO;
    private VentaRequest ventaRequest;

    @Autowired
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        // Detalle de la venta (un videojuego dentro de la boleta)
        DetalleVentaDTO detalleDTO = new DetalleVentaDTO();
        detalleDTO.setId(1L);
        detalleDTO.setVideojuegoId(10L);
        detalleDTO.setCantidad(2);
        detalleDTO.setPrecioUnitario(15000);
        detalleDTO.setSubtotal(30000);

        // Boleta asociada a la venta
        BoletaDTO boletaDTO = new BoletaDTO();
        boletaDTO.setId(1L);
        boletaDTO.setMonto(30000);
        boletaDTO.setFechaEmision(LocalDate.of(2024, 5, 13));
        boletaDTO.setIva("19%");

        // Cliente y vendedor asociados a la venta
        ClienteDTO clienteDTO = new ClienteDTO();
        clienteDTO.setNombreCompleto("María González");

        VendedorDTO vendedorDTO = new VendedorDTO();
        vendedorDTO.setNombreCompleto("Pedro Soto");

        // Proveedor de la sucursal
        ProveedorDTO proveedorDTO = new ProveedorDTO();
        proveedorDTO.setRut("76.123.456-7");
        proveedorDTO.setNombre("Distribuidora GameTech");
        proveedorDTO.setDireccion("Av. Siempre Viva 123");

        // Sucursal asociada a la venta
        SucursalDTO sucursalDTO = new SucursalDTO();
        sucursalDTO.setNombre("Sucursal Centro");
        sucursalDTO.setCalle("Av. Principal 456");
        sucursalDTO.setProvedor(proveedorDTO);

        // DTO de respuesta enriquecido (lo que devuelve el service tras consultar los Feign)
        ventaDTO = new VentaDTO();
        ventaDTO.setBoleta(boletaDTO);
        ventaDTO.setFecha(LocalDate.of(2024, 5, 13));
        ventaDTO.setHora(LocalTime.of(10, 30));
        ventaDTO.setCliente(clienteDTO);
        ventaDTO.setVendedor(vendedorDTO);
        ventaDTO.setSucursal(sucursalDTO);
        ventaDTO.setDetalles(List.of(detalleDTO));
        ventaDTO.setTotal(30000);

        // Detalle de la solicitud (lo que envía el cliente en el body del POST)
        DetalleVentaRequest detalleRequest = new DetalleVentaRequest();
        detalleRequest.setVideojuegoId(10L);
        detalleRequest.setCantidad(2);

        // Request de creación de venta
        ventaRequest = new VentaRequest();
        ventaRequest.setBoleta(1L);
        ventaRequest.setCliente(5L);
        ventaRequest.setVendedor(2L);
        ventaRequest.setSucursal(10L);
        ventaRequest.setDetalles(List.of(detalleRequest));
    }

    @Test
    @DisplayName("POST /api/v1/ventas - Debería retornar 201 CREATED y la venta creada")
    void testEndpointCrear() throws Exception {
        // Arrange
        when(ventaService.crearVenta(any(VentaRequest.class)))
                .thenReturn(ventaDTO);

        // Act & Assert
        mockMvc.perform(post("/api/v1/ventas")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(ventaRequest)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.fecha").value("2024-05-13"))
                .andExpect(jsonPath("$.total").value(30000))
                .andExpect(jsonPath("$.boleta.monto").value(30000))
                .andExpect(jsonPath("$.cliente.nombreCompleto").value("María González"))
                .andExpect(jsonPath("$.vendedor.nombreCompleto").value("Pedro Soto"))
                .andExpect(jsonPath("$.sucursal.nombre").value("Sucursal Centro"))
                .andExpect(jsonPath("$.detalles[0].videojuegoId").value(10))
                .andExpect(jsonPath("$.detalles[0].cantidad").value(2))
                .andExpect(jsonPath("$.detalles[0].subtotal").value(30000));
    }

    @Test
    @DisplayName("GET /api/v1/ventas - Debería retornar 200 OK y la lista de ventas")
    void testEndpointListar() throws Exception {
        // Arrange
        when(ventaService.listar()).thenReturn(List.of(ventaDTO));

        // Act & Assert
        mockMvc.perform(get("/api/v1/ventas"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].fecha").value("2024-05-13"))
                .andExpect(jsonPath("$[0].total").value(30000))
                .andExpect(jsonPath("$[0].detalles[0].videojuegoId").value(10));
    }

    @Test
    @DisplayName("GET /api/v1/ventas/{id} - Debería retornar 200 OK y la venta encontrada")
    void testEndpointBuscarPorId() throws Exception {
        // Arrange
        when(ventaService.buscar(1L)).thenReturn(ventaDTO);

        // Act & Assert
        mockMvc.perform(get("/api/v1/ventas/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.fecha").value("2024-05-13"))
                .andExpect(jsonPath("$.hora").value("10:30:00"))
                .andExpect(jsonPath("$.total").value(30000));
    }

    @Test
    @DisplayName("GET /api/v1/ventas/buscar/fecha/{fecha} - Debería retornar 200 OK y las ventas de esa fecha")
    void testEndpointPorFecha() throws Exception {
        // Arrange
        when(ventaService.buscarPorFecha("2024-05-13")).thenReturn(List.of(ventaDTO));

        // Act & Assert
        mockMvc.perform(get("/api/v1/ventas/buscar/fecha/2024-05-13"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].fecha").value("2024-05-13"))
                .andExpect(jsonPath("$[0].total").value(30000));
    }

    @Test
    @DisplayName("GET /api/v1/ventas/buscar/cliente/{idCliente} - Debería retornar 200 OK y las ventas del cliente")
    void testEndpointPorCliente() throws Exception {
        // Arrange
        when(ventaService.buscarPorCliente(5L)).thenReturn(List.of(ventaDTO));

        // Act & Assert
        mockMvc.perform(get("/api/v1/ventas/buscar/cliente/5"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].cliente.nombreCompleto").value("María González"))
                .andExpect(jsonPath("$[0].total").value(30000));
    }

    @Test
    @DisplayName("GET /api/v1/ventas/buscar/sucursal/{idSucursal} - Debería retornar 200 OK y las ventas de la sucursal")
    void testEndpointPorSucursal() throws Exception {
        // Arrange
        when(ventaService.buscarPorSucursal(10L)).thenReturn(List.of(ventaDTO));

        // Act & Assert
        mockMvc.perform(get("/api/v1/ventas/buscar/sucursal/10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].sucursal.nombre").value("Sucursal Centro"))
                .andExpect(jsonPath("$[0].total").value(30000));
    }

    @Test
    @DisplayName("GET /api/v1/ventas/buscar/rango - Debería retornar 200 OK y las ventas dentro del rango")
    void testEndpointPorRangoTotal() throws Exception {
        // Arrange
        when(ventaService.buscarPorRangoTotal(10000, 50000)).thenReturn(List.of(ventaDTO));

        // Act & Assert
        mockMvc.perform(get("/api/v1/ventas/buscar/rango")
                        .param("min", "10000")
                        .param("max", "50000"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].total").value(30000));
    }
}