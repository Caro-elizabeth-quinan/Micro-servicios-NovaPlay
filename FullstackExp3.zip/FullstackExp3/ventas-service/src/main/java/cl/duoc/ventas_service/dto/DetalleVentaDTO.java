package cl.duoc.ventas_service.dto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@Data
@JsonPropertyOrder({"id","videojuegoId","cantidad","precioUnitario","subtotal"})
public class DetalleVentaDTO {

    private Long id;

    private Long videojuegoId;

    private Integer cantidad;

    private Integer precioUnitario;

    private Integer subtotal;
}