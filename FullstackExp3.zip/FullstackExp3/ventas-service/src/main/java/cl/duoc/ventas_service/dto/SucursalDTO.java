package cl.duoc.ventas_service.dto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@Data
@JsonPropertyOrder({"nombre","calle","provedor"})
public class SucursalDTO {
    private String nombre;
    private String calle;
    private ProveedorDTO provedor;

}
