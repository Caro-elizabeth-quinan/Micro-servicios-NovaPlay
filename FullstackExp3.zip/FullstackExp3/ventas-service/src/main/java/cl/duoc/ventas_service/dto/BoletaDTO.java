package cl.duoc.ventas_service.dto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

import java.time.LocalDate;

@Data
@JsonPropertyOrder({"id","monto","fechaEmision","iva"})
public class BoletaDTO {
    private Long id;
    private int monto;
    private LocalDate fechaEmision;
    private String iva;
}
