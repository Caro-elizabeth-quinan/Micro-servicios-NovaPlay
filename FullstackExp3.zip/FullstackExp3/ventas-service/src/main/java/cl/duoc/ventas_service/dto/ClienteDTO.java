package cl.duoc.ventas_service.dto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@Data
@JsonPropertyOrder({"nombreCompleto"})
public class ClienteDTO {
    private String nombreCompleto;
}

