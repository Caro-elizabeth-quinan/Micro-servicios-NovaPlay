package cl.duoc.ventas_service.dto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@Data
@JsonPropertyOrder({"id","titulo","genero","descripcion","precio"})
public class VideojuegosDTO {
    private Long id;

    private String titulo;

    private String genero;

    private String descripcion;

    private int precio;
}
