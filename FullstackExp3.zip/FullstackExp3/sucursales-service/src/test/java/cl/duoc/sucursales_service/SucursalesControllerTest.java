package cl.duoc.sucursales_service;

import cl.duoc.sucursales_service.controller.SucursalController;
import cl.duoc.sucursales_service.dto.ProveedorDTO;
import cl.duoc.sucursales_service.dto.SucursalDTO;
import cl.duoc.sucursales_service.dto.SucursalInputDTO;
import cl.duoc.sucursales_service.exception.ResourceNotFoundException;
import cl.duoc.sucursales_service.model.Sucursal;
import cl.duoc.sucursales_service.service.SucursalService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import tools.jackson.databind.ObjectMapper;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(SucursalController.class)
@DisplayName("Pruebas en la capa Controller de sucursales")
class SucursalControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private SucursalService sucursalService;

    private Sucursal sucursal;
    private SucursalDTO sucursalDTO;
    private SucursalInputDTO sucursalInputDTO;

    @Autowired
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        // Entidad tal como la devuelve el repository (listar, registrar, actualizar)
        sucursal = new Sucursal();
        sucursal.setId(1L);
        sucursal.setNombre("Sucursal Plaza Vespucio");
        sucursal.setCalle("Av. Vicuña Mackenna");
        sucursal.setNroSucursal(7110);
        sucursal.setIdProvedor(12);

        // DTO compuesto que devuelve findById, enriquecido con el proveedor vía Feign
        ProveedorDTO proveedorDTO = new ProveedorDTO();
        proveedorDTO.setRut("76.123.456-7");
        proveedorDTO.setNombre("Proveedor Mayorista SpA");
        proveedorDTO.setDireccion("Santiago Centro");

        sucursalDTO = new SucursalDTO();
        sucursalDTO.setNombre("Sucursal Plaza Vespucio");
        sucursalDTO.setCalle("Av. Vicuña Mackenna");
        sucursalDTO.setProvedor(proveedorDTO);

        // Input que envía el cliente al crear/actualizar (sin ID)
        sucursalInputDTO = new SucursalInputDTO();
        sucursalInputDTO.setNombre("Sucursal Plaza Vespucio");
        sucursalInputDTO.setCalle("Av. Vicuña Mackenna");
        sucursalInputDTO.setNroSucursal(7110);
        sucursalInputDTO.setIdProvedor(12);
    }

    @Test
    @DisplayName("GET /api/v1/sucursales - Debería retornar 200 OK y la lista de sucursales")
    void testEndpointListar() throws Exception {
        // Arrange
        when(sucursalService.findAll()).thenReturn(List.of(sucursal));

        // Act & Assert
        mockMvc.perform(get("/api/v1/sucursales"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].nombre").value("Sucursal Plaza Vespucio"))
                .andExpect(jsonPath("$[0].calle").value("Av. Vicuña Mackenna"))
                .andExpect(jsonPath("$[0].nroSucursal").value(7110))
                .andExpect(jsonPath("$[0].idProvedor").value(12));
    }

    @Test
    @DisplayName("GET /api/v1/sucursales/{cod} - Debería retornar 200 OK y el SucursalDTO con proveedor")
    void testEndpointBuscarPorId() throws Exception {
        // Arrange
        when(sucursalService.findById(1L)).thenReturn(sucursalDTO);

        // Act & Assert
        mockMvc.perform(get("/api/v1/sucursales/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nombre").value("Sucursal Plaza Vespucio"))
                .andExpect(jsonPath("$.calle").value("Av. Vicuña Mackenna"))
                .andExpect(jsonPath("$.provedor.rut").value("76.123.456-7"))
                .andExpect(jsonPath("$.provedor.nombre").value("Proveedor Mayorista SpA"));
    }

    @Test
    @DisplayName("GET /api/v1/sucursales/{cod} - Debería retornar 404 NOT FOUND cuando la sucursal no existe")
    void testEndpointBuscarPorIdNoEncontrada() throws Exception {
        // Arrange
        when(sucursalService.findById(99L))
                .thenThrow(new ResourceNotFoundException("Sucursal no encontrada con id: 99"));

        // Act & Assert
        mockMvc.perform(get("/api/v1/sucursales/99"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.status").value(404))
                .andExpect(jsonPath("$.error").value("NOT FOUND"))
                .andExpect(jsonPath("$.mensaje").value("Sucursal no encontrada con id: 99"))
                .andExpect(jsonPath("$.path").value("/api/v1/sucursales/99"));
    }

    @Test
    @DisplayName("POST /api/v1/sucursales - Debería retornar 201 CREATED y la sucursal creada")
    void testEndpointRegistrar() throws Exception {
        // Arrange
        when(sucursalService.save(any(Sucursal.class))).thenReturn(sucursal);

        // Act & Assert
        mockMvc.perform(post("/api/v1/sucursales")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(sucursalInputDTO)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.nombre").value("Sucursal Plaza Vespucio"))
                .andExpect(jsonPath("$.calle").value("Av. Vicuña Mackenna"))
                .andExpect(jsonPath("$.nroSucursal").value(7110))
                .andExpect(jsonPath("$.idProvedor").value(12));
    }

    @Test
    @DisplayName("PUT /api/v1/sucursales/{cod} - Debería retornar 200 OK y la sucursal actualizada")
    void testEndpointActualizar() throws Exception {
        // Arrange
        Sucursal actualizada = new Sucursal();
        actualizada.setId(1L);
        actualizada.setNombre("Sucursal Plaza Vespucio");
        actualizada.setCalle("Av. Vicuña Mackenna");
        actualizada.setNroSucursal(7110);
        actualizada.setIdProvedor(20);

        when(sucursalService.update(eq(1L), any(Sucursal.class))).thenReturn(actualizada);

        // Act & Assert
        mockMvc.perform(put("/api/v1/sucursales/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(sucursalInputDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.idProvedor").value(20));
    }

    @Test
    @DisplayName("PUT /api/v1/sucursales/{cod} - Debería retornar 404 NOT FOUND cuando la sucursal a actualizar no existe")
    void testEndpointActualizarNoEncontrada() throws Exception {
        // Arrange
        when(sucursalService.update(eq(88L), any(Sucursal.class)))
                .thenThrow(new ResourceNotFoundException("Sucursal no encontrada con id: 88"));

        // Act & Assert
        mockMvc.perform(put("/api/v1/sucursales/88")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(sucursalInputDTO)))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.mensaje").value("Sucursal no encontrada con id: 88"));
    }

    @Test
    @DisplayName("DELETE /api/v1/sucursales/{cod} - Debería retornar 204 NO CONTENT")
    void testEndpointBorrar() throws Exception {
        // Arrange
        doNothing().when(sucursalService).delete(1L);

        // Act & Assert
        mockMvc.perform(delete("/api/v1/sucursales/1"))
                .andExpect(status().isNoContent());
    }

    @Test
    @DisplayName("DELETE /api/v1/sucursales/{cod} - Debería retornar 404 NOT FOUND cuando la sucursal a eliminar no existe")
    void testEndpointBorrarNoEncontrada() throws Exception {
        // Arrange
        doThrow(new ResourceNotFoundException("Sucursal no encontrada con id: 99"))
                .when(sucursalService).delete(99L);

        // Act & Assert
        mockMvc.perform(delete("/api/v1/sucursales/99"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.mensaje").value("Sucursal no encontrada con id: 99"));
    }

    @Test
    @DisplayName("GET /api/v1/sucursales/proveedor/{idProveedor} - Debería retornar 200 OK y las sucursales del proveedor")
    void testEndpointBuscarProveedor() throws Exception {
        // Arrange
        when(sucursalService.buscarPorProveedor(12)).thenReturn(List.of(sucursal));

        // Act & Assert
        mockMvc.perform(get("/api/v1/sucursales/proveedor/12"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].idProvedor").value(12));
    }

    @Test
    @DisplayName("GET /api/v1/sucursales/buscar/numero/{nro} - Debería retornar 200 OK y las sucursales con ese número")
    void testEndpointBuscarNumero() throws Exception {
        // Arrange
        when(sucursalService.buscarPorNumero(7110)).thenReturn(List.of(sucursal));

        // Act & Assert
        mockMvc.perform(get("/api/v1/sucursales/buscar/numero/7110"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].nroSucursal").value(7110));
    }

    @Test
    @DisplayName("GET /api/v1/sucursales/buscar/nombre - Debería retornar 200 OK y las sucursales encontradas")
    void testEndpointBuscarNombre() throws Exception {
        // Arrange
        when(sucursalService.buscarPorNombre("Sucursal Plaza Vespucio")).thenReturn(List.of(sucursal));

        // Act & Assert
        mockMvc.perform(get("/api/v1/sucursales/buscar/nombre")
                        .param("valor", "Sucursal Plaza Vespucio"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].nombre").value("Sucursal Plaza Vespucio"));
    }

    @Test
    @DisplayName("GET /api/v1/sucursales/buscar/calle - Debería retornar 200 OK y las sucursales encontradas")
    void testEndpointBuscarCalle() throws Exception {
        // Arrange
        when(sucursalService.buscarPorCalle("Vicuña")).thenReturn(List.of(sucursal));

        // Act & Assert
        mockMvc.perform(get("/api/v1/sucursales/buscar/calle")
                        .param("valor", "Vicuña"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].calle").value("Av. Vicuña Mackenna"));
    }
}