package cl.duoc.sucursales_service.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Sucursal {

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    private Long id;

    @NotBlank(message = "El campo nombre no puede estar vacio")
    @Column(nullable = false)
    @Size(min = 3, max = 50)
    private String nombre;

    @NotBlank(message = "El campo calle no puede estar vacio")
    @Column(nullable = false)
    @Size(min = 3, max = 50)
    private String calle;

    @NotNull(message = "El campo nro de Sucursal no puede estar vacio")
    @Column(nullable = false)
    private int nroSucursal;

    @NotNull(message = "El campo provedor no puede estar vacio")
    @Column(nullable = false)
    private int idProvedor;
}
