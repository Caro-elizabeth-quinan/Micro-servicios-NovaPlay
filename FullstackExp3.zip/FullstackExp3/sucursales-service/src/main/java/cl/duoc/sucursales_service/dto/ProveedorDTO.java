package cl.duoc.sucursales_service.dto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@Data
@JsonPropertyOrder({"rut","nombre","direccion"})
public class ProveedorDTO {
    private String rut;
    private String nombre;
    private String direccion;
}
