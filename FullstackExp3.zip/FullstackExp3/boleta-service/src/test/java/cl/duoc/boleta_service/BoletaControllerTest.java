package cl.duoc.boleta_service.controller;

import cl.duoc.boleta_service.boletaDTO.BoletaDTO;
import cl.duoc.boleta_service.boletaDTO.BoletaInputDTO;
import cl.duoc.boleta_service.service.BoletaService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import tools.jackson.databind.ObjectMapper;

import java.time.LocalDate;
import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(BoletaController.class)
@DisplayName("Pruebas en la capa Controller de boletas")
class BoletaControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private BoletaService boletaService;

    private BoletaDTO boletaDTO;
    private BoletaInputDTO boletaInputDTO;

    @Autowired
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        // DTO de respuesta (lo que devuelve el service en todos los métodos)
        boletaDTO = new BoletaDTO();
        boletaDTO.setId(1L);
        boletaDTO.setMonto(15000);
        boletaDTO.setFechaEmision(LocalDate.of(2026, 6, 20));
        boletaDTO.setIva("19");

        // Input que envía el cliente al crear/actualizar
        boletaInputDTO = new BoletaInputDTO();
        boletaInputDTO.setMonto(15000);
        boletaInputDTO.setFechaEmision(LocalDate.of(2026, 6, 20));
        boletaInputDTO.setIva(19);
    }

    @Test
    @DisplayName("GET /api/v1/boletas - Debería retornar 200 OK y la lista de boletas")
    void testEndpointListar() throws Exception {
        // Arrange
        when(boletaService.findAll()).thenReturn(List.of(boletaDTO));

        // Act & Assert
        mockMvc.perform(get("/api/v1/boletas"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].monto").value(15000))
                .andExpect(jsonPath("$[0].fechaEmision").value("2026-06-20"))
                .andExpect(jsonPath("$[0].iva").value("19"));
    }

    @Test
    @DisplayName("GET /api/v1/boletas/{id} - Debería retornar 200 OK y la boleta encontrada")
    void testEndpointBuscarPorId() throws Exception {
        // Arrange
        when(boletaService.findById(1L)).thenReturn(boletaDTO);

        // Act & Assert
        mockMvc.perform(get("/api/v1/boletas/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.monto").value(15000))
                .andExpect(jsonPath("$.iva").value("19"));
    }

    @Test
    @DisplayName("GET /api/v1/boletas/{id} - Debería retornar 404 con body Map cuando la boleta no existe")
    void testEndpointBuscarPorIdNoEncontrada() throws Exception {
        // Arrange: el service retorna null (no lanza ResourceNotFoundException), y el
        // controller construye el 404 a mano con Map.of("error", ...), por lo que el
        // body NO tiene la forma de ErrorResponse (sin fecha/status/mensaje/path).
        when(boletaService.findById(99L)).thenReturn(null);

        // Act & Assert
        mockMvc.perform(get("/api/v1/boletas/99"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.error").value("La boleta solicitada no existe en el sistema"));
    }

    @Test
    @DisplayName("POST /api/v1/boletas - Debería retornar 201 CREATED y la boleta creada")
    void testEndpointRegistrar() throws Exception {
        // Arrange
        when(boletaService.save(any(BoletaInputDTO.class))).thenReturn(boletaDTO);

        // Act & Assert
        mockMvc.perform(post("/api/v1/boletas")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(boletaInputDTO)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.monto").value(15000))
                .andExpect(jsonPath("$.iva").value("19"));
    }

    @Test
    @DisplayName("PUT /api/v1/boletas/{id} - Debería retornar 200 OK y la boleta actualizada")
    void testEndpointActualizar() throws Exception {
        // Arrange
        BoletaDTO actualizada = new BoletaDTO();
        actualizada.setId(1L);
        actualizada.setMonto(20000);
        actualizada.setFechaEmision(LocalDate.of(2026, 6, 20));
        actualizada.setIva("19");

        when(boletaService.update(eq(1L), any(BoletaInputDTO.class))).thenReturn(actualizada);

        // Act & Assert
        mockMvc.perform(put("/api/v1/boletas/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(boletaInputDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.monto").value(20000));
    }

    @Test
    @DisplayName("PUT /api/v1/boletas/{id} - Debería retornar 404 con body Map cuando la boleta a actualizar no existe")
    void testEndpointActualizarNoEncontrada() throws Exception {
        // Arrange: igual que findById, update retorna null (no lanza excepción)
        when(boletaService.update(eq(99L), any(BoletaInputDTO.class))).thenReturn(null);

        // Act & Assert
        mockMvc.perform(put("/api/v1/boletas/99")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(boletaInputDTO)))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.error").value("No se encontró ningún registro con el ID provisto para actualizar"));
    }

    @Test
    @DisplayName("DELETE /api/v1/boletas/{id} - Debería retornar 204 NO CONTENT")
    void testEndpointBorrar() throws Exception {
        // Arrange
        doNothing().when(boletaService).delete(1L);

        // Act & Assert
        mockMvc.perform(delete("/api/v1/boletas/1"))
                .andExpect(status().isNoContent());
    }

    @Test
    @DisplayName("DELETE /api/v1/boletas/{id} - Debería retornar 500 cuando la boleta a eliminar no existe")
    void testEndpointBorrarNoEncontrada() throws Exception {
        // Arrange: el service lanza RuntimeException genérica, y el PROPIO controller
        // la atrapa en su try/catch devolviendo 500 (nunca llega al GlobalExceptionHandler,
        // aunque éste sí sepa manejar excepciones genéricas). El body es un Map, no un
        // ErrorResponse.
        doThrow(new RuntimeException("Boleta no encontrada"))
                .when(boletaService).delete(99L);

        // Act & Assert
        mockMvc.perform(delete("/api/v1/boletas/99"))
                .andExpect(status().isInternalServerError())
                .andExpect(jsonPath("$.error").value("Boleta no encontrada"));
    }

    @Test
    @DisplayName("GET /api/v1/boletas/reporte-rango - Debería retornar 200 OK y las boletas dentro del rango")
    void testEndpointBuscarRangoFechas() throws Exception {
        // Arrange
        when(boletaService.buscarRangoFechas(
                LocalDate.of(2026, 1, 1),
                LocalDate.of(2026, 6, 30)))
                .thenReturn(List.of(boletaDTO));

        // Act & Assert
        mockMvc.perform(get("/api/v1/boletas/reporte-rango")
                        .param("inicio", "2026-01-01")
                        .param("fin", "2026-06-30"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1));
    }

    @Test
    @DisplayName("GET /api/v1/boletas/monto/{monto} - Debería retornar 200 OK y las boletas sobre el monto")
    void testEndpointBuscarPorMontoMinimo() throws Exception {
        // Arrange
        when(boletaService.buscarPorMontoMinimo(10000)).thenReturn(List.of(boletaDTO));

        // Act & Assert
        mockMvc.perform(get("/api/v1/boletas/monto/10000"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].monto").value(15000));
    }

    @Test
    @DisplayName("GET /api/v1/boletas/iva/{iva} - Debería retornar 200 OK y las boletas con ese IVA")
    void testEndpointBuscarPorIva() throws Exception {
        // Arrange
        when(boletaService.buscarPorIva(19)).thenReturn(List.of(boletaDTO));

        // Act & Assert
        mockMvc.perform(get("/api/v1/boletas/iva/19"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].iva").value("19"));
    }

    @Test
    @DisplayName("GET /api/v1/boletas/buscar-por-fecha - Debería retornar 200 OK y las boletas de esa fecha")
    void testEndpointBuscarPorFecha() throws Exception {
        // Arrange
        when(boletaService.buscarPorFecha(LocalDate.of(2026, 6, 20)))
                .thenReturn(List.of(boletaDTO));

        // Act & Assert
        mockMvc.perform(get("/api/v1/boletas/buscar-por-fecha")
                        .param("fecha", "2026-06-20"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1));
    }
}