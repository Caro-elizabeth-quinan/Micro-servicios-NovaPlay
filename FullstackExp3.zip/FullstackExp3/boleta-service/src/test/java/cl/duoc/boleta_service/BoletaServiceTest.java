package cl.duoc.boleta_service.service;

import cl.duoc.boleta_service.boletaDTO.BoletaDTO;
import cl.duoc.boleta_service.boletaDTO.BoletaInputDTO;
import cl.duoc.boleta_service.boletaMapper.BoletaMapper;
import cl.duoc.boleta_service.model.Boleta;
import cl.duoc.boleta_service.repository.BoletaRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BoletaServiceTest {

    @Mock
    private BoletaRepository boletaRepository;

    @Mock
    private BoletaMapper boletaMapper;

    @InjectMocks
    private BoletaService boletaService;

    private Boleta boleta;
    private BoletaDTO boletaDTO;

    @BeforeEach
    void setUp() {
        // Objeto de base de datos
        boleta = new Boleta();
        boleta.setId(1L);
        boleta.setMonto(10000);
        boleta.setIva(19);
        boleta.setFechaEmision(LocalDate.now());

        // Objeto de salida esperado
        boletaDTO = new BoletaDTO();
        boletaDTO.setId(1L);
        boletaDTO.setMonto(10000);
        boletaDTO.setIva("19");
        boletaDTO.setFechaEmision(LocalDate.now());
    }

    // ---------------- FIND ALL ----------------
    @Test
    void testFindAll() {
        when(boletaRepository.findAll()).thenReturn(List.of(boleta));
        when(boletaMapper.toDTO(boleta)).thenReturn(boletaDTO);

        List<BoletaDTO> result = boletaService.findAll();

        assertEquals(1, result.size());
        assertEquals(1L, result.get(0).getId());
        verify(boletaRepository, times(1)).findAll();
        verify(boletaMapper, times(1)).toDTO(boleta);
    }

    // ---------------- FIND BY ID ----------------
    @Test
    void testFindById() {
        when(boletaRepository.findById(1L)).thenReturn(Optional.of(boleta));
        when(boletaMapper.toDTO(boleta)).thenReturn(boletaDTO);

        BoletaDTO result = boletaService.findById(1L);

        assertNotNull(result);
        assertEquals(1L, result.getId());
        verify(boletaRepository).findById(1L);
        verify(boletaMapper).toDTO(boleta);
    }

    // ---------------- SAVE ----------------
    @Test
    void testSave() {
        // Preparar entrada
        BoletaInputDTO input = new BoletaInputDTO();
        input.setMonto(10000);
        input.setIva(19);
        input.setFechaEmision(LocalDate.now());

        when(boletaRepository.save(any(Boleta.class))).thenReturn(boleta);
        when(boletaMapper.toDTO(boleta)).thenReturn(boletaDTO);

        BoletaDTO result = boletaService.save(input);

        assertNotNull(result);
        assertEquals(1L, result.getId());
        verify(boletaRepository).save(any(Boleta.class));
        verify(boletaMapper).toDTO(boleta);
    }

    // ---------------- UPDATE ----------------
    @Test
    void testUpdate() {
        // Preparar entrada con nuevos datos
        BoletaInputDTO inputUpdated = new BoletaInputDTO();
        inputUpdated.setMonto(20000);
        inputUpdated.setIva(10);
        inputUpdated.setFechaEmision(LocalDate.now());

        // El DTO que esperamos de respuesta editado
        BoletaDTO updatedDTO = new BoletaDTO();
        updatedDTO.setId(1L);
        updatedDTO.setMonto(20000);
        updatedDTO.setIva("10");
        updatedDTO.setFechaEmision(LocalDate.now());

        when(boletaRepository.findById(1L)).thenReturn(Optional.of(boleta));
        when(boletaRepository.save(any(Boleta.class))).thenReturn(boleta);
        when(boletaMapper.toDTO(any(Boleta.class))).thenReturn(updatedDTO);

        BoletaDTO result = boletaService.update(1L, inputUpdated);

        assertNotNull(result);
        assertEquals(20000, result.getMonto());
        verify(boletaRepository).findById(1L);
        verify(boletaRepository).save(any(Boleta.class));
    }

    // ---------------- DELETE ----------------
    @Test
    void testDelete() {
        when(boletaRepository.existsById(1L)).thenReturn(true);
        doNothing().when(boletaRepository).deleteById(1L);

        assertDoesNotThrow(() -> boletaService.delete(1L));

        verify(boletaRepository).deleteById(1L);
    }

    @Test
    void testDelete_BoletaNoExiste() {
        when(boletaRepository.existsById(1L)).thenReturn(false);

        RuntimeException exception = assertThrows(RuntimeException.class,
                () -> boletaService.delete(1L));

        assertEquals("Boleta no encontrada", exception.getMessage());
    }

    // ---------------- BUSQUEDAS ----------------
    @Test
    void testBuscarPorFecha() {
        when(boletaRepository.findByFechaEmision(any())).thenReturn(List.of(boleta));
        when(boletaMapper.toDTO(boleta)).thenReturn(boletaDTO);

        List<BoletaDTO> result = boletaService.buscarPorFecha(LocalDate.now());

        assertFalse(result.isEmpty());
        verify(boletaRepository).findByFechaEmision(any());
    }

    @Test
    void testBuscarPorMontoMinimo() {
        when(boletaRepository.findByMontoGreaterThanEqual(1000)).thenReturn(List.of(boleta));
        when(boletaMapper.toDTO(boleta)).thenReturn(boletaDTO);

        List<BoletaDTO> result = boletaService.buscarPorMontoMinimo(1000);

        assertEquals(1, result.size());
        verify(boletaRepository).findByMontoGreaterThanEqual(1000);
    }

    @Test
    void testBuscarPorIva() {
        when(boletaRepository.findByIva(19)).thenReturn(List.of(boleta));
        when(boletaMapper.toDTO(boleta)).thenReturn(boletaDTO);

        List<BoletaDTO> result = boletaService.buscarPorIva(19);

        assertEquals(1, result.size());
        verify(boletaRepository).findByIva(19);
    }
}