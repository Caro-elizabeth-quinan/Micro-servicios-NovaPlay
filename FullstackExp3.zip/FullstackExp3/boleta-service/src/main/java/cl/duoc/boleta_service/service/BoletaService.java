package cl.duoc.boleta_service.service;

import cl.duoc.boleta_service.boletaDTO.BoletaDTO;
import cl.duoc.boleta_service.boletaDTO.BoletaInputDTO;
import cl.duoc.boleta_service.boletaMapper.BoletaMapper;
import cl.duoc.boleta_service.model.Boleta;
import cl.duoc.boleta_service.repository.BoletaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class BoletaService {

    @Autowired
    private BoletaRepository boletaRepository;

    @Autowired
    private BoletaMapper boletaMapper;

    public List<BoletaDTO> findAll() {
        return boletaRepository.findAll()
                .stream()
                .map(boletaMapper::toDTO)
                .collect(Collectors.toList());
    }

    public BoletaDTO findById(Long id) {
        Boleta boleta = boletaRepository.findById(id).orElse(null);
        // Si no existe la entidad, retornamos null real de inmediato
        if (boleta == null) {
            return null;
        }
        return boletaMapper.toDTO(boleta);
    }

    public BoletaDTO save(BoletaInputDTO input) {
        Boleta boleta = new Boleta();
        boleta.setMonto(input.getMonto());
        boleta.setFechaEmision(input.getFechaEmision());
        boleta.setIva(input.getIva());

        Boleta nueva = boletaRepository.save(boleta);
        return boletaMapper.toDTO(nueva);
    }

    public BoletaDTO update(Long id, BoletaInputDTO input) {
        Boleta boletaActualizar = boletaRepository.findById(id).orElse(null);
        // Si no existe para actualizar, retornamos null
        if (boletaActualizar == null) {
            return null;
        }

        boletaActualizar.setIva(input.getIva());
        boletaActualizar.setMonto(input.getMonto());
        boletaActualizar.setFechaEmision(input.getFechaEmision());

        Boleta guardada = boletaRepository.save(boletaActualizar);
        return boletaMapper.toDTO(guardada);
    }

    public List<BoletaDTO> buscarPorFecha(LocalDate fecha) {
        return boletaRepository.findByFechaEmision(fecha)
                .stream()
                .map(boletaMapper::toDTO)
                .collect(Collectors.toList());
    }

    public List<BoletaDTO> buscarRangoFechas(LocalDate inicio, LocalDate fin) {
        return boletaRepository.findByFechaEmisionBetween(inicio, fin)
                .stream()
                .map(boletaMapper::toDTO)
                .collect(Collectors.toList());
    }

    public void delete(Long id) {
        if (!boletaRepository.existsById(id)) {
            throw new RuntimeException("Boleta no encontrada");
        }
        boletaRepository.deleteById(id);
    }

    public List<BoletaDTO> buscarPorMontoMinimo(int monto) {
        return boletaRepository.findByMontoGreaterThanEqual(monto)
                .stream()
                .map(boletaMapper::toDTO)
                .collect(Collectors.toList());
    }

    public List<BoletaDTO> buscarPorIva(int iva) {
        return boletaRepository.findByIva(iva)
                .stream()
                .map(boletaMapper::toDTO)
                .collect(Collectors.toList());
    }
}