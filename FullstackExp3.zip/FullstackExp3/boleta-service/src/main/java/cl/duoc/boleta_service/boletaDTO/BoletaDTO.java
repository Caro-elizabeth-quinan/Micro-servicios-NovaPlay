package cl.duoc.boleta_service.boletaDTO;


import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;

import java.time.LocalDate;

@JsonPropertyOrder({
        "id",
        "monto",
        "fechaEmision",
        "iva"
})
@Data
public class BoletaDTO {
    private Long id;
    private int monto;
    private LocalDate fechaEmision;
    private String iva;
}
