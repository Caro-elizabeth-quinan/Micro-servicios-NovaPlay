package cl.duoc.boleta_service.controller;

import cl.duoc.boleta_service.boletaDTO.BoletaDTO;
import cl.duoc.boleta_service.boletaDTO.BoletaInputDTO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import cl.duoc.boleta_service.service.BoletaService;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("api/v1/boletas")
@Tag(name = "Boletas", description = "API para la emisión, control financiero y generación de reportes de boletas")
public class BoletaController {

    @Autowired
    private BoletaService boletaService;

    @Operation(
            summary = "Listar boletas",
            description = "Obtiene el historial completo de boletas emitidas registradas en el sistema."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Listado de boletas recuperado con éxito",
            content = @Content(mediaType = "application/json", array = @ArraySchema(schema = @Schema(implementation = BoletaDTO.class)))
    )
    @ApiResponse(
            responseCode = "500",
            description = "Error interno del servidor al procesar la solicitud",
            content = @Content(mediaType = "application/json")
    )
    @GetMapping
    public ResponseEntity<List<BoletaDTO>> listar() {
        return ResponseEntity.ok(boletaService.findAll());
    }

    @Operation(
            summary = "Buscar boleta por ID",
            description = "Obtiene los detalles estructurados de una boleta mediante su identificador único."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Boleta localizada con éxito",
            content = @Content(mediaType = "application/json", schema = @Schema(implementation = BoletaDTO.class))
    )
    @ApiResponse(
            responseCode = "400",
            description = "El formato del ID proporcionado no es válido",
            content = @Content(mediaType = "application/json")
    )
    @ApiResponse(
            responseCode = "404",
            description = "La boleta solicitada no existe en el sistema",
            content = @Content(mediaType = "application/json")
    )
    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(
            @Parameter(description = "ID único de la boleta", example = "1")
            @PathVariable Long id
    ) {
        BoletaDTO dto = boletaService.findById(id);
        if (dto == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "La boleta solicitada no existe en el sistema"));
        }
        return ResponseEntity.ok(dto);
    }

    @Operation(
            summary = "Registrar boleta",
            description = "Crea una nueva boleta calculando y verificando montos e IVA asociados sin requerir ID manual."
    )
    @ApiResponse(
            responseCode = "201",
            description = "Boleta generada y guardada exitosamente",
            content = @Content(mediaType = "application/json", schema = @Schema(implementation = BoletaDTO.class))
    )
    @ApiResponse(
            responseCode = "400",
            description = "Cuerpo de solicitud inválido o faltan campos obligatorios",
            content = @Content(mediaType = "application/json")
    )
    @ApiResponse(
            responseCode = "500",
            description = "Error al intentar guardar la boleta en el sistema",
            content = @Content(mediaType = "application/json")
    )
    @PostMapping
    public ResponseEntity<BoletaDTO> registrar(@Valid @RequestBody BoletaInputDTO input) {
        return new ResponseEntity<>(boletaService.save(input), HttpStatus.CREATED);
    }

    @Operation(
            summary = "Actualizar boleta",
            description = "Modifica los datos financieros de una boleta existente localizándola por su ID."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Documento actualizado correctamente",
            content = @Content(mediaType = "application/json", schema = @Schema(implementation = BoletaDTO.class))
    )
    @ApiResponse(
            responseCode = "400",
            description = "Datos de actualización erróneos o ID inválido",
            content = @Content(mediaType = "application/json")
    )
    @ApiResponse(
            responseCode = "404",
            description = "No se encontró ningún registro con el ID provisto para actualizar",
            content = @Content(mediaType = "application/json")
    )
    @PutMapping("/{id}")
    public ResponseEntity<?> actualizar(
            @Parameter(description = "ID único de la boleta a actualizar", example = "1")
            @PathVariable Long id,
            @Valid @RequestBody BoletaInputDTO input
    ) {
        BoletaDTO actualizada = boletaService.update(id, input);
        if (actualizada == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", "No se encontró ningún registro con el ID provisto para actualizar"));
        }
        return ResponseEntity.ok(actualizada);
    }
    @Operation(
            summary = "Eliminar boleta",
            description = "Remueve un registro de boleta del sistema a partir de su ID."
    )
    @ApiResponse(
            responseCode = "204",
            description = "Boleta removida con éxito",
            content = @Content // <-- Al dejarlo así vacío, Swagger entiende que NO hay cuerpo ni tipo de medio erróneo
    )
    @ApiResponse(
            responseCode = "404",
            description = "La boleta seleccionada no existe para ser eliminada",
            content = @Content(mediaType = "application/json")
    )
    @ApiResponse(
            responseCode = "500",
            description = "Error de consistencia o validación de antigüedad fallida al borrar",
            content = @Content(mediaType = "application/json")
    )
    @DeleteMapping("/{id}")
    public ResponseEntity<?> borrar(
            @Parameter(description = "ID único de la boleta", example = "1")
            @PathVariable Long id
    ) {
        try {
            boletaService.delete(id);
            return ResponseEntity.noContent().build(); // Retorna 204 No Content limpio
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", e.getMessage()));
        }
    }

    @Operation(
            summary = "Reporte por rango de fechas",
            description = "Genera una lista de boletas comprendidas dentro de un intervalo temporal específico."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Reporte de rango temporal generado exitosamente",
            content = @Content(mediaType = "application/json", array = @ArraySchema(schema = @Schema(implementation = BoletaDTO.class)))
    )
    @ApiResponse(
            responseCode = "400",
            description = "Formato de parámetros de fecha incorrecto (Usa yyyy-MM-dd)",
            content = @Content(mediaType = "application/json")
    )
    @GetMapping("/reporte-rango")
    public ResponseEntity<List<BoletaDTO>> buscarRangoFechas(
            @Parameter(description = "Fecha de inicio del reporte (yyyy-MM-dd)", example = "2026-01-01")
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate inicio,
            @Parameter(description = "Fecha de término del reporte (yyyy-MM-dd)", example = "2026-06-30")
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fin
    ) {
        return ResponseEntity.ok(boletaService.buscarRangoFechas(inicio, fin));
    }

    @Operation(
            summary = "Buscar por monto mínimo",
            description = "Filtra todas aquellas boletas cuyo monto sea mayor o igual al valor provisto."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Registros que igualan o superan el monto localizados",
            content = @Content(mediaType = "application/json", array = @ArraySchema(schema = @Schema(implementation = BoletaDTO.class)))
    )
    @ApiResponse(
            responseCode = "400",
            description = "El valor del monto ingresado es incorrecto",
            content = @Content(mediaType = "application/json")
    )
    @GetMapping("/monto/{monto}")
    public ResponseEntity<List<BoletaDTO>> buscarPorMontoMinimo(
            @Parameter(description = "Monto mínimo límite de consulta", example = "5000")
            @PathVariable int monto
    ) {
        return ResponseEntity.ok(boletaService.buscarPorMontoMinimo(monto));
    }

    @Operation(
            summary = "Buscar por IVA",
            description = "Filtra las boletas almacenadas según un valor específico de IVA."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Coincidencias de IVA localizadas de forma exitosa",
            content = @Content(mediaType = "application/json", array = @ArraySchema(schema = @Schema(implementation = BoletaDTO.class)))
    )
    @ApiResponse(
            responseCode = "400",
            description = "El valor de IVA provisto no es válido",
            content = @Content(mediaType = "application/json")
    )
    @GetMapping("/iva/{iva}")
    public ResponseEntity<List<BoletaDTO>> buscarPorIva(
            @Parameter(description = "Porcentaje de IVA exacto a consultar", example = "19")
            @PathVariable int iva
    ) {
        return ResponseEntity.ok(boletaService.buscarPorIva(iva));
    }

    @Operation(
            summary = "Buscar por fecha de emisión",
            description = "Busca los documentos generados en un día específico del año."
    )
    @ApiResponse(
            responseCode = "200",
            description = "Documentos localizados para el día indicado",
            content = @Content(mediaType = "application/json", array = @ArraySchema(schema = @Schema(implementation = BoletaDTO.class)))
    )
    @ApiResponse(
            responseCode = "400",
            description = "La fecha ingresada posee un formato erróneo",
            content = @Content(mediaType = "application/json")
    )
    @GetMapping("/buscar-por-fecha")
    public ResponseEntity<List<BoletaDTO>> buscarPorFecha(
            @Parameter(description = "Día exacto de emisión (yyyy-MM-dd)", example = "2026-06-20")
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fecha
    ) {
        return ResponseEntity.ok(boletaService.buscarPorFecha(fecha));
    }
}