DROP DATABASE IF EXISTS bd_boletas;
DROP DATABASE IF EXISTS bd_clientes;
DROP DATABASE IF EXISTS bd_logins;
DROP DATABASE IF EXISTS bd_pedidos;
DROP DATABASE IF EXISTS bd_provedores;
DROP DATABASE IF EXISTS bd_sucursales;
DROP DATABASE IF EXISTS bd_vendedores;
DROP DATABASE IF EXISTS bd_ventas;
DROP DATABASE IF EXISTS bd_videojuegos;

-- =========================================
-- CREACION DE BASES DE DATOS
-- =========================================

CREATE DATABASE IF NOT EXISTS bd_boletas
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

CREATE DATABASE IF NOT EXISTS bd_clientes
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

CREATE DATABASE IF NOT EXISTS bd_logins
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

CREATE DATABASE IF NOT EXISTS bd_pedidos
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

CREATE DATABASE IF NOT EXISTS bd_provedores
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

CREATE DATABASE IF NOT EXISTS bd_sucursales
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

CREATE DATABASE IF NOT EXISTS bd_vendedores
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

CREATE DATABASE IF NOT EXISTS bd_ventas
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

CREATE DATABASE IF NOT EXISTS bd_videojuegos
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;