package cl.duoc.login_service.controller;

import cl.duoc.login_service.dto.LoginDTO;
import cl.duoc.login_service.exception.ResourceNotFoundException;
import cl.duoc.login_service.model.Login;
import cl.duoc.login_service.service.LoginService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import tools.jackson.databind.ObjectMapper;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(LoginController.class)
@DisplayName("Pruebas en la capa Controller de login")
class LoginControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private LoginService loginService;

    private Login login;
    private LoginDTO loginDTO;

    @Autowired
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        // Entidad tal como la devuelve el repository (listar, registrar, actualizar, buscarPorEmail)
        login = new Login();
        login.setId(1L);
        login.setEmail("admin@duocuc.cl");
        login.setContrasena("ClaveSegura123");

        // DTO resumido que devuelve findById (solo expone el email)
        loginDTO = new LoginDTO();
        loginDTO.setEmail("admin@duocuc.cl");
    }

    @Test
    @DisplayName("GET /api/v1/loganizas - Debería retornar 200 OK y la lista de logins")
    void testEndpointListar() throws Exception {
        // Arrange
        when(loginService.findAll()).thenReturn(List.of(login));

        // Act & Assert
        mockMvc.perform(get("/api/v1/loganizas"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].id").value(1))
                .andExpect(jsonPath("$[0].email").value("admin@duocuc.cl"))
                .andExpect(jsonPath("$[0].contrasena").value("ClaveSegura123"));
    }

    @Test
    @DisplayName("GET /api/v1/loganizas/{id} - Debería retornar 200 OK y el LoginDTO encontrado")
    void testEndpointBuscarPorId() throws Exception {
        // Arrange
        when(loginService.findById(1L)).thenReturn(loginDTO);

        // Act & Assert
        mockMvc.perform(get("/api/v1/loganizas/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.email").value("admin@duocuc.cl"));
    }

    @Test
    @DisplayName("GET /api/v1/loganizas/{id} - Debería retornar 404 NOT FOUND cuando el login no existe")
    void testEndpointBuscarPorIdNoEncontrado() throws Exception {
        // Arrange
        when(loginService.findById(99L))
                .thenThrow(new ResourceNotFoundException("Login no encontrado con id: 99"));

        // Act & Assert
        mockMvc.perform(get("/api/v1/loganizas/99"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.status").value(404))
                .andExpect(jsonPath("$.error").value("NOT FOUND"))
                .andExpect(jsonPath("$.mensaje").value("Login no encontrado con id: 99"))
                .andExpect(jsonPath("$.path").value("/api/v1/loganizas/99"));
    }

    @Test
    @DisplayName("POST /api/v1/loganizas - Debería retornar 201 CREATED y el login creado")
    void testEndpointCrear() throws Exception {
        // Arrange: el controller recibe @Valid @RequestBody Login (la entidad), no LoginInputDTO
        Login loginSinId = new Login();
        loginSinId.setEmail("admin@duocuc.cl");
        loginSinId.setContrasena("ClaveSegura123");

        when(loginService.save(any(Login.class))).thenReturn(login);

        // Act & Assert
        mockMvc.perform(post("/api/v1/loganizas")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(loginSinId)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.email").value("admin@duocuc.cl"))
                .andExpect(jsonPath("$.contrasena").value("ClaveSegura123"));
    }

    @Test
    @DisplayName("DELETE /api/v1/loganizas/{id} - Debería retornar 204 NO CONTENT")
    void testEndpointEliminar() throws Exception {
        // Arrange
        doNothing().when(loginService).delete(1L);

        // Act & Assert
        mockMvc.perform(delete("/api/v1/loganizas/1"))
                .andExpect(status().isNoContent());
    }

    @Test
    @DisplayName("DELETE /api/v1/loganizas/{id} - Debería retornar 404 NOT FOUND cuando el login a eliminar no existe")
    void testEndpointEliminarNoEncontrado() throws Exception {
        // Arrange
        doThrow(new ResourceNotFoundException("Login no encontrado con id: 99"))
                .when(loginService).delete(99L);

        // Act & Assert
        mockMvc.perform(delete("/api/v1/loganizas/99"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.mensaje").value("Login no encontrado con id: 99"));
    }

    @Test
    @DisplayName("PUT /api/v1/loganizas/{id} - Debería retornar 200 OK y el login actualizado")
    void testEndpointActualizar() throws Exception {
        // Arrange
        Login loginInput = new Login();
        loginInput.setEmail("admin@duocuc.cl");
        loginInput.setContrasena("NuevaClave456");

        Login actualizado = new Login();
        actualizado.setId(1L);
        actualizado.setEmail("admin@duocuc.cl");
        actualizado.setContrasena("NuevaClave456");

        when(loginService.update(eq(1L), any(Login.class))).thenReturn(actualizado);

        // Act & Assert
        mockMvc.perform(put("/api/v1/loganizas/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(loginInput)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.contrasena").value("NuevaClave456"));
    }

    @Test
    @DisplayName("PUT /api/v1/loganizas/{id} - Debería retornar 404 NOT FOUND cuando el login a actualizar no existe")
    void testEndpointActualizarNoEncontrado() throws Exception {
        // Arrange
        Login loginInput = new Login();
        loginInput.setEmail("admin@duocuc.cl");
        loginInput.setContrasena("ClaveSegura123");

        when(loginService.update(eq(99L), any(Login.class)))
                .thenThrow(new ResourceNotFoundException("Login no encontrado con id: 99"));

        // Act & Assert
        mockMvc.perform(put("/api/v1/loganizas/99")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(loginInput)))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.mensaje").value("Login no encontrado con id: 99"));
    }

    @Test
    @DisplayName("GET /api/v1/loganizas/email/{email} - Debería retornar 200 OK y el login encontrado")
    void testEndpointBuscarPorEmail() throws Exception {
        // Arrange: buscarPorEmail devuelve Login (la entidad completa), no LoginDTO
        when(loginService.buscarPorEmail("admin@duocuc.cl")).thenReturn(login);

        // Act & Assert
        mockMvc.perform(get("/api/v1/loganizas/email/admin@duocuc.cl"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.email").value("admin@duocuc.cl"));
    }

    @Test
    @DisplayName("GET /api/v1/loganizas/email/{email} - Debería retornar 404 NOT FOUND cuando el email no existe")
    void testEndpointBuscarPorEmailNoEncontrado() throws Exception {
        // Arrange
        when(loginService.buscarPorEmail("inexistente@duocuc.cl"))
                .thenThrow(new ResourceNotFoundException("Login no encontrado con email: inexistente@duocuc.cl"));

        // Act & Assert
        mockMvc.perform(get("/api/v1/loganizas/email/inexistente@duocuc.cl"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.mensaje").value("Login no encontrado con email: inexistente@duocuc.cl"));
    }
}