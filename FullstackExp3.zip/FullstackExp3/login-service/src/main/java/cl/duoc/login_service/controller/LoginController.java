package cl.duoc.login_service.controller;

import cl.duoc.login_service.dto.LoginDTO;
import cl.duoc.login_service.dto.LoginInputDTO;
import cl.duoc.login_service.exception.LoginErrorResponse;
import cl.duoc.login_service.model.Login;
import cl.duoc.login_service.service.LoginService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.ErrorResponse;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/v1/loganizas")
public class LoginController {
    @Autowired
    private LoginService loginService;


    @Operation(
            summary = "Obtener todos los usuarios",
            description = "Retorna una lista con todos los usuarios registrados en el sistema"
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "200",
                    description = "Usuarios obtenidos correctamente",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = Login.class)
                    )
            ),
            @ApiResponse(
                    responseCode = "204",
                    description = "No existen usuarios registrados"
            )
    })
    @GetMapping
    public ResponseEntity<?> listar() {
        return ResponseEntity.ok(loginService.findAll());
    }

    @Operation(
            summary = "Buscar usuario por ID",
            description = "Obtiene la información de un usuario utilizando su identificador"
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "200",
                    description = "Usuario encontrado",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = LoginDTO.class)
                    )
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Usuario no encontrado",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = LoginErrorResponse.class)
                    )
            )
    })
    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(
            @Parameter(
                    description = "ID del usuario",
                    example = "1"
            )
            @PathVariable Long id) {
        // Busca login por id.
        // Si no existe, el service lanzará error 404.
        return ResponseEntity.ok(
                loginService.findById(id)
        );
    }

    @Operation(
            summary = "Registrar usuario",
            description = "Crea un nuevo usuario dentro del sistema"
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "201",
                    description = "Usuario creado correctamente",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = Login.class)
                    )
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Datos inválidos",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = LoginErrorResponse.class)
                    )
            )
    })
    @PostMapping
    public ResponseEntity<Login> crear(
            @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "Datos del nuevo usuario",
                    required = true
            )
            @Valid @RequestBody Login input) {


        return ResponseEntity.status(HttpStatus.CREATED)
                .body(loginService.save(input));

    }


    @Operation(
            summary = "Eliminar usuario",
            description = "Elimina un usuario existente utilizando su identificador"
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "204",
                    description = "Usuario eliminado correctamente"
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Usuario no encontrado",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = LoginErrorResponse.class)
                    )
            )
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(

            @Parameter(
                    description = "ID del usuario a eliminar",
                    example = "1"
            )
            @PathVariable Long id) {

        loginService.delete(id);
        return ResponseEntity.noContent().build();
    }


    @Operation(
            summary = "Actualizar usuario",
            description = "Actualiza la información de un usuario existente"
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "200",
                    description = "Usuario actualizado correctamente",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = LoginDTO.class)
                    )
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Usuario no encontrado",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = LoginErrorResponse.class)
                    )
            ),
            @ApiResponse(
                    responseCode = "400",
                    description = "Datos inválidos",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = LoginErrorResponse.class)
                    )
            )
    })
    @PutMapping("/{id}")
    public ResponseEntity<?> actualizar(
            @Parameter(
                    description = "ID del usuario a actualizar",
                    example = "1"
            )
            @PathVariable Long id,

            @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "Datos actualizados del usuario",
                    required = true
            )
            @Valid @RequestBody Login login
    ) {
        // Actualiza login.
        // Si no existe, lanza error 404.
        return ResponseEntity.ok(
                loginService.update(id, login)
        );
    }

    @Operation(
            summary = "Buscar por email",
            description = "Busca a un usuario especifico por su email"
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "200",
                    description = "Usuario encontrado correctamente",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = LoginDTO.class)
                    )
            ),
            @ApiResponse(
                    responseCode = "404",
                    description = "Usuario no encontrado",
                    content = @Content(
                            mediaType = "application/json",
                            schema = @Schema(implementation = LoginErrorResponse.class)
                    )
            )
    })
    @GetMapping("/email/{email}")
    public ResponseEntity<Login> buscarPorEmail(@PathVariable String email) {

        return ResponseEntity.ok(
                loginService.buscarPorEmail(email)
        );
    }

}