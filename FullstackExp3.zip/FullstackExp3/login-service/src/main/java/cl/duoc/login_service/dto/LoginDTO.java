package cl.duoc.login_service.dto;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;


import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
@JsonPropertyOrder({"email"})
public class LoginDTO {
    @Schema(description = "Correo electrónico del usuario", example = "admin@duocuc.cl")
    private String email;
}
