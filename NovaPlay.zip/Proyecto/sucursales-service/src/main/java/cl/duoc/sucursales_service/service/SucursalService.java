package cl.duoc.sucursales_service.service;


import cl.duoc.sucursales_service.clients.ProvedorFeign;
import cl.duoc.sucursales_service.dto.ProveedorDTO;
import cl.duoc.sucursales_service.dto.SucursalDTO;
import cl.duoc.sucursales_service.exception.ResourceNotFoundException;
import cl.duoc.sucursales_service.mapper.SucursalMapper;
import cl.duoc.sucursales_service.model.Sucursal;
import cl.duoc.sucursales_service.repository.SucursalRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SucursalService {

    @Autowired
    private SucursalRepository sucursalRepository;

    @Autowired
    private SucursalMapper sucursalMapper;

    @Autowired
    private ProvedorFeign provedorFeign;
    // Lista todas las sucursales
    public List<Sucursal> findAll() {

        return sucursalRepository.findAll();
    }

    // Busca sucursal por id
    // Si no existe, lanza error 404
    public SucursalDTO findById(Long cod) {

        Sucursal sucu = sucursalRepository.findById(cod)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Sucursal no encontrada con id: " + cod
                        )
                );

        // Convierte entity a DTO
        SucursalDTO dto = sucursalMapper.toDTO(sucu);

        // Obtiene información del proveedor
        ProveedorDTO provedorDto =
                provedorFeign.buscarPorId(
                        sucu.getId_provedor()
                );

        dto.setProvedor(provedorDto);

        return dto;
    }

    // Guarda nueva sucursal
    public Sucursal save(Sucursal sucu) {

        return sucursalRepository.save(sucu);
    }

    // Elimina sucursal
    // Si no existe, lanza error 404
    public void delete(Long cod){

        // Verifica existencia
        if(!sucursalRepository.existsById(cod)){

            throw new ResourceNotFoundException(
                    "Sucursal no encontrada con id: " + cod
            );
        }

        sucursalRepository.deleteById(cod);
    }

    // Actualiza sucursal
    // Si no existe, lanza error 404
    public Sucursal update(Long cod, Sucursal sucursal){

        Sucursal sucuNueva = sucursalRepository.findById(cod)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Sucursal no encontrada con id: " + cod
                        )
                );

        // Actualiza campos
        sucuNueva.setNombre(sucursal.getNombre());
        sucuNueva.setCalle(sucursal.getCalle());
        sucuNueva.setNroSucursal(sucursal.getNroSucursal());
        sucuNueva.setId_provedor(sucursal.getId_provedor());

        return sucursalRepository.save(sucuNueva);
    }

    // Consulta 1: Buscar por nombre exacto
    public List<Sucursal> buscarPorNombre(String nombre) {

        return sucursalRepository.findByNombre(nombre);
    }

    // Consulta 2: Buscar coincidencia por calle
    public List<Sucursal> buscarPorCalle(String calle) {

        return sucursalRepository.findByCalleContainingIgnoreCase(calle);
    }

    // Consulta 3: Buscar por número de sucursal
    public List<Sucursal> buscarPorNumero(int nro) {

        return sucursalRepository.findByNroSucursal(nro);
    }

}
