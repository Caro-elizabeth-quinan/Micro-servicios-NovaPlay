package cl.duoc.sucursales_service.repository;

import cl.duoc.sucursales_service.model.Sucursal;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SucursalRepository extends JpaRepository<Sucursal,Long> {
    // 1. Buscar por nombre exacto
    List<Sucursal> findByNombre(String nombre);

    // 2. Buscar sucursales que contengan una palabra en la calle (Like)
    List<Sucursal> findByCalleContainingIgnoreCase(String calle);

    // 3. Buscar por el número de sucursal exacto
    List<Sucursal> findByNroSucursal(int nroSucursal);

    //Genera un error
    // 4. Buscar sucursales asociadas a un proveedor específico
    //List<Sucursal> findById_provedor(int id_Provedor);
}
