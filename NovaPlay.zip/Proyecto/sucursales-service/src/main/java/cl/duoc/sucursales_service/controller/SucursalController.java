package cl.duoc.sucursales_service.controller;

import cl.duoc.sucursales_service.dto.SucursalDTO;
import cl.duoc.sucursales_service.model.Sucursal;
import cl.duoc.sucursales_service.repository.SucursalRepository;
import cl.duoc.sucursales_service.service.SucursalService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/v1/sucursales")
public class SucursalController {
    @Autowired
    private SucursalService sucursalService;

    @GetMapping
    public ResponseEntity<?> listar(){
        return  ResponseEntity.ok(sucursalService.findAll());
    }

    @GetMapping("/{cod}")
    public ResponseEntity<?> buscarPorId(@PathVariable Long cod){
            // Busca sucursal por id.
            // Si no existe, el service lanzará error 404.
            return ResponseEntity.ok(
                    sucursalService.findById(cod)
            );
        }

    @PostMapping
    public ResponseEntity<?> registrar(
            // @Valid activa validaciones
            @Valid @RequestBody Sucursal sucursal
    ){
        // Guarda sucursal
        Sucursal nuevo = sucursalService.save(sucursal);
        // Retorna status 201
        return new ResponseEntity<>(
                nuevo,
                HttpStatus.CREATED
        );
    }

    @DeleteMapping("/{cod}")
    public ResponseEntity<?> borrar(@PathVariable Long cod){
        sucursalService.delete(cod);
        return ResponseEntity.noContent().build();
    }
    @PutMapping("/{cod}")
    public ResponseEntity<?> actualizar(
            @PathVariable Long cod,
             @Valid @RequestBody Sucursal sucursal
    ){// Actualiza sucursal.
        // Si no existe, lanza error 404.
        return ResponseEntity.ok(
                sucursalService.update(cod, sucursal)
        );
    }

    // 1. GET /api/v1/sucursales/buscar/nombre?valor=Centro
    @GetMapping("/buscar/nombre")
    public ResponseEntity<List<Sucursal>> filtrarPorNombre(@RequestParam String valor) {
        return ResponseEntity.ok(sucursalService.buscarPorNombre(valor));
    }

    // 2. GET /api/v1/sucursales/buscar/calle?valor=Alameda
    @GetMapping("/buscar/calle")
    public ResponseEntity<List<Sucursal>> filtrarPorCalle(@RequestParam String valor) {
        return ResponseEntity.ok(sucursalService.buscarPorCalle(valor));
    }

    // 3. GET /api/v1/sucursales/buscar/numero/101
    @GetMapping("/buscar/numero/{nro}")
    public ResponseEntity<List<Sucursal>> filtrarPorNumero(@PathVariable int nro) {
        return ResponseEntity.ok(sucursalService.buscarPorNumero(nro));
    }


}
