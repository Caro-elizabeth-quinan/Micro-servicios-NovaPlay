package cl.duoc.boleta_service.repository;

import cl.duoc.boleta_service.model.Boleta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface BoletaRepository extends JpaRepository<Boleta, Long> {
    // Buscar boletas emitidas en una fecha específica
    List<Boleta> findByFechaEmision(LocalDate fecha);

    // Buscar boletas con un monto superior a cierto valor
    List<Boleta> findByMontoGreaterThanEqual(int monto);

    // Buscar boletas por un rango de fechas (Muy útil para reportes)
    List<Boleta> findByFechaEmisionBetween(LocalDate inicio, LocalDate fin);

    // Custom Query usando JPQL para obtener el total recaudado en un mes
    @Query("SELECT SUM(b.monto) FROM Boleta b WHERE MONTH(b.fechaEmision) = :mes")
    Long sumMontoByMes(@Param("mes") int mes);
}
