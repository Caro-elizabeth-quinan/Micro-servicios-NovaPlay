package cl.duoc.boleta_service.service;

import cl.duoc.boleta_service.boletaDTO.BoletaDTO;
import cl.duoc.boleta_service.boletaMapper.BoletaMapper;
import cl.duoc.boleta_service.model.Boleta;
import cl.duoc.boleta_service.repository.BoletaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class BoletaService {

    @Autowired
    private BoletaRepository boletaRepository;
    @Autowired
    private BoletaMapper boletaMapper;

    public List<Boleta> findAll() {
        return boletaRepository.findAll();
    }

    public BoletaDTO findById(Long id) {
        Boleta boleta = boletaRepository.findById(id).orElse(null);
        return boletaMapper.toDTO(boleta);
    }

    public Boleta save(Boleta boleta) {
        return boletaRepository.save(boleta);
    }

    public Boleta update(Long id, Boleta boleta){
        Boleta boletaActualizar = boletaRepository.findById(id).orElse(null);
        if( boletaActualizar == null) return null;
        boletaActualizar.setIva( boleta.getIva() );
        boletaActualizar.setMonto( boleta.getMonto() );
        boletaActualizar.setFechaEmision(boleta.getFechaEmision());

        return boletaRepository.save(boletaActualizar);

    }

    public List<Boleta> buscarPorFecha(LocalDate fecha) {
        return boletaRepository.findByFechaEmision(fecha);
    }

    public List<Boleta> buscarRangoFechas(LocalDate inicio, LocalDate fin) {
        return boletaRepository.findByFechaEmisionBetween(inicio, fin);
    }

    // Ejemplo de validación: No permitir borrar si la boleta es muy antigua (regla de negocio)
    public void delete(Long id) {
        if (!boletaRepository.existsById(id)) {
            throw new RuntimeException("Boleta no encontrada");
        }
        boletaRepository.deleteById(id);
    }


}
