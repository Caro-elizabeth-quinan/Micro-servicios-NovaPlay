package cl.duoc.boleta_service.controller;

import cl.duoc.boleta_service.boletaDTO.BoletaDTO;
import cl.duoc.boleta_service.model.Boleta;
import cl.duoc.boleta_service.service.BoletaService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;

@RestController
@RequestMapping("api/v1/boletas")
public class BoletaController {

    @Autowired
    private BoletaService boletaService;

    @GetMapping
    public ResponseEntity<?> listar(){
        return  ResponseEntity.ok(boletaService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(@PathVariable Long id) {
        // Busca boleta por id.
        // Si no existe, el service lanzará
        // ResourceNotFoundException.
        return ResponseEntity.ok(
                boletaService.findById(id)
        );
    }

    @PostMapping
    public ResponseEntity<?> registrar(// @Valid activa las validaciones del model
            @Valid @RequestBody Boleta boleta){
        // Guarda nueva boleta
        Boleta nuevo = boletaService.save(boleta);
        // Retorna status 201
        return new ResponseEntity<>(nuevo,HttpStatus.CREATED);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> borrar(@PathVariable Long id){
        boletaService.delete(id);
        return ResponseEntity.noContent().build();
    }
    @PutMapping("/{id}")
    public ResponseEntity<?> actualizar(
            // Id de la boleta
            @PathVariable Long id,
            // Datos nuevos
            @Valid @RequestBody Boleta boleta)
    {
        // Actualiza la boleta.
        // Si no existe el id,
        // el service lanzará error 404.
        return ResponseEntity.ok(boletaService.update(id, boleta));
    }

    @GetMapping("/buscar-por-fecha")
    public ResponseEntity<?> buscarPorFecha(@RequestParam LocalDate fecha) {
        return ResponseEntity.ok(boletaService.buscarPorFecha(fecha));
    }

    @GetMapping("/reporte-rango")
    public ResponseEntity<?> reporteRango(@RequestParam LocalDate inicio, @RequestParam LocalDate fin) {
        return ResponseEntity.ok(boletaService.buscarRangoFechas(inicio, fin));
    }

}
