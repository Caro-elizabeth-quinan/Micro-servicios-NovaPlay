package cl.duoc.clientes_service.service;

import cl.duoc.clientes_service.clients.LoginFeign;
import cl.duoc.clientes_service.dto.ClienteDTO;
import cl.duoc.clientes_service.dto.LoginDTO;
import cl.duoc.clientes_service.exception.ResourceNotFoundException;
import cl.duoc.clientes_service.mapper.ClienteMapper;
import cl.duoc.clientes_service.model.Cliente;
import cl.duoc.clientes_service.repository.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class ClienteService {

    @Autowired
    private ClienteRepository clienteRepository;

    @Autowired
    private ClienteMapper clienteMapper;
    @Autowired
    private LoginFeign loginFeign;

    public List<Cliente> findAll() {
        return clienteRepository.findAll();
    }

    public ClienteDTO findById(Long id) {
        // Busca cliente por id.
        // Si no existe, lanza excepción 404.
        Cliente cliente = clienteRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                                "Cliente no encontrado con id: " + id
                        ));

        ClienteDTO dto = clienteMapper.toDTO(cliente);
        // Obtiene información del login
        LoginDTO loginDTO = loginFeign.buscarPorId(cliente.getLogin());
        dto.setLogin(loginDTO);
        return dto;
    }


    //Si quieres validar edad se haria aqui
    public Cliente save(Cliente cliente) {
        return clienteRepository.save(cliente);
    }

    public void delete(Long id){

        // Verifica si el cliente existe
        if(!clienteRepository.existsById(id)){

            // Lanza error 404
            throw new ResourceNotFoundException(
                    "Cliente no encontrado con id: " + id
            );
        }

        clienteRepository.deleteById(id);
    }

    public Cliente update(Long id, Cliente cliente){
        // Busca cliente a actualizar.
        // Si no existe, lanza error 404.
        Cliente clienteActualizar = clienteRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                                "Cliente no encontrado con id: " + id)
                );

        clienteActualizar.setNombre(cliente.getNombre());
        clienteActualizar.setApellido(cliente.getApellido());
        clienteActualizar.setFechaNacimiento(cliente.getFechaNacimiento());
        clienteActualizar.setLogin(cliente.getLogin());

        return clienteRepository.save(clienteActualizar);
    }


    // Métodos existentes... (findAll, findById, save, delete, update)

    public Cliente buscarPorRut(String rut) {
        // Busca cliente por rut.
        // Si no existe, lanza error 404.
        return clienteRepository.findByRut(rut)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Cliente no encontrado con rut: " + rut
                        )
                );
    }

    public List<Cliente> buscarPorApellido(String apellido) {
        return clienteRepository.findByApellidoContainingIgnoreCase(apellido);
    }

    public List<Cliente> buscarPorRangoFecha(LocalDate inicio, LocalDate fin) {
        return clienteRepository.findByFechaNacimientoBetween(inicio, fin);
    }
}
