package cl.duoc.clientes_service.controller;

import cl.duoc.clientes_service.dto.ClienteDTO;
import cl.duoc.clientes_service.model.Cliente;
import cl.duoc.clientes_service.service.ClienteService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("api/v1/clientes")
public class ClienteController {
    @Autowired
    private ClienteService clienteService;



    @GetMapping
    public ResponseEntity<?> listar(){
        return  ResponseEntity.ok(clienteService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(@PathVariable Long id){
        // Busca cliente por id.
        // Si no existe, el service lanzará error 404.
        return ResponseEntity.ok(
                clienteService.findById(id)
        );
    }

    @PostMapping
    public ResponseEntity<?> registrar(
            // @Valid activa validaciones del model
            @Valid @RequestBody Cliente cliente
    ){
        // Guarda nuevo cliente
        Cliente nuevo = clienteService.save(cliente);
        // Retorna status 201 CREATED
        return new ResponseEntity<>(
                nuevo,
                HttpStatus.CREATED
        );
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> borrar(@PathVariable Long id){
        clienteService.delete(id);
        return ResponseEntity.noContent().build();
    }
    @PutMapping("/{id}")
    public ResponseEntity<?> actualizar(
            // Id del cliente
            @PathVariable Long id,
            // Datos nuevos
            @Valid @RequestBody Cliente cliente
    ){
        // Actualiza cliente.
        // Si no existe, lanza error 404.
        return ResponseEntity.ok(
                clienteService.update(id, cliente)
        );
    }

    // 1. Buscar por RUT: GET /api/v1/clientes/buscar-rut?rut=12345678-9
    @GetMapping("/buscar-rut")
    public ResponseEntity<?> buscarPorRut(
            @RequestParam String rut
    ) {
        // Busca cliente por rut
        return ResponseEntity.ok(
                clienteService.buscarPorRut(rut)
        );
    }

    // 2. Buscar por Apellido: GET /api/v1/clientes/buscar-apellido?apellido=perez
    @GetMapping("/buscar-apellido")
    public ResponseEntity<?> buscarPorApellido(@RequestParam String apellido) {
        List<Cliente> clientes = clienteService.buscarPorApellido(apellido);
        return ResponseEntity.ok(clientes);
    }

    // 3. Buscar por Fechas: GET /api/v1/clientes/buscar-fechas?inicio=2000-01-01&fin=2005-12-31
    @GetMapping("/buscar-fechas")
    public ResponseEntity<?> buscarPorFechas(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate inicio,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fin) {
        List<Cliente> clientes = clienteService.buscarPorRangoFecha(inicio, fin);
        return ResponseEntity.ok(clientes);
    }
}
