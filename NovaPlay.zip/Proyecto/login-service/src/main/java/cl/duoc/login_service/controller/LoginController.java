package cl.duoc.login_service.controller;

import cl.duoc.login_service.dto.LoginDTO;
import cl.duoc.login_service.model.Login;
import cl.duoc.login_service.service.LoginService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("api/v1/login")
public class LoginController {
    @Autowired
    private LoginService loginService;

    @GetMapping
    public ResponseEntity<?> listar() {
        return ResponseEntity.ok(loginService.findAll());
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> buscarPorId(
            @PathVariable Long id) {
        // Busca login por id.
        // Si no existe, el service lanzará error 404.
        return ResponseEntity.ok(
                loginService.findById(id)
        );
    }

    @PostMapping
    public ResponseEntity<?> registrar(
            // @Valid activa validaciones del model
            @Valid @RequestBody Login login
    ) {
        // Guarda nuevo login
        Login nuevo = loginService.save(login);
        // Retorna status 201 CREATED
        return new ResponseEntity<>(
                nuevo,
                HttpStatus.CREATED
        );
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> borrar(@PathVariable Long id) {
        loginService.delete(id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> actualizar(
            // Id del login
            @PathVariable Long id,
            // Datos nuevos
            @Valid @RequestBody Login login
    ) {
        // Actualiza login.
        // Si no existe, lanza error 404.
        return ResponseEntity.ok(
                loginService.update(id, login)
        );
    }

}